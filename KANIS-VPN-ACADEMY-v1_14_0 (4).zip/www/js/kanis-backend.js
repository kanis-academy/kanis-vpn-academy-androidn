/* KANIS VPN ACADEMY — connexion Supabase, comptes, tableaux de bord (acheteur / revendeur / admin) */
(function(){
"use strict";
var C=window.KANIS_SUPABASE||{}, KV=window.KV={on:false,access:[],profile:null,db:null,cache:{},tok:0,screen:"",mounted:null};
var FMT=function(n){return Number(n||0).toLocaleString("fr-FR")+" FCFA";};
function h(t,a,k){var e=document.createElement(t);for(var x in a||{}){if(x==="class")e.className=a[x];else if(x.slice(0,2)==="on")e.addEventListener(x.slice(2),a[x]);else e.setAttribute(x,a[x]);}
  [].concat(k==null?[]:k).forEach(function(c){if(c!=null)e.appendChild(typeof c==="object"?c:document.createTextNode(String(c)));});return e;}
function toast(m){if(window.KANIS&&KANIS.toast)KANIS.toast(m);else alert(m);}
var css=".kv{position:fixed;inset:0;z-index:90;background:var(--bg,#f5f3ee);color:var(--ink,#24262b);overflow:auto;padding:calc(env(safe-area-inset-top,0px) + 12px) 14px calc(env(safe-area-inset-bottom,0px) + 24px);font:15px/1.45 system-ui,sans-serif}"+
".kv[hidden]{display:none}.kv .in{max-width:620px;margin:0 auto}.kv img.lg{display:block;width:96px;height:96px;margin:6px auto;border-radius:22px}"+
".kv h2{margin:10px 0 6px;font-size:20px}.kv h3{margin:16px 0 6px;font-size:16px}.kv .c{background:var(--surface,#fff);border:1px solid var(--line,#e2ded4);border-radius:14px;padding:12px;margin:8px 0}"+
".kv label{display:block;margin:8px 0;font-size:13px;color:var(--muted,#62646b)}.kv input,.kv select{display:block;width:100%;box-sizing:border-box;margin-top:4px;padding:11px;border:1px solid var(--line,#e2ded4);border-radius:10px;background:var(--bg,#fff);color:inherit;font-size:15px}"+
".kv button{border:0;border-radius:10px;padding:11px 14px;margin:4px 4px 4px 0;background:var(--accent,#d4a017);color:var(--accent-ink,#1b1400);font-weight:700;font-size:14px}.kv button.alt{background:transparent;border:1px solid var(--line,#ccc);color:inherit}"+
".kv .tabs{display:flex;gap:6px;overflow-x:auto;padding:6px 0}.kv .tabs button{white-space:nowrap;margin:0}.kv .row{display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid var(--line,#e2ded4);font-size:13px;flex-wrap:wrap}"+
".kv .k{display:grid;grid-template-columns:1fr 1fr;gap:8px}.kv .k b{display:block;font-size:18px}.kv .err{color:#d22f3c}.kv .ok{color:#1e9e5a}.kv s{color:var(--muted,#888)}.kv .tag{padding:2px 8px;border-radius:99px;background:var(--line,#e2ded4);font-size:12px}";
document.head.appendChild(h("style",{},css));
var css2=".kv h2{text-align:center}.kv .ctr{text-align:center}.kv button.big{display:block;width:100%;padding:15px;font-size:16px;margin:10px 0;border-radius:14px}"+
".kv .price{text-align:center;border:2px solid var(--accent,#d4a017);background:var(--surface,#fff);border-radius:16px;padding:14px;margin:10px 0}.kv .price[hidden]{display:none}"+
".kv .price small{display:block;font-size:11px;letter-spacing:.08em;color:var(--muted,#62646b);font-weight:700;margin:3px 0}.kv .price b{display:block;font-size:30px;margin:4px 0}"+
".kv a{color:var(--accent,#b8860b);font-weight:600}#toast{z-index:300}";
document.head.appendChild(h("style",{},css2));
var root=h("div",{class:"kv",hidden:"",role:"dialog","aria-label":"Mon compte"});document.body.appendChild(root);

var css3=".kv{--bg:#050d24;--surface:#0c1a3d;--ink:#eaf2ff;--muted:#93a9d6;--line:#1c3470;--accent:var(--a1);--accent-ink:#fff;background:radial-gradient(120% 60% at 50% -10%,var(--g0) 0%,var(--g1) 45%,var(--g3) 100%);padding-bottom:calc(92px + env(safe-area-inset-bottom,0px))}"+
".kv .hd{position:relative;text-align:center;padding:14px 10px 16px;margin:2px 0 10px;border-radius:22px;background:linear-gradient(160deg,var(--h1),var(--h2) 70%);border:1px solid var(--bd);box-shadow:0 8px 28px rgba(0,0,0,.3)}"+
".kv .hd img.lg{width:84px;height:84px;margin:0 auto 4px;border-radius:22px;box-shadow:0 0 0 2px #2f8bff,0 0 22px rgba(0,194,255,.55)}.kv .hd h2{margin:4px 0 8px;font-size:21px;color:var(--ht,#fff);letter-spacing:.02em}"+
".kv .fl{display:block;width:84px;height:5px;margin:0 auto;border-radius:3px;background:linear-gradient(90deg,#ff4d5e 0 33%,#ffc83d 33% 66%,#20c26b 66%)}"+
".kv .c{background:linear-gradient(180deg,var(--c1),var(--c2));border:1px solid var(--bd2);box-shadow:0 4px 14px rgba(0,0,0,.25)}.kv h3{color:var(--a3)}"+
".kv .tag{background:linear-gradient(90deg,var(--a1),var(--a2));color:var(--bt,#fff);font-weight:700;display:inline-block}.kv .err{color:#ff7482}.kv .ok{color:#3ddc97}.kv a{color:var(--a3)}"+
".kv input,.kv select{background:var(--g2);border:1px solid var(--bd);color:var(--ink)}.kv input:focus,.kv select:focus{outline:2px solid var(--a2);border-color:var(--a2)}"+
".kv button{border-radius:12px;color:var(--bt,#fff);background:linear-gradient(135deg,var(--a1),var(--a2));box-shadow:0 3px 10px rgba(0,0,0,.28);transition:transform .1s}.kv button:active{transform:scale(.97)}"+
".kv button[data-c=g]{background:linear-gradient(135deg,#12b76a,#0e9f5a);box-shadow:0 3px 10px rgba(18,183,106,.35)}"+
".kv button[data-c=r]{background:linear-gradient(135deg,#ff4d5e,#d92d3f);box-shadow:0 3px 10px rgba(255,77,94,.35)}"+
".kv button[data-c=y]{background:linear-gradient(135deg,#ffc83d,#f59e0b);color:#1b1400;box-shadow:0 3px 10px rgba(245,158,11,.35)}"+
".kv button[data-c=o]{background:transparent;border:1.5px solid var(--a3);color:var(--a3);box-shadow:none}"+
".kv .tabs{padding:8px 0 10px}.kv .tabs button{background:var(--c1);border:1px solid var(--bd);color:var(--tb,#bcd6ff);box-shadow:none;border-radius:99px;padding:8px 14px;font-size:13px}"+
".kv .tabs button:not(.alt){background:linear-gradient(135deg,var(--a1),var(--a2));border-color:transparent;color:var(--bt,#fff)}"+
".kv .price{background:linear-gradient(160deg,var(--h1),var(--h2));border-color:#ffc83d}"+
".kv .bn{position:fixed;left:0;right:0;bottom:0;z-index:5;display:grid;grid-template-columns:repeat(5,1fr);gap:2px;padding:6px 6px calc(6px + env(safe-area-inset-bottom,0px));background:linear-gradient(180deg,var(--n1),var(--g3));border-top:2px solid var(--a1);box-shadow:0 -6px 22px rgba(0,0,0,.45)}"+
".kv .bn button.nb{margin:0;padding:4px 2px;background:none;box-shadow:none;border:0;color:var(--muted);font-size:11px;font-weight:700;display:flex;flex-direction:column;align-items:center;gap:3px}"+
".kv .bn .ib{display:grid;place-items:center;width:46px;height:30px;border-radius:15px;color:var(--c);transition:all .08s}.kv .bn .ib svg{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}"+
".kv .bn button.on{color:var(--ink)}.kv .bn button.on .ib{background:var(--c);color:#041028;box-shadow:0 0 14px var(--c)}"+
".kv .in{position:relative;z-index:1}"+
".kv{background-color:var(--g3)}"+
".kv .tun{position:fixed;left:0;top:0;width:100%;height:100%;z-index:0;pointer-events:none}"+
".kv .c{background:linear-gradient(180deg,color-mix(in srgb,var(--c1) 88%,transparent),color-mix(in srgb,var(--c2) 88%,transparent))}"+
".kv .hello{margin:2px 0 8px;font-size:17px;font-weight:700;color:var(--ht,#fff)}"+
".kv .bf{text-align:center;margin:16px 0 6px;padding:11px 12px;border-radius:14px;border:1px solid var(--bd2);background:linear-gradient(90deg,rgba(239,43,45,.22),rgba(255,204,0,.22),rgba(0,154,68,.22));font-weight:800;font-size:14px;color:var(--ink)}";
var ICO={home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',book:'<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5"/><path d="M9 7h6"/>',play:'<circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5z"/>',bag:'<path d="M5 8h14l-1 12H6z"/><path d="M9 8a3 3 0 0 1 6 0"/>',key:'<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9"/><path d="M16 7l3 3"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.5 3.6-7 8-7s8 2.5 8 7"/>',cart:'<circle cx="9" cy="20" r="1.6"/><circle cx="18" cy="20" r="1.6"/><path d="M2 3h3l2.5 12h11l2-8H6"/>',list:'<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.6 3-6 7-6s7 2.4 7 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M19 14.5c1.8.8 3 2.4 3 5.5"/>',wallet:'<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18"/><circle cx="16.5" cy="15" r="1.2"/>',inbox:'<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>',gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>'};
function ico(k){var e=document.createElement("span");e.className="ib";e.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true">'+(ICO[k]||ICO.home)+'</svg>';return e;}
var BNAV=[["Formations","Accueil","home","#4cc9ff"],["Vidéos","Vidéos","play","#ff6b7a"],["Achats","Achats","bag","#ffc83d"],["Codes","Codes","key","#3ddc97"],["Profil","Compte","user","#b794ff"]],
    RNAV=[["Vendre","Vendre","cart","#4cc9ff"],["Ventes","Ventes","list","#ffc83d"],["Codes","Codes","key","#ff6b7a"],["Paiement","Paiement","wallet","#3ddc97"],["Profil","Compte","user","#b794ff"]],
    ANAV=[["Demandes revendeurs","Demandes","inbox","#4cc9ff"],["Acheteurs","Acheteurs","users","#3ddc97"],["Paiements","Paiements","wallet","#ffc83d"],["Vidéos","Vidéos","play","#ff6b7a"],["Réglages","Compte","user","#b794ff"]];
function navMark(n,t){if(!n)return;[].forEach.call(n.querySelectorAll(".nb"),function(x){x.classList.toggle("on",x.getAttribute("data-tab")===t);});}
function tabsUI(names,cur,set,nav){var ids=nav.map(function(x){return x[0];}),more=names.filter(function(n){return ids.indexOf(n)<0;});
  var navEl=h("nav",{class:"bn","aria-label":"Navigation"},nav.map(function(x){return h("button",{class:"nb"+(x[0]===cur?" on":""),"data-tab":x[0],style:"--c:"+x[3],"aria-label":x[1],onclick:function(){set(x[0]);navMark(navEl,x[0]);dash(true);}},[ico(x[2]),x[1]]);}));
  var out=more.length?h("div",{class:"tabs"},more.map(function(n){return h("button",{class:n===cur?"":"alt",onclick:function(){set(n);dash(true);}},n);})):document.createElement("span");
  out.__nav=navEl;return out;}

var THEMES=[["Bleu KANIS",215],["Violet",265],["Rose",330],["Rouge",355],["Orange",24],["Or",45],["Vert",145],["Turquoise",175]];
function hs(h,x,l){return "hsl("+h+","+x+"%,"+l+"%)";}
function curMode(){try{return localStorage.getItem("kv_mode")||"light";}catch(e){return "light";}}
function isLight(){var m=curMode();return m==="light"||(m==="auto"&&window.matchMedia&&matchMedia("(prefers-color-scheme: light)").matches);}
function applyTheme(i){var t=THEMES[i]||THEMES[0],h=t[1],L=isLight(),v=L?{"--a1":hs(h,90,48),"--a2":hs(h+((h>=35&&h<=75)?-15:25),95,45),"--a3":hs(h,85,36),"--h1":hs(h,85,52),"--h2":hs(h+15,85,38),"--bd":hs(h,55,72),"--bd2":hs(h,45,82),"--c1":"#ffffff","--c2":hs(h,60,98),"--g0":hs(h,100,94),"--g1":hs(h,100,97),"--g2":"#ffffff","--g3":hs(h,60,99),"--n1":"#ffffff","--line":hs(h,40,86),"--surface":"#ffffff","--bg":hs(h,100,97),"--accent":hs(h,90,48),"--muted":hs(h,18,38),"--ink":hs(h,60,12),"--tb":hs(h,85,34),"--bt":(h>=35&&h<=75)?"#1b1400":"#fff","--ht":(h>=35&&h<=75)?"#1b1400":"#fff"}:
  {"--a1":hs(h,95,56),"--a2":hs(h+((h>=35&&h<=75)?-15:25),100,50),"--a3":hs(h,100,72),"--h1":hs(h,80,30),"--h2":hs(h,75,17),"--bd":hs(h,70,50),"--bd2":hs(h,65,38),"--c1":hs(h,70,19),"--c2":hs(h,70,14),"--g0":hs(h,70,28),"--g1":hs(h,80,14),"--g2":hs(h,80,7),"--g3":hs(h,85,5),"--n1":hs(h,70,13),"--line":hs(h,60,27),"--surface":hs(h,70,16),"--bg":hs(h,80,8),"--accent":hs(h,95,56),"--muted":hs(h,40,72),"--ink":"#eaf2ff","--tb":"#bcd6ff","--bt":(h>=30&&h<=190)?"#08122b":"#fff","--ht":"#fff"};
  for(var k in v)root.style.setProperty(k,v[k]);root.setAttribute("data-mode",L?"light":"dark");try{localStorage.setItem("kv_theme",String(THEMES.indexOf(t)));}catch(e){}}
try{if(window.matchMedia)matchMedia("(prefers-color-scheme: light)").addEventListener("change",function(){if(curMode()==="auto")applyTheme(curTheme());});}catch(e){}
function curTheme(){try{return parseInt(localStorage.getItem("kv_theme"),10)||0;}catch(e){return 0;}}
function notifOn(){try{return localStorage.getItem("kv_notif")!=="0";}catch(e){return true;}}
applyTheme(curTheme());
var css4=".kv .mb{position:absolute;left:10px;top:10px;margin:0;width:44px;height:44px;padding:0;border-radius:14px;background:rgba(255,255,255,.12);border:1px solid var(--bd);box-shadow:none;font-size:22px;line-height:1}"+
".kv .dw{position:fixed;inset:0;z-index:20;display:flex}.kv .dw .bk{position:absolute;inset:0;background:rgba(0,0,0,.6)}.kv .dw .pn{position:relative;width:min(88vw,340px);height:100%;overflow:auto;background:linear-gradient(180deg,var(--g1),var(--g3));border-right:2px solid var(--a1);padding:calc(env(safe-area-inset-top,0px) + 14px) 14px 24px;animation:dwin .22s}@keyframes dwin{from{transform:translateX(-100%)}}"+
".kv .dw h3{margin:16px 0 6px}.kv .dw .top{display:flex;align-items:center;gap:10px}.kv .dw .top img{width:44px;height:44px;border-radius:12px}.kv .dw .top b{flex:1;font-size:17px}.kv .dw .top button{margin:0}"+
".kv .cs{width:42px;height:42px;padding:0;margin:4px;border-radius:50%;border:3px solid transparent;box-shadow:none}.kv .cs.on{border-color:#fff}"+
".kv .sw{width:54px;height:30px;padding:0;margin:0;border-radius:99px;background:#33415f;position:relative;box-shadow:none;flex:none}.kv .sw::after{content:'';position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;transition:left .2s}.kv .sw.on{background:#12b76a}.kv .sw.on::after{left:27px}"+
".kv .dw .ml{display:block;width:100%;text-align:left;margin:4px 0}.kv .dw .sr{display:flex;align-items:center;justify-content:space-between;gap:10px}.kv .dw small{color:var(--muted)}";
document.head.appendChild(h("style",{},css4));

var css5=".kv .c{animation:none}"+
".kv .hd::before{content:'';position:absolute;inset:0;border-radius:22px;background:radial-gradient(circle at 88% 0%,rgba(255,255,255,.25),transparent 55%);pointer-events:none}"+
".kv .bn{border-radius:22px 22px 0 0}.kv .k .c{border-top:3px solid var(--a2)}.kv .k b{font-size:20px;color:var(--a3)}"+
".kv .md{display:flex;gap:6px}.kv .md button{flex:1;margin:0;padding:10px 4px;background:var(--c1);border:1.5px solid var(--bd);color:var(--tb);box-shadow:none;font-size:13px}.kv .md button.on{background:linear-gradient(135deg,var(--a1),var(--a2));color:var(--bt,#fff);border-color:transparent}"+
".kv[data-mode=light]{color-scheme:light}.kv[data-mode=light] .c{box-shadow:0 6px 18px rgba(20,40,90,.10)}.kv[data-mode=light] .price{background:#fff;border-color:var(--a1)}"+
".kv[data-mode=light] .err{color:#c62839}.kv[data-mode=light] .ok{color:#0d8a53}.kv[data-mode=light] .sw{background:#c3cde0}.kv[data-mode=light] .sw.on{background:#12b76a}.kv[data-mode=light] .cs.on{border-color:#0b1b3d}"+
".kv[data-mode=light] .bn{box-shadow:0 -6px 22px rgba(20,40,90,.14)}.kv[data-mode=light] .dw .pn{box-shadow:8px 0 30px rgba(0,0,0,.2)}.kv[data-mode=light] .dw .bk{background:rgba(10,20,50,.4)}";
document.head.appendChild(h("style",{},css5));
document.head.appendChild(h("style",{},"\n.kv{-webkit-tap-highlight-color:transparent;overscroll-behavior:contain;scroll-behavior:auto}\n.kv button,.kv a,.kv select,.kv label,.kv summary{touch-action:manipulation}\n.kv .tunw{position:fixed;inset:0;z-index:0;pointer-events:none;overflow:hidden;contain:strict}\n.kv .tunw .gl{position:absolute;inset:0;background:radial-gradient(circle at 50% 42%,color-mix(in srgb,var(--a1) 34%,transparent),transparent 46%)}\n.kv .tunw .sp{position:absolute;left:50%;top:42%;width:150vmax;height:150vmax;margin:-75vmax 0 0 -75vmax;border-radius:50%;opacity:.55;background:repeating-conic-gradient(from 0deg,color-mix(in srgb,var(--a1) 28%,transparent) 0 .45deg,transparent .45deg 15deg);-webkit-mask-image:radial-gradient(circle,transparent 0 2%,#000 9%,transparent 46%);mask-image:radial-gradient(circle,transparent 0 2%,#000 9%,transparent 46%);animation:tunSpin 140s linear infinite;will-change:transform}\n.kv[data-mode=light] .tunw .sp{opacity:.28}\n.kv .tunw .rg{position:absolute;left:50%;top:42%;width:100vmin;height:100vmin;margin:-50vmin 0 0 -50vmin;border-radius:50%;border:2px solid var(--a1);opacity:0;transform:scale(.1);animation:tunRing 9s linear infinite;will-change:transform,opacity}\n.kv .tunw .rg.b{animation-delay:-3s}.kv .tunw .rg.c{animation-delay:-6s}\n.kv .tunw .tl{position:absolute;left:50%;top:42%;width:min(70vw,320px);height:auto;transform:translate(-50%,-50%);opacity:.08}\n.kv[data-mode=light] .tunw .tl{opacity:.06}\n@keyframes tunSpin{to{transform:rotate(360deg)}}\n@keyframes tunRing{0%{transform:scale(.1);opacity:0}15%{opacity:.38}100%{transform:scale(1.5);opacity:0}}\n@media (prefers-reduced-motion:reduce){.kv .tunw .sp,.kv .tunw .rg{animation:none}.kv .tunw .rg{opacity:.12;transform:scale(.7)}}\n.kv .sk{display:grid;gap:12px;padding:16px}\n.kv .skl{display:block;height:14px;border-radius:8px;background:linear-gradient(90deg,var(--c1) 25%,color-mix(in srgb,var(--a1) 24%,var(--c1)) 50%,var(--c1) 75%);background-size:200% 100%;animation:skl 1.1s linear infinite}\n.kv .skl.l{height:56px;border-radius:14px}.kv .skl.s{width:60%}\n@keyframes skl{to{background-position:-200% 0}}\n.kv .c{animation:upf .14s ease-out both;border-radius:16px}@keyframes upf{from{opacity:0}}\n.kv input,.kv select{min-height:48px;font-size:16px;border-radius:12px}\n.kv button{min-height:44px;transition:transform .08s ease-out,filter .08s}\n.kv button:active{transform:scale(.96);filter:brightness(1.12)}\n.kv .bn{padding-top:4px}\n.kv .bn button.nb{min-height:58px;transition:none}\n.kv .bn .ib{transition:background .1s,box-shadow .1s,transform .08s}\n.kv .bn button.nb:active .ib{transform:scale(.88)}\n.kv .hd{overflow:hidden}\n.kv p.tag{display:block;border-radius:12px;padding:9px 12px;line-height:1.4;font-size:13px}\n.kv .hd.big img.lg{width:116px;height:116px;border-radius:26px;box-shadow:0 0 0 3px #2f8bff,0 0 34px rgba(0,194,255,.65)}\n.kv .hd.big h2{font-size:23px}\n.kv .dw .pn{animation:dwin .16s ease-out}\n"));
function closeMenu(){var d=root.querySelector(".dw");if(d)d.remove();}
async function diag(out){out.textContent="";function L(ok,t){out.appendChild(h("div",{class:ok?"ok":"err"},(ok?"✓ ":"✗ ")+t));}
  L(!!(C.url&&C.anonKey),"Configuration : "+(C.url?C.url.replace(/^https?:\/\//,""):"URL absente"));
  L(!!KV.session,"Session : "+(KV.session?(KV.session.user.is_anonymous?"sans compte (anonyme) — OK":"connecté par e-mail"):"aucune"));
  try{var r=await KV.db.from("courses").select("id").limit(1);L(!r.error,"Table courses : "+(r.error?r.error.message:"accessible"));}catch(e){L(false,"Table courses : "+e.message);}
  try{var r2=await KV.db.rpc("my_access");L(!r2.error,"Fonctions SQL : "+(r2.error?r2.error.message:"OK"));}catch(e){L(false,"Fonctions SQL : "+e.message);}
  L(!!(KV.profile&&KV.profile.role),"Profil : "+(KV.profile?"rôle "+KV.profile.role:"introuvable"));
  out.appendChild(h("small",{},"Si une ligne est en erreur : exécute supabase/TOUT-EN-UN.sql et suis SUPABASE-GUIDE.md."));}
function menu(){if(root.querySelector(".dw")){closeMenu();return;}
  var role=KV.profile.role,tabs=role==="admin"?ATABS:role==="reseller"?RT:BT,set=role==="admin"?function(n){atab=n;}:role==="reseller"?function(n){rtab=n;}:function(n){btab=n;};
  var LBL={Codes:"🔑 Codes d’accès",Alertes:"🔔 Alertes",Profil:"👤 Mon profil",Accueil:"🏠 Accueil"};
  var sws=h("div",{},THEMES.map(function(t,i){return h("button",{class:"cs"+(i===curTheme()?" on":""),style:"background:"+hs(t[1],95,56),"aria-label":t[0],title:t[0],onclick:function(){applyTheme(i);sws.querySelectorAll(".cs").forEach(function(x,j){x.classList.toggle("on",j===i);});}});}));
  var sw=h("button",{class:"sw"+(notifOn()?" on":""),"aria-label":"Notifications",onclick:function(){var on=!notifOn();try{localStorage.setItem("kv_notif",on?"1":"0");}catch(e){}sw.classList.toggle("on",on);
    if(on){try{var P=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications;if(P&&P.requestPermissions)P.requestPermissions();else if(window.Notification&&Notification.requestPermission)Notification.requestPermission();}catch(e){}}toast(on?"Notifications activées":"Notifications désactivées");}});
var md=h("div",{class:"md"},[["light","☀️ Clair"],["dark","🌙 Sombre"],["auto","🌗 Auto"]].map(function(x){return h("button",{class:"mdb"+(curMode()===x[0]?" on":""),onclick:function(){try{localStorage.setItem("kv_mode",x[0]);}catch(e){}applyTheme(curTheme());md.querySelectorAll(".mdb").forEach(function(y,j){y.classList.toggle("on",["light","dark","auto"][j]===x[0]);});}},x[1]);}));
  var out=h("div",{class:"c"});
  var pn=h("div",{class:"pn"},[
    h("div",{class:"top"},[h("img",{src:"img/logo.png",alt:""}),h("b",{},"Menu"),h("button",{class:"alt",onclick:closeMenu},"✕")]),
    h("p",{class:"tag"},(KV.profile.full_name||KV.profile.email||"Mon espace")+" · "+{buyer:"Acheteur",reseller:"Revendeur",admin:"Administrateur"}[role]),
    h("h3",{},"🎨 Couleur de mon espace"),sws,
    h("h3",{},"🌓 Apparence"),md,h("h3",{},"🔔 Notifications"),h("div",{class:"sr"},[h("span",{},"Recevoir les alertes"),sw]),
    h("h3",{},"📂 Aller à"),
    h("div",{},tabs.map(function(n){return h("button",{class:"ml alt",onclick:function(){closeMenu();set(n);dash(true);}},LBL[n]||n);})),
    h("button",{class:"ml alt",onclick:function(){closeMenu();open(false);}},"▶ Accéder aux formations et outils"),
    h("h3",{},"🔌 Connexion Supabase"),h("button",{class:"ml",onclick:function(){diag(out);}},"Vérifier la connexion"),out,
    h("div",{style:"margin-top:14px"},logoutBtn()),madeBy(),h("small",{},"KANIS VPN ACADEMY · v1.13.0")]);
  root.appendChild(h("div",{class:"dw"},[h("div",{class:"bk",onclick:closeMenu}),pn]));}
var RED=/refus|supprim|annul|rejet|déconnect|désactiv|suspend|retir|bloqu/i,GRN=/accept|confirm|valid|activ|enregistr|cré|ajout|envoy|copier|whatsapp|déverrouill|approuv|payer|générer|accéder|réessayer/i,GLD=/modifi|édit|promo|réinit/i;
function colorize(){root.querySelectorAll("button").forEach(function(x){if(x.classList.contains("nb")||x.classList.contains("sw")||x.classList.contains("cs")||x.classList.contains("mb")||x.classList.contains("mdb")||x.closest(".tabs")||x.dataset.c)return;var t=x.textContent;x.dataset.c=RED.test(t)?"r":GRN.test(t)?"g":GLD.test(t)?"y":x.classList.contains("alt")?"o":"b";});}
var colQ=0;new MutationObserver(function(){if(colQ)return;colQ=requestAnimationFrame(function(){colQ=0;colorize();});}).observe(root,{childList:true,subtree:true});
document.head.appendChild(h("style",{},css3));
function open(v){root.hidden=!v;}
function head(t){return h("div",{class:"hd"},[h("img",{class:"lg",src:"img/logo.png",alt:"KANIS VPN ACADEMY"}),h("h2",{},t),h("i",{class:"fl"})]);}
function form(fields,label,fn){var f=h("form",{}),inp={},err=h("p",{class:"err"});
  fields.forEach(function(d){var i=d.opts?h("select",{},d.opts.map(function(o){return h("option",{value:o[0]},o[1]);})):h("input",{type:d.t||"text",autocomplete:d.ac||"off",value:d.v||""});if(d.v&&d.opts)i.value=d.v;inp[d.k]=i;f.appendChild(h("label",{},[d.l,i]));});
  f.appendChild(err);var b=h("button",{type:"submit"},label);f.appendChild(b);
  f.addEventListener("submit",async function(e){e.preventDefault();err.textContent="";var lb0=b.textContent;b.textContent="⏳ Patientez…";b.disabled=true;var v={};for(var k in inp)v[k]=inp[k].type==="password"?inp[k].value:inp[k].value.trim();
    try{await fn(v);}catch(x){err.textContent=x.message||String(x);}b.textContent=lb0;b.disabled=false;});return f;}
async function rpc(n,a){var r=await KV.db.rpc(n,a||{});if(r.error)throw r.error;return r.data;}
async function q(p){var r=await p;if(r.error)throw r.error;return r.data;}
function rows(list,fn){return h("div",{},list.length?list.map(fn):[h("p",{class:"tag"},"Aucune donnée")]);}
function row(a,b){return h("div",{class:"row"},[h("span",{},a),h("span",{},b)]);}
var TUN=null;
/* Tunnel allégé : un seul bloc réutilisé, animé en CSS (GPU) — aucun canvas, aucune boucle JavaScript. */
function tunnel(){if(!TUN){TUN=h("div",{class:"tunw","aria-hidden":"true"},[h("div",{class:"gl"}),h("div",{class:"sp"}),h("i",{class:"rg"}),h("i",{class:"rg b"}),h("i",{class:"rg c"}),h("img",{class:"tl",src:"img/logo.png",alt:"",decoding:"async"})]);}return TUN;}
function madeBy(){return h("div",{class:"bf"},"100% burkinabè 🇧🇫 · créé par Mr Simporé");}
function hello(){var n=(KV.profile&&KV.profile.full_name)||"";try{n=n||localStorage.getItem("kv_name")||"";}catch(e){}return h("p",{class:"hello"},"Bonjour"+(n?", "+n:"")+" 👋");}

/* ---------- Notifications (serveur + locales Android) ---------- */
function pushLocal(t,b){if(!notifOn())return;try{var P=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications;if(P)P.schedule({notifications:[{id:Math.floor(Math.random()*2e9),title:t,body:b||"",schedule:{at:new Date(Date.now()+400)}}]});}catch(e){}}
async function notifCard(){var ns=await q(KV.db.from("notifications").select("*").order("created_at",{ascending:false}).limit(20));
  return h("div",{class:"c"},[h("h3",{},"Notifications"),rows(ns,function(n){return h("div",{class:"row"},[h("span",{},[h("b",{},n.title),h("br"),n.body||""]),h("span",{class:"tag"},new Date(n.created_at).toLocaleDateString("fr-FR"))]);})]);}
function listen(){if(KV.ch){KV.db.removeChannel(KV.ch);KV.ch=null;}if(!KV.session)return;var me=KV.session.user.id;
  KV.ch=KV.db.channel("n-"+me).on("postgres_changes",{event:"INSERT",schema:"public",table:"notifications"},function(p){var n=p.new;if(n.user_id&&n.user_id!==me)return;if(notifOn()){pushLocal(n.title,n.body);toast(n.title);}if(!root.hidden)dash(true);}).subscribe();
  catchUp();}
async function catchUp(){try{var k="kv_seen_"+KV.session.user.id,last=localStorage.getItem(k),now=new Date().toISOString();
  if(last){var ns=await q(KV.db.from("notifications").select("*").gt("created_at",last).order("created_at").limit(3));ns.forEach(function(n){pushLocal(n.title,n.body);});}localStorage.setItem(k,now);}catch(e){}}

/* ---------- Accès aux formations (décidé par le serveur) ---------- */
KV.has=function(k){return KV.access.indexOf(k)>-1;};
KV.refresh=async function(){try{KV.access=KV.db&&KV.session?await rpc("my_access"):[];}catch(e){KV.access=[];}};
KV.redeem=async function(code){if(!KV.session){toast("Connecte-toi pour utiliser un code");KV.openAccount();return null;}
  try{var s=await rpc("redeem_code",{p_code:code});prefetchGift("buyer");await KV.refresh();return s;}catch(e){toast(e.message);return null;}};
function player(v){var m=String(v.url).match(/(?:youtu\.be\/|[?&]v=|\/embed\/)([A-Za-z0-9_-]{11})/),w=h("div",{class:"c"},[h("b",{},(v.chapter?v.chapter+" · ":"")+v.title)]);
  if(v.signed||/\.(mp4|webm)(\?.*)?$/i.test(v.url))w.appendChild(h("video",{controls:"",playsinline:"",preload:"metadata",controlslist:"nodownload noplaybackrate",disablepictureinpicture:"",oncontextmenu:function(e){e.preventDefault();},src:v.url,style:"width:100%;border-radius:10px;margin-top:6px"}));
  else if(m)w.appendChild(h("iframe",{src:"https://www.youtube-nocookie.com/embed/"+m[1]+"?rel=0&playsinline=1",allowfullscreen:"",style:"width:100%;aspect-ratio:16/9;border:0;border-radius:10px;margin-top:6px"}));
  else w.appendChild(h("a",{href:v.url,target:"_blank",rel:"noopener"},"Ouvrir la vidéo"));return w;}
KV.renderVideo=async function(key,box){box.textContent="";
  try{var vs=await rpc("get_video_sources",{p_slug:key});if(!vs.length)box.appendChild(h("p",{},"Vidéo bientôt disponible."));
    for(var i=0;i<vs.length;i++){var v=vs[i];if(v.storage_path){var su=await KV.db.storage.from("videos").createSignedUrl(v.storage_path,7200);if(su.error){box.appendChild(h("p",{class:"err"},"Vidéo indisponible."));continue;}v.url=su.data.signedUrl;v.signed=true;}
      var pl=player(v);if(v.description)pl.appendChild(h("p",{},v.description));box.appendChild(pl);}}
  catch(e){box.appendChild(h("p",{class:"err"},"Impossible de charger la vidéo : "+e.message));}};

/* ---------- Authentification (inscription directe, sans confirmation e-mail) ---------- */
var NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
var CALLBACK="kanisvpn://auth-callback";
var CONFIRM_HELP="Dans Supabase : Authentication → Sign In / Providers → Email → désactive « Confirm email » → Save.";
var STATUS={pending:"En attente de vérification",confirmed:"Confirmé",refused:"Refusé",refunded:"Remboursé"};
var PROV={orange_money:"Orange Money",wave:"Wave",manual:"Manuel"};
function stopPoll(){if(KV.poll){clearInterval(KV.poll);KV.poll=null;}}
function mapErr(e){var m=String((e&&e.message)||e||""),c=String((e&&(e.code||e.error_code))||""),all=m+" "+c;
  if(/already registered|already been registered|user_already_exists/i.test(all))return "Un compte existe déjà avec cet e-mail. Connecte-toi.";
  if(/invalid login credentials|invalid_credentials/i.test(all))return "E-mail ou mot de passe incorrect.";
  if(/email not confirmed|email_not_confirmed/i.test(all))return "Supabase exige encore la confirmation par e-mail pour ce compte. "+CONFIRM_HELP;
  if(/over_email_send_rate_limit|email rate limit/i.test(all))return "L’envoi d’e-mails est momentanément saturé. Réessaie plus tard ou contacte l’administrateur sur WhatsApp.";
  if(/rate limit|too many|over_.*_rate_limit|\b429\b/i.test(all))return "Trop de tentatives. Patiente quelques minutes puis réessaie. [détail : "+String(c||m).slice(0,90)+(e&&e.status?" / HTTP "+e.status:"")+"]";
  if(/signup.*disabled|signups not allowed|signup_disabled/i.test(all))return "Les inscriptions sont désactivées dans Supabase (Authentication → Sign In / Providers → « Allow new users to sign up »).";
  if(/password/i.test(m)&&/(should|least|weak|short|characters)/i.test(m))return "Mot de passe refusé : 8 caractères minimum et pas trop simple.";
  if(/database error saving new user/i.test(m))return "Le profil n’a pas pu être créé : exécute les migrations SQL 001, 002 puis 003 dans Supabase.";
  if(/failed to fetch|networkerror|load failed|network request/i.test(m))return "Pas de connexion Internet, ou serveur Supabase injoignable.";
  if(/invalid api key|apikey/i.test(all))return "Clé Supabase invalide : l’URL et la clé publique de config.js doivent venir du MÊME projet.";
  return m||"Erreur inconnue";}
function shell(title){stopPoll();KV.screen="sub";KV.mounted=null;root.textContent="";root.className="kv";root.appendChild(tunnel());var b=h("div",{class:"in"});root.appendChild(b);b.appendChild(head(title));open(true);return b;}
function logoutBtn(){if(KV.session&&KV.session.user&&KV.session.user.is_anonymous)return document.createElement("span");return h("button",{class:"alt",onclick:function(){logout();}},"Se déconnecter");}
function logout(){stopPoll();KV.leaving=true;var db=KV.db;try{if(KV.ch){db.removeChannel(KV.ch);KV.ch=null;}}catch(e){}
  KV.cache={};KV.mounted=null;KV.session=null;KV.profile=null;KV.access=[];KV.locked=true;
  welcome();
  /* la déconnexion serveur se fait en arrière-plan : l'écran change tout de suite, sans attendre le réseau */
  try{db.auth.signOut().then(function(r){if(r&&r.error)return db.auth.signOut({scope:"local"});}).catch(function(){try{db.auth.signOut({scope:"local"});}catch(e){}}).then(function(){KV.leaving=false;});}catch(e){KV.leaving=false;}}
function errorView(msg){var b=shell("Connexion impossible");b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},msg),h("button",{onclick:function(){route();}},"Réessayer"),logoutBtn()]));}

function welcome(){var b=shell("Bienvenue"),nm="";KV.screen="welcome";b.firstChild.classList.add("big");try{nm=localStorage.getItem("kv_name")||"";}catch(e){}
  b.appendChild(h("p",{class:"ctr"},"Apprends, protège ta connexion et réussis avec KANIS VPN ACADEMY."));
  var inp=h("input",{type:"text",placeholder:"Ex : Awa Traoré",autocomplete:"name",maxlength:"40",value:nm}),er=h("p",{class:"err"});
  b.appendChild(h("div",{class:"c"},[h("h3",{},"✍️ Ton nom"),h("p",{class:"tag"},"Écris ton nom : il s’affichera en haut de ton espace (« Bonjour, ton nom »)."),h("label",{},["Mon nom",inp]),er]));
  function go(role){var n=inp.value.trim();if(n.length<2){er.textContent="Écris ton nom pour continuer.";inp.focus();return;}er.textContent="";try{localStorage.setItem("kv_name",n);}catch(e){}startAs(role,n);}
  b.appendChild(h("button",{class:"big",onclick:function(){go("buyer");}},"JE SUIS ACHETEUR"));
  b.appendChild(h("button",{class:"big alt",onclick:function(){go("reseller");}},"JE SUIS REVENDEUR"));
  b.appendChild(h("p",{class:"ctr"},h("a",{href:"#",onclick:function(e){e.preventDefault();loginView();}},"Administration")));}
async function startAs(role,name){var b=shell("Un instant…");b.appendChild(h("p",{class:"ctr"},"Préparation de ton espace…"));
  try{if(!KV.session){var r=await KV.db.auth.signInAnonymously({options:{data:{want_reseller:role==="reseller"?"true":"",full_name:name||""}}});if(r.error)throw r.error;KV.session=r.data.session;}
    if(name&&KV.session&&KV.session.user){try{await KV.db.from("profiles").update({full_name:name}).eq("id",KV.session.user.id);}catch(e){}}
    await route();}
  catch(e){var m=String((e&&e.message)||"")+String((e&&e.code)||""),b2=shell("Démarrage impossible");
    b2.appendChild(h("div",{class:"c"},[h("p",{class:"err"},/anonymous/i.test(m)?"Les accès sans compte ne sont pas activés sur le serveur (Supabase : Authentication → Sign In / Providers → Allow anonymous sign-ins, puis bouton Save changes).":mapErr(e)),h("small",{},"Détail technique : "+String((e&&e.code)||"")+" "+String((e&&e.message)||"")+" · serveur : "+String((C&&C.url)||"?").replace(/^https?:\/\//,"")),h("button",{onclick:function(){welcome();}},"Retour")]));}}

function loginView(){var b=shell("Administration"),c=h("div",{class:"c"});b.appendChild(c);
  c.appendChild(form([{k:"email",l:"Adresse e-mail",t:"email",ac:"email"},{k:"pw",l:"Mot de passe",t:"password",ac:"current-password"}],"SE CONNECTER",async function(v){
    if(!v.email||!v.pw)throw new Error("Saisis ton e-mail et ton mot de passe.");
    var r=await KV.db.auth.signInWithPassword({email:v.email,password:v.pw});if(r.error)throw new Error(mapErr(r.error));
    KV.session=r.data.session;await route();}));
  b.appendChild(h("div",{},[h("button",{class:"alt",onclick:welcome},"Retour")]));}

function signupView(type){var b=shell("Créer un compte");
  var banner=h("div",{class:"price",hidden:""});b.appendChild(banner);
  var c=h("div",{class:"c"});b.appendChild(c);
  var f=form([{k:"type",l:"Type de compte",opts:[["buyer","Acheteur"],["reseller","Revendeur"]],v:type||"buyer"},
    {k:"name",l:"Nom complet",ac:"name"},{k:"email",l:"Adresse e-mail",t:"email",ac:"email"},{k:"phone",l:"Numéro de téléphone",t:"tel",ac:"tel"},
    {k:"pw",l:"Mot de passe (8 caractères min.)",t:"password",ac:"new-password"},{k:"pw2",l:"Confirmer le mot de passe",t:"password",ac:"new-password"}],"CRÉER MON COMPTE",async function(v){
    if(v.name.length<3)throw new Error("Saisis ton nom complet.");
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email))throw new Error("Adresse e-mail invalide.");
    if(v.phone.replace(/\D/g,"").length<8)throw new Error("Numéro de téléphone invalide.");
    if(v.pw.length<8)throw new Error("Le mot de passe doit avoir au moins 8 caractères.");
    if(v.pw!==v.pw2)throw new Error("Les deux mots de passe ne sont pas identiques.");
    if(KV.lastSignup&&Date.now()-KV.lastSignup<4000)throw new Error("Patiente quelques secondes avant de réessayer.");KV.lastSignup=Date.now();
    var r=await KV.db.auth.signUp({email:v.email,password:v.pw,options:{emailRedirectTo:NATIVE?CALLBACK:(C.redirectTo||location.origin+"/"),data:{full_name:v.name,phone:v.phone,want_reseller:v.type==="reseller"?"true":"false"}}});
    if(r.error)throw new Error(mapErr(r.error));
    if(r.data.user&&r.data.user.identities&&r.data.user.identities.length===0)throw new Error("Un compte existe déjà avec cet e-mail. Connecte-toi.");
    if(!r.data.session){noSessionView();return;}                       // jamais « connecté » sans vraie session
    KV.session=r.data.session;await route();});
  c.appendChild(f);
  var sel=f.querySelector("select");
  function paint(base,fin){banner.textContent="";banner.appendChild(h("small",{},"ACTIVATION DU COMPTE REVENDEUR"));
    banner.appendChild(h("b",{},[fin<base?h("s",{},FMT(base)):null,fin<base?" ":null,FMT(fin)]));
    if(fin<base)banner.appendChild(h("small",{},"Promotion en cours appliquée automatiquement"));
    banner.appendChild(h("small",{},"À payer après la création du compte. Le compte reste INACTIF jusqu’à la confirmation du paiement."));}
  async function upd(){if(sel.value!=="reseller"){banner.hidden=true;return;}banner.hidden=false;paint(3000,3000);
    try{var p=await rpc("activation_quote");if(sel.value==="reseller")paint(p.base,p.final);}catch(e){}}
  sel.addEventListener("change",upd);upd();
  b.appendChild(h("div",{},[h("button",{class:"alt",onclick:function(){loginView();}},"J’ai déjà un compte"),h("button",{class:"alt",onclick:welcome},"Retour")]));}

function noSessionView(){var b=shell("Compte créé, session non ouverte");
  b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},"Ton compte existe, mais Supabase n’a pas ouvert de session : la confirmation par e-mail est encore activée sur le serveur."),
    h("p",{},CONFIRM_HELP),h("p",{class:"tag"},"Une fois désactivée, les nouveaux comptes seront connectés directement. Pour ce compte, demande à l’administrateur de le confirmer (Authentication → Users)."),
    h("button",{onclick:function(){loginView();}},"Se connecter"),h("button",{class:"alt",onclick:welcome},"Retour")]));}

function forgotView(){var b=shell("Mot de passe oublié"),c=h("div",{class:"c"});b.appendChild(c);
  c.appendChild(h("p",{},"1. Contacte l’administrateur sur WhatsApp : il initialise ton accès pendant 24 h. 2. Reviens ici et choisis ton nouveau mot de passe."));
  c.appendChild(h("a",{href:waUrl(C.whatsapp,"Bonjour, j’ai oublié mon mot de passe KANIS VPN ACADEMY. Pouvez-vous initialiser mon accès ?"),target:"_blank",rel:"noopener",style:WAST},"CONTACTER SUR WHATSAPP"));
  var c2=h("div",{class:"c"});b.appendChild(c2);c2.appendChild(h("h3",{},"Choisir mon nouveau mot de passe"));
  c2.appendChild(form([{k:"email",l:"Adresse e-mail du compte",t:"email",ac:"email"},{k:"phone",l:"Numéro de téléphone du compte",t:"tel"},{k:"pw",l:"Nouveau mot de passe (8 caractères min.)",t:"password",ac:"new-password"},{k:"pw2",l:"Confirmer le mot de passe",t:"password",ac:"new-password"}],"ENREGISTRER",async function(v){
    if(!v.email||!v.phone)throw new Error("Saisis ton e-mail et ton numéro de téléphone.");if(v.pw.length<8)throw new Error("8 caractères minimum.");if(v.pw!==v.pw2)throw new Error("Les deux mots de passe ne sont pas identiques.");
    var r=await rpc("claim_reset",{p_email:v.email.trim(),p_phone:v.phone,p_new:v.pw});
    if(r!=="ok")throw new Error("Impossible : e-mail ou numéro incorrect, ou ton accès n’a pas été initialisé (ou a expiré). Contacte l’administrateur.");
    var sg=await KV.db.auth.signInWithPassword({email:v.email.trim(),password:v.pw});if(sg.error)throw new Error(mapErr(sg.error));KV.session=sg.data.session;toast("Mot de passe enregistré ✓");await route();}));
  b.appendChild(h("button",{class:"alt",onclick:function(){loginView();}},"Retour à la connexion"));}

function recoveryView(){var b=shell("Nouveau mot de passe"),c=h("div",{class:"c"});b.appendChild(c);
  c.appendChild(form([{k:"pw",l:"Nouveau mot de passe (8 caractères min.)",t:"password",ac:"new-password"},{k:"pw2",l:"Confirmer le mot de passe",t:"password",ac:"new-password"}],"ENREGISTRER",async function(v){
    if(v.pw.length<8)throw new Error("8 caractères minimum.");if(v.pw!==v.pw2)throw new Error("Les deux mots de passe ne sont pas identiques.");
    var r=await KV.db.auth.updateUser({password:v.pw});if(r.error)throw new Error(mapErr(r.error));toast("Mot de passe modifié ✓");await route();}));}

function linkError(msg){var b=shell("Lien invalide ou expiré");
  b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},msg||"Ce lien est expiré ou a déjà été utilisé."),h("button",{onclick:forgotView},"Demander un nouveau lien"),h("button",{class:"alt",onclick:function(){route();}},"Retour")]));}

/* Lien profond Android : kanisvpn://auth-callback#access_token=…&type=recovery */
async function handleCallback(url){var u=String(url||"");if(u.indexOf("auth-callback")<0)return;
  try{var q={},parts=u.split("#"),qs=(parts[0].split("?")[1]||""),hs=parts.slice(1).join("#");
    (qs+"&"+hs).split("&").forEach(function(p){if(!p)return;var i=p.indexOf("=");if(i<1)return;q[decodeURIComponent(p.slice(0,i))]=decodeURIComponent(p.slice(i+1).replace(/\+/g," "));});
    if(q.error||q.error_code||q.error_description){linkError(/expired|otp_expired/i.test((q.error_code||"")+(q.error_description||""))?"Ce lien est expiré. Demande-en un nouveau.":(q.error_description||"Lien invalide."));return;}
    if(q.access_token&&q.refresh_token){var r=await KV.db.auth.setSession({access_token:q.access_token,refresh_token:q.refresh_token});if(r.error)throw r.error;KV.session=r.data.session;
      if(q.type==="recovery"){recoveryView();return;}await route();return;}
    linkError("Lien incomplet : redemande un nouveau lien.");
  }catch(e){linkError("Lien invalide ou expiré. "+mapErr(e));}}
function wireDeepLinks(){try{var A=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.App;if(!A)return;
  A.addListener("appUrlOpen",function(e){handleCallback(e&&e.url);});
  if(A.getLaunchUrl)A.getLaunchUrl().then(function(r){if(r&&r.url)handleCallback(r.url);}).catch(function(){});}catch(e){}}

/* ---------- Profil, redirection selon rôle et statut ---------- */
async function loadProfile(){var id=KV.session.user.id,r=await KV.db.from("profiles").select("*").eq("id",id).maybeSingle();if(r.error)throw r.error;
  if(!r.data){var e=await KV.db.rpc("ensure_profile");if(e.error){if(e.error.code==="PGRST202"||/schema cache/i.test(e.error.message||"")){var ss=await KV.db.auth.getSession(),an=ss&&ss.data&&ss.data.session&&ss.data.session.user&&ss.data.session.user.is_anonymous;throw new Error("ensure_profile introuvable pour ce compte (session: "+(ss&&ss.data&&ss.data.session?(an?"anonyme":"connecté"):"AUCUNE")+", projet: "+String(C.url).replace("https://","").split(".")[0]+"). Détail serveur : "+(e.error.message||"")+" ["+(e.error.code||"")+"]");}throw e.error;}r=await KV.db.from("profiles").select("*").eq("id",id).maybeSingle();if(r.error)throw r.error;}
  if(!r.data)throw new Error("Profil introuvable : exécute la migration SQL 003.");return r.data;}
async function route(){stopPoll();
  if(!KV.session){KV.profile=null;KV.access=[];KV.locked=true;welcome();return;}
  var p;try{p=await loadProfile();}catch(e){var m=String((e&&e.message)||"")+(e&&e.code||"");
    if(/jwt|token|PGRST30|401/i.test(m)){try{await KV.db.auth.signOut({scope:"local"});}catch(x){}KV.session=null;KV.locked=true;welcome();return;}
    errorView(mapErr(e));return;}
  KV.profile=p;KV.profAt=Date.now();KV.cache={};KV.mounted=null;listen();await KV.refresh();KV.accAt=Date.now();
  if(p.role==="reseller"&&p.reseller_status!=="active"){KV.locked=true;await activationView();return;}   // revendeur inactif : page d’activation obligatoire
  KV.locked=false;await dash();}

/* ---------- Page d'activation du compte revendeur ---------- */
var USSD="*144*2*1*44947055*3000#",WAST="display:block;text-align:center;margin-top:10px;padding:12px;border-radius:12px;background:#25D366;color:#fff;font-weight:700;text-decoration:none";
function waUrl(n,t){return "https://wa.me/"+String(n||"").replace(/\D/g,"")+"?text="+encodeURIComponent(t);}
function copyTxt(t){try{navigator.clipboard.writeText(t).then(function(){toast("Copié ✓");},function(){toast(t);});}catch(e){toast(t);}}
async function upl(bucket,file,uid){var ext=(file.name.split(".").pop()||"bin").replace(/[^a-z0-9]/gi,"").slice(0,5)||"bin",path=uid+"/"+Date.now()+"-"+Math.random().toString(36).slice(2,7)+"."+ext;var r=await KV.db.storage.from(bucket).upload(path,file,{contentType:file.type});if(r.error)throw r.error;return path;}
function thumbUrl(p){return p?KV.db.storage.from("thumbs").getPublicUrl(p).data.publicUrl:"";}
async function priced(cs){await Promise.all(cs.map(async function(c){try{c.eff=await rpc("price_for",{p_course:c.id,p_promo:null});}catch(e){c.eff=c.price;}}));return cs;}
function priceEl(c){var e=c.eff==null?c.price:c.eff;return e<c.price?h("p",{},[h("s",{},FMT(c.price)),"  ",h("b",{},FMT(e)+" (PROMO)")]):h("p",{},FMT(c.price));}
function vidList(c,vl){if(!vl.length)return [h("p",{class:"tag"},"Aucune vidéo pour l’instant.")];return vl.map(function(v){var tu=thumbUrl(v.thumbnail_path),k=h("div",{class:"c"},[tu?h("img",{src:tu,alt:"",style:"width:100%;border-radius:10px"}):null,h("b",{},v.title),h("p",{},v.description||"")]);
  if(v.unlocked)k.appendChild(h("button",{onclick:function(){open(false);window.KANIS.openCourse(c.slug);}},"▶ Regarder"));
  else{k.appendChild(h("p",{class:"tag"},"🔒 VIDÉO VERROUILLÉE"));k.appendChild(h("button",{onclick:function(){btab="Codes";dash();}},"DÉVERROUILLER AVEC UN CODE"));}return k;});}
function copyHost(t,ok){function fb(){try{var a=document.createElement("textarea");a.value=t;a.setAttribute("readonly","");a.style.cssText="position:fixed;opacity:0;top:0;left:0";document.body.appendChild(a);a.select();document.execCommand("copy");document.body.removeChild(a);ok();}catch(e){toast("Copie impossible, réessayez");}}try{navigator.clipboard.writeText(t).then(ok,fb);}catch(e){fb();}}
var SITEST="display:block;text-align:center;margin-top:10px;padding:12px;border-radius:12px;background:var(--accent,#2a6df4);color:var(--ht,#fff);font-weight:700;text-decoration:none";
function prefetchGift(aud){KV.gift=KV.gift||{};KV.gift[aud]=rpc("get_host_gift",{p_audience:aud}).catch(function(){return null;});return KV.gift[aud];}
function giftBlock(aud){var box=h("div",{class:"gift"}),pr=(KV.gift&&KV.gift[aud])||prefetchGift(aud);if(KV.gift)delete KV.gift[aud];
  var sk=h("div",{class:"c"},[h("h3",{},"🎁 Host offert"),h("button",{class:"big",onclick:function(){pr.then(function(g){var x=g&&g.hosts&&g.hosts[0];if(!x){toast("Host indisponible, contactez l’administrateur");return;}copyHost(x.host,function(){var bt=sk.querySelector("button");if(bt)bt.textContent="✅ Host copié !";toast("Host copié ✓");});});}},"📋 COPIER LE HOST")]);
  box.appendChild(sk);
  pr.then(function(g){try{var hs=(g&&g.hosts)||[],ss=(g&&g.sites)||[];box.textContent="";
    if(hs.length){box.appendChild(h("div",{class:"c"},[h("h3",{},"🎁 Host offert")]));
      hs.forEach(function(x){var btn=h("button",{class:"big",onclick:function(){copyHost(x.host,function(){btn.textContent="✅ Host copié !";toast("Host copié ✓");});}},"📋 COPIER LE HOST");
        box.appendChild(h("div",{class:"c"},[h("p",{},(x.flag||"🏳️")+" "+(x.country_name||"")),btn]));});
      box.appendChild(h("div",{class:"c"},[h("h3",{},"🌍 Vous êtes dans un autre pays ?"),h("p",{},"Si le host de votre pays n’est pas dans la liste ci-dessus, contactez l’administrateur pour l’obtenir."),h("a",{href:waUrl(C.whatsapp,"Bonjour, j’ai activé mon accès KANIS VPN ACADEMY. Je suis dans un autre pays. Pouvez-vous m’envoyer le host de mon pays ? Mon pays : "),target:"_blank",rel:"noopener",style:WAST},"💬 CONTACTER L’ADMINISTRATEUR")]));}
    if(ss.length){var c=h("div",{class:"c"},[h("h3",{},"🌐 Sites gratuits pour créer vos fichiers")]);ss.forEach(function(x){c.appendChild(h("a",{href:x.url,target:"_blank",rel:"noopener",style:SITEST},x.title||x.url));});box.appendChild(c);}
  }catch(e){}});
  return box;}
function codeOk(){var b=shell("Félicitations");b.appendChild(h("div",{class:"c"},[h("h3",{},"FÉLICITATIONS ! 🎉"),h("p",{},"Votre code d’accès est valide !"),h("p",{},"Votre formation vient d’être activée avec succès. Vous pouvez maintenant regarder toutes les vidéos de cette formation."),h("p",{},"Bonne formation sur KANIS VPN ACADEMY !"),h("button",{onclick:function(){btab="Vidéos";dash();}},"REGARDER MES VIDÉOS")]));b.appendChild(giftBlock("buyer"));}
function vidForm(cs2,chs){var f=h("form",{}),err=h("p",{class:"err"}),F={};
  function add(k,l,i){F[k]=i;f.appendChild(h("label",{},[l,i]));}
  add("course","Formation",h("select",{},cs2.map(function(c){return h("option",{value:c.id},c.title);})));
  add("chapter","Chapitre",h("select",{},[h("option",{value:""},"—")].concat(chs.map(function(c){return h("option",{value:c.id},c.title);}))));
  add("title","Titre",h("input",{type:"text",required:"required"}));add("desc","Description détaillée",h("textarea",{rows:"3"}));add("pos","Ordre d’affichage",h("input",{type:"number",value:"0"}));
  add("thumb","Miniature (image)",h("input",{type:"file",accept:"image/*"}));add("file","Fichier vidéo (MP4/WebM, stockage privé)",h("input",{type:"file",accept:"video/mp4,video/webm"}));add("url","… ou lien YouTube non répertorié",h("input",{type:"text"}));
  var btn=h("button",{type:"submit"},"Ajouter");f.appendChild(err);f.appendChild(btn);
  f.addEventListener("submit",async function(e){e.preventDefault();err.textContent="";var vf=F.file.files[0],url=F.url.value.trim();if(!vf&&!url){err.textContent="Ajoute un fichier vidéo ou un lien.";return;}btn.disabled=true;
    try{var uid=KV.profile.id,sp=vf?await upl("videos",vf,uid):null,tp=F.thumb.files[0]?await upl("thumbs",F.thumb.files[0],uid):null;
      await q(KV.db.from("videos").insert({course_id:F.course.value,chapter_id:F.chapter.value||null,title:F.title.value.trim(),description:F.desc.value.trim(),url:url||("storage:"+sp),storage_path:sp,thumbnail_path:tp,position:+F.pos.value||0}));dash();}
    catch(x){err.textContent=mapErr(x);}btn.disabled=false;});return f;}
function waBlock(){return h("div",{class:"c"},[h("p",{},"Vous souhaitez devenir revendeur ? Vous avez une question sur le paiement ou votre activation ? Contactez directement l’administrateur sur WhatsApp."),
  h("a",{href:waUrl(C.whatsapp,"Bonjour, je souhaite devenir revendeur KANIS VPN ACADEMY. Je voudrais obtenir les informations pour effectuer mon paiement de 3 000 FCFA et recevoir mon code d’activation."),target:"_blank",rel:"noopener",style:WAST},"CONTACTER SUR WHATSAPP")]);}
function proofForm(p){var f=h("form",{}),err=h("p",{class:"err"}),F={};
  [["name","Nom complet","text",p.full_name||""],["phone","Téléphone","tel",p.phone||""],["email","Adresse e-mail","email",p.email||""],["pay","Numéro utilisé pour le paiement","tel",""],["amount","Montant (FCFA)","number","3000"]].forEach(function(d){var i=h("input",{type:d[2],value:d[3],required:"required"});F[d[0]]=i;f.appendChild(h("label",{},[d[1],i]));});
  F.email.removeAttribute("required");
  var file=h("input",{type:"file",accept:"image/*",required:"required"});f.appendChild(h("label",{},["Capture de la preuve de paiement",file]));
  var btn=h("button",{type:"submit"},"ENVOYER MA PREUVE");f.appendChild(err);f.appendChild(btn);
  f.addEventListener("submit",async function(e){e.preventDefault();err.textContent="";var fl=file.files[0];if(!fl){err.textContent="Ajoute la capture de paiement.";return;}if(fl.size>5*1024*1024){err.textContent="Image trop lourde (5 Mo maximum).";return;}btn.disabled=true;
    try{var ext=(fl.name.split(".").pop()||"jpg").replace(/[^a-z0-9]/gi,"").slice(0,5)||"jpg",path=p.id+"/"+Date.now()+"."+ext;
      var up=await KV.db.storage.from("proofs").upload(path,fl,{contentType:fl.type});if(up.error)throw up.error;
      await rpc("submit_reseller_request",{p_name:F.name.value.trim(),p_phone:F.phone.value.trim(),p_email:F.email.value.trim()||"non renseigné",p_pay_phone:F.pay.value.trim(),p_amount:+F.amount.value,p_proof_path:path});
      toast("Preuve envoyée ✓");try{window.open(waUrl(C.whatsapp,"Bonjour, j’ai effectué mon paiement de 3 000 FCFA pour devenir revendeur KANIS VPN ACADEMY. Nom : "+F.name.value.trim()+" · Téléphone : "+F.phone.value.trim()+" · Numéro de paiement : "+F.pay.value.trim()+". Ma preuve de paiement a été envoyée dans l’application. Merci de me donner mon code d’activation."),"_blank");}catch(e){}await activationView();}catch(x){err.textContent=mapErr(x);}btn.disabled=false;});return f;}
function activatedView(){var b=shell("Félicitations");b.appendChild(h("div",{class:"c"},[h("h3",{},"FÉLICITATIONS ! 🎉"),h("p",{},"Votre compte REVENDEUR KANIS VPN ACADEMY est maintenant activé."),h("p",{},"Bienvenue dans notre réseau de revendeurs ! Vous pouvez maintenant commencer à vendre nos formations."),h("button",{onclick:function(){route();}},"ACCÉDER À MON ESPACE REVENDEUR")]));b.appendChild(giftBlock("reseller"));}
async function activationView(stage){var p=KV.profile,b=shell(p.reseller_status==="suspended"?"Compte suspendu":"Activation du compte revendeur");
  b.appendChild(h("p",{class:"tag"},"Revendeur · INACTIF"));
  if(p.reseller_status==="suspended"){b.appendChild(h("div",{class:"c"},h("p",{},"Votre compte revendeur est suspendu. Contactez l’administration pour le réactiver.")));b.appendChild(waBlock());b.appendChild(logoutBtn());return;}
  try{var rq=await q(KV.db.from("reseller_requests").select("*").eq("user_id",p.id).order("created_at",{ascending:false}).limit(1)),last=rq[0];
    if(last&&last.status==="pending"){b.appendChild(h("div",{class:"c"},[h("h3",{},"Demande en attente de vérification"),h("p",{},"Votre preuve de paiement a été envoyée. L’administrateur la vérifie manuellement, puis vous enverra votre code d’activation sur WhatsApp."),h("button",{class:"alt",onclick:function(){route();}},"Actualiser"),h("a",{href:waUrl(C.whatsapp,"Bonjour, j’ai envoyé ma preuve de paiement de 3 000 FCFA dans l’application KANIS VPN ACADEMY. Merci de me donner mon code d’activation."),target:"_blank",rel:"noopener",style:WAST},"RELANCER SUR WHATSAPP")]));}
    else if(stage==="pay"){b.appendChild(h("div",{class:"c"},[h("h3",{},"Paiement des frais d’activation"),h("p",{},"Montant : "+FMT(3000)),h("p",{},"Opérateur : Orange Money Burkina Faso"),h("p",{class:"num"},USSD),
      h("button",{onclick:function(){copyTxt(USSD);}},"COPIER LE CODE DE PAIEMENT"),h("p",{},"Effectuez votre paiement de 3 000 FCFA avec le code ci-dessus, puis envoyez votre preuve de paiement pour recevoir votre code d’activation."),
      h("button",{onclick:function(){activationView("proof");}},"J’AI EFFECTUÉ LE PAIEMENT")]));}
    else if(stage==="proof"){b.appendChild(h("div",{class:"c"},[h("h3",{},"Envoyer ma preuve de paiement"),proofForm(p)]));}
    else{b.appendChild(h("div",{class:"c"},[h("h3",{},"Devenir revendeur"),h("p",{},"Vous souhaitez devenir revendeur KANIS VPN ACADEMY ? Créez votre compte et payez les frais d’activation de 3 000 FCFA pour rejoindre notre réseau."),
      last&&last.status==="refused"?h("p",{class:"err"},"Votre dernière demande a été refusée."+(last.admin_note?" Motif : "+last.admin_note:"")):null,h("button",{onclick:function(){activationView("pay");}},"DEVENIR REVENDEUR")]));}
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Vous avez reçu votre code d’activation ?"),form([{k:"code",l:"Code d’activation"}],"VALIDER MON CODE",async function(v){await rpc("redeem_reseller_code",{p_code:v.code});prefetchGift("reseller");await loadProfile();activatedView();})]));
  }catch(e){b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},mapErr(e)),h("button",{onclick:function(){activationView();}},"Réessayer")]));}
  b.appendChild(waBlock());b.appendChild(logoutBtn());}

/* ---------- Briques communes ---------- */
function profileCard(){var p=KV.profile;return h("div",{class:"c"},[h("h3",{},"Mon profil"),form([{k:"full_name",l:"Nom",v:p.full_name||""},{k:"phone",l:"Téléphone",t:"tel",v:p.phone||""}],"Enregistrer",async function(v){
  await q(KV.db.from("profiles").update({full_name:v.full_name,phone:v.phone}).eq("id",p.id));toast("Profil mis à jour");})]);}
function payForm(onCreate,extra){var om=(window.CONFIG&&CONFIG.orangeMoney)||"",wv=(window.CONFIG&&CONFIG.wave)||"";
  return form((extra||[]).concat([{k:"provider",l:"Moyen de paiement",opts:[["orange_money","Orange Money"],["wave","Wave"]]},{k:"promo",l:"Code promo (optionnel)"}]),"Valider la commande",async function(v){
    var id=await onCreate(v);alert("Commande enregistrée (réf. "+String(id).slice(0,8)+").\nStatut : EN ATTENTE DE VÉRIFICATION.\nEnvoie le paiement à Orange Money "+om+" / Wave "+wv+" en indiquant cette référence. L’accès n’est débloqué qu’après confirmation réelle du paiement.");dash();});}
function courseOpts(list){return list.map(function(c){return [c.id,c.title+" — "+FMT(c.eff!=null?c.eff:c.price)];});}
function codeReveal(code){var old=document.getElementById("kv-code-ov");if(old)old.remove();
  var ov=h("div",{id:"kv-code-ov",style:"position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,30,.65);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px"});
  var box=h("div",{style:"background:#fff;color:#0a1f5c;border-radius:18px;padding:22px;max-width:380px;width:100%;text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.4)"},[
    h("h3",{style:"margin:0 0 6px"},"Code d’accès généré"),
    h("p",{style:"margin:0 0 10px;font-size:14px"},"Affiché UNE seule fois — copie-le maintenant."),
    h("div",{style:"font:700 26px monospace;letter-spacing:2px;padding:16px 8px;border-radius:12px;background:#eef3ff;color:#0a2a8a;word-break:break-all;-webkit-user-select:all;user-select:all"},String(code||"")),
    h("button",{onclick:function(){copyTxt(String(code||""));}},"COPIER LE CODE"),
    h("a",{href:waUrl("","Voici ton code d’accès KANIS VPN ACADEMY : "+code),target:"_blank",rel:"noopener",style:WAST},"ENVOYER PAR WHATSAPP"),
    h("button",{class:"alt",style:"margin-top:10px",onclick:function(){ov.remove();}},"J’AI COPIÉ LE CODE")]);
  ov.appendChild(box);document.body.appendChild(ov);}

/* ---------- Acheteur ---------- */
function tabsBar(names,cur,set){return tabsUI(names,cur,set,names===BT?BNAV:RNAV);}
function lab(s){return STATUS[s]||s;}
var BT=["Formations","Vidéos","Achats","Paiements","Codes","Alertes","Profil"],btab="Formations";
async function buyerView(b){b.appendChild(tabsBar(BT,btab,function(n){btab=n;}));var d=KV.db,me=KV.profile.id;
  if(btab==="Formations"||btab==="Vidéos"){var cs=await (btab==="Vidéos"?function(x){return x;}:priced)(await q(d.from("courses").select("*").eq("active",true).order("created_at")));
    if(btab==="Vidéos"){var vls=await Promise.all(cs.map(function(cc){return rpc("list_course_videos",{p_slug:cc.slug}).catch(function(){return [];});}));cs.forEach(function(cc,ci){b.appendChild(h("h3",{},cc.title));vidList(cc,vls[ci]||[]).forEach(function(n){b.appendChild(n);});});}
    else{b.appendChild(rows(cs,function(c){return h("div",{class:"c"},[h("b",{},c.title),h("p",{},c.description||""),priceEl(c),KV.has(c.slug)?null:h("a",{href:waUrl(C.whatsapp,"Bonjour, je souhaite acheter la formation "+c.title+" ("+FMT(c.eff!=null?c.eff:c.price)+"). Comment puis-je obtenir mon code d’accès ?"),target:"_blank",rel:"noopener",style:WAST},"📲 OBTENIR LE CODE SUR WHATSAPP"),h("button",{class:"alt",onclick:function(){btab="Vidéos";dash();}},"🎬 Vidéos"),KV.has(c.slug)?h("button",{onclick:function(){open(false);window.KANIS.openCourse(c.slug);}},"▶ Regarder"):h("span",{class:"tag"},"Verrouillée")]);}));
      if(cs.length)b.appendChild(h("div",{class:"c"},[h("h3",{},"Acheter une formation"),payForm(function(v){return rpc("create_order",{p_course:v.course,p_promo:v.promo||null,p_provider:v.provider});},[{k:"course",l:"Formation",opts:courseOpts(cs)}])]));}}
  if(btab==="Achats"){var os=await q(d.from("orders").select("*,courses(title)").eq("buyer_id",me).eq("kind","course").order("created_at",{ascending:false}));
    b.appendChild(rows(os,function(o){return row((o.courses?o.courses.title:"Formation")+" · "+FMT(o.amount)+" · "+new Date(o.created_at).toLocaleDateString("fr-FR"),lab(o.status));}));}
  if(btab==="Paiements"){var ps=await q(d.from("payments").select("*,orders(kind,courses(title))").order("created_at",{ascending:false}).limit(100));
    b.appendChild(rows(ps,function(p){var o=p.orders||{};return row((o.kind==="activation"?"Activation":(o.courses?o.courses.title:"Formation"))+" · "+FMT(p.amount)+" · "+(PROV[p.provider]||p.provider)+(p.reference?" · réf. "+p.reference:""),lab(p.status));}));}
  if(btab==="Codes")b.appendChild(h("div",{class:"c"},[h("h3",{},"J’ai un code d’accès"),form([{k:"code",l:"Code"}],"Débloquer",async function(v){var s=await KV.redeem(v.code);if(s){codeOk();}})]));
  if(btab==="Alertes")b.appendChild(await notifCard());
  if(btab==="Profil")b.appendChild(profileCard());}

/* ---------- Revendeur actif ---------- */
var RT=["Vendre","Ventes","Clients","Codes","Paiement","Profil"],rtab="Vendre";
var OPS=["Orange Money","Moov Money","Telecel Money","Coris Money","Sank Money","Wave","MTN MoMo","Airtel Money","Autre"];
async function resellerView(b){b.appendChild(tabsBar(RT,rtab,function(n){rtab=n;}));var d=KV.db,p=KV.profile;
  function cd(o){return o.access_codes&&o.access_codes[0];}
  if(rtab==="Vendre"||rtab==="Paiement"){var pm=await q(d.from("reseller_payment_methods").select("*").eq("reseller_id",p.id).order("created_at"));
    if(rtab==="Vendre"){var cs=await priced(await q(d.from("courses").select("*").eq("active",true)));
      b.appendChild(h("div",{class:"c"},[h("h3",{},"💳 Mes moyens de paiement")].concat(pm.length?pm.map(function(m){return h("p",{},"📱 "+m.operator+" · "+m.number+" · "+m.holder_name);}):[h("p",{class:"err"},"Aucun moyen de paiement. Ajoute ton numéro pour que tes clients puissent te payer."),h("button",{onclick:function(){rtab="Paiement";dash();}},"Ajouter mon numéro")])));
      b.appendChild(h("div",{class:"c"},[h("h3",{},"Nouvelle vente"),h("p",{class:"tag"},"Le client te paie directement sur ton numéro. Quand tu as reçu l’argent, génère son code."),
        cs.length?form([{k:"course",l:"Formation",opts:courseOpts(cs)},{k:"cname",l:"Nom du client"},{k:"cphone",l:"Téléphone du client (WhatsApp)",t:"tel"},{k:"method",l:"Payé avec",opts:pm.map(function(m){return [m.operator,m.operator+" · "+m.number];}).concat([["Autre","Autre / espèces"]])}],"J’AI REÇU LE PAIEMENT → GÉNÉRER LE CODE",async function(v){
          if(!v.cname)throw new Error("Nom du client requis.");var c=await rpc("reseller_sell",{p_course:v.course,p_client_name:v.cname,p_client_phone:v.cphone||null,p_method:v.method||null});codeReveal(c);
          if(v.cphone&&confirm("Envoyer le code au client sur WhatsApp ?")){var ph=String(v.cphone).replace(/\D/g,"");if(ph.length===8)ph="226"+ph;window.open("https://wa.me/"+ph+"?text="+encodeURIComponent("Bonjour "+v.cname+", voici ton code d’accès KANIS VPN ACADEMY : "+c+"\nEntre-le dans l’application (onglet Codes) pour débloquer ta formation."));}dash();}):h("p",{},"Aucune formation disponible.")]));}
    else{b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter un moyen de paiement"),h("p",{class:"tag"},"Tes clients te paieront sur ce numéro."),form([{k:"op",l:"Opérateur / réseau",opts:OPS.map(function(o){return [o,o];})},{k:"custom",l:"Nom du réseau si « Autre »"},{k:"num",l:"Numéro de paiement",t:"tel"},{k:"holder",l:"Nom du titulaire"},{k:"ins",l:"Instructions (optionnel)"}],"Ajouter",async function(v){
        if(!v.num||!v.holder)throw new Error("Numéro et titulaire requis.");await q(d.from("reseller_payment_methods").insert({reseller_id:p.id,operator:v.op==="Autre"&&v.custom?v.custom:v.op,number:v.num,holder_name:v.holder,instructions:v.ins||null}));dash();})]));
      b.appendChild(rows(pm,function(m){var k=h("div",{class:"c"},[h("b",{},m.operator+" · "+m.number),h("p",{},"Titulaire : "+m.holder_name),h("p",{class:"tag"},m.instructions||"")]);
        k.appendChild(form([{k:"num",l:"Numéro",t:"tel",v:m.number},{k:"holder",l:"Titulaire",v:m.holder_name},{k:"ins",l:"Instructions",v:m.instructions||""}],"Modifier",async function(v){await q(d.from("reseller_payment_methods").update({number:v.num,holder_name:v.holder,instructions:v.ins||null}).eq("id",m.id));dash();}));
        k.appendChild(h("button",{class:"alt",onclick:async function(){if(!confirm("Supprimer ce moyen de paiement ?"))return;await q(d.from("reseller_payment_methods").delete().eq("id",m.id));dash();}},"Supprimer"));return k;}));}}
  if(rtab==="Ventes"||rtab==="Clients"||rtab==="Codes"){var os=await q(d.from("orders").select("*,courses(title),access_codes(hint,status)").eq("reseller_id",p.id).order("created_at",{ascending:false}));
    function st(o){var c=cd(o);return c?"…"+c.hint+" · "+(c.status==="used"?"Utilisé":c.status==="revoked"?"Révoqué":"Non utilisé"):lab(o.status);}
    if(rtab==="Ventes"){b.appendChild(h("h3",{},"Mes ventes ("+os.length+")"));b.appendChild(rows(os,function(o){return row((o.client_name||"Code généré")+" · "+(o.courses?o.courses.title:"")+" · "+FMT(o.amount),st(o));}));}
    if(rtab==="Clients"){var seen={};b.appendChild(rows(os.filter(function(o){if(!o.client_name)return false;var k=o.client_name+"|"+(o.client_phone||"");if(seen[k]){seen[k].n++;return false;}seen[k]={n:1};o._s=seen[k];return true;}),function(o){return row(o.client_name+(o.client_phone?" · "+o.client_phone:""),o._s.n+" achat(s)");}));}
    if(rtab==="Codes"){await resellerCodes(b,d,p);}}
  if(rtab==="Profil"){b.appendChild(profileCard());b.appendChild(await notifCard());}}

async function resellerCodes(b,d,p){var cl=await q(d.from("courses").select("id,title").eq("active",true).order("created_at")),cs=await q(d.from("access_codes").select("hint,status,created_at,courses(title),orders(client_name)").eq("created_by",p.id).order("created_at",{ascending:false}).limit(100));
  async function go(c){try{codeReveal(await rpc("reseller_generate_code",{p_course:c}));dash();}catch(e){toast(e.message);}}
  b.appendChild(h("div",{class:"c"},[h("h3",{},"➕ Générer un code d’accès"),h("p",{class:"tag"},"Choisis la formation")].concat(cl.map(function(c){return h("button",{class:"big","data-c":"b",onclick:function(){go(c.id);}},"🎓 "+c.title);}))));
  b.appendChild(h("h3",{},"Codes générés (jamais stockés en clair)"));
  b.appendChild(rows(cs,function(c){return row((c.courses?c.courses.title:"")+(c.orders&&c.orders.client_name?" · "+c.orders.client_name:"")+" · …"+c.hint,c.status==="used"?"Utilisé":c.status==="revoked"?"Révoqué":"Non utilisé");}));}
async function adminGen(b,d){var cl=await q(d.from("courses").select("id,title").eq("active",true).order("created_at")),rc=await q(d.from("reseller_codes").select("hint,status").order("created_at",{ascending:false}).limit(50));
  async function go(kind,course){try{codeReveal(await rpc("admin_generate_code",{p_kind:kind,p_course:course||null}));dash();}catch(e){toast(e.message);}}
  b.appendChild(h("div",{class:"c"},[h("h3",{},"➕ Générer un code"),h("p",{class:"tag"},"Choisis le type de code")].concat(cl.map(function(c){return h("button",{class:"big","data-c":"b",onclick:function(){go("course",c.id);}},"🎓 "+c.title);})).concat([h("button",{class:"big","data-c":"y",onclick:function(){go("reseller");}},"🧑‍💼 Code d’accès revendeur")])));
  b.appendChild(h("h3",{},"Codes revendeurs"));b.appendChild(rows(rc,function(c){return row("RV-"+(c.hint?"… "+c.hint:"(demande)"),c.status==="used"?"Utilisé":c.status==="revoked"?"Révoqué":"Non utilisé");}));}
/* ---------- Administrateur ---------- */
var ATABS=["Acheteurs","Revendeurs","Demandes revendeurs","Réinitialiser accès","Formations","Vidéos","Prix","Promotions","Promotion des prix","Paiements","Codes","Notifications","Réglages"],atab="Demandes revendeurs";
async function adminView(b){b.appendChild(tabsUI(ATABS,atab,function(n){atab=n;},ANAV));var d=KV.db;
  if(atab==="Stats"){var s=await rpc("admin_stats");b.appendChild(h("div",{class:"k"},[["Acheteurs",s.buyers],["Revendeurs",s.resellers],["Ventes",s.sales],["Chiffre d’affaires",FMT(s.revenue)],["Commissions",FMT(s.commissions)],["Revenus académie",FMT(s.academy)]].map(function(x){return h("div",{class:"c"},[x[0],h("b",{},x[1])]);})));}
  if(atab==="Acheteurs"||atab==="Revendeurs"){var us=await q(d.from("profiles").select("*").in("role",atab==="Acheteurs"?["buyer","admin"]:["reseller"]).order("created_at",{ascending:false}).limit(200));b.appendChild(rows(us,function(u){var r=h("div",{class:"row"},[h("span",{},(u.full_name||u.email||"Sans nom · "+String(u.id).slice(0,6))+" · "+u.role+(u.role==="reseller"?" ("+u.reseller_status+")":"")),h("span",{})]);
    if(u.id!==KV.profile.id)r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){var n=prompt("Nouveau rôle pour "+(u.full_name||u.email||"Sans nom · "+String(u.id).slice(0,6))+" : buyer, reseller ou admin",u.role);if(!n)return;try{await rpc("admin_set_role",{p_user:u.id,p_role:n.trim()});dash();}catch(e){toast(e.message);}}},"Rôle"));
    if(u.role==="reseller")r.lastChild.appendChild(h("button",{onclick:async function(){try{await rpc("admin_set_reseller",{p_user:u.id,p_status:u.reseller_status==="active"?"suspended":"active"});dash();}catch(e){toast(e.message);}}},u.reseller_status==="active"?"Suspendre":"Activer"));return r;}));}
  if(atab==="Formations"){var cs=await q(d.from("courses").select("*").order("created_at"));b.appendChild(rows(cs,function(c){return h("div",{class:"c"},[form([{k:"title",l:"Titre",v:c.title},{k:"description",l:"Description",v:c.description||""},{k:"price",l:"Prix (FCFA)",t:"number",v:c.price},{k:"cover_url",l:"Image (URL)",v:c.cover_url||""},{k:"active",l:"Statut",opts:[["true","Actif"],["false","Inactif"]],v:String(c.active)}],"Enregistrer",async function(v){
      await q(d.from("courses").update({title:v.title,description:v.description,price:+v.price,cover_url:v.cover_url,active:v.active==="true"}).eq("id",c.id));toast("Enregistré");}),
      h("button",{class:"alt",onclick:async function(){if(confirm("Supprimer cette formation ?")){try{await q(d.from("courses").delete().eq("id",c.id));dash();}catch(e){toast(e.message);}}}},"Supprimer")]);}));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter une formation"),form([{k:"slug",l:"Identifiant (ex: nouveau-tunnel)"},{k:"title",l:"Titre"},{k:"price",l:"Prix",t:"number",v:"2500"}],"Ajouter",async function(v){await q(d.from("courses").insert({slug:v.slug,title:v.title,price:+v.price}));dash();})]));}
  if(atab==="Vidéos"){var cs2=await q(d.from("courses").select("id,title")),vs=await q(d.from("videos").select("*,courses(title)").order("position")),chs=await q(d.from("chapters").select("*,courses(title)"));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter un chapitre"),form([{k:"course",l:"Formation",opts:cs2.map(function(c){return [c.id,c.title];})},{k:"title",l:"Titre du chapitre"}],"Ajouter",async function(v){await q(d.from("chapters").insert({course_id:v.course,title:v.title}));dash();})]));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter une vidéo"),vidForm(cs2,chs)]));
    b.appendChild(rows(vs,function(v){var k=h("div",{class:"c"},[h("b",{},(v.courses?v.courses.title+" · ":"")+v.title+(v.is_active?"":" (désactivée)")),h("p",{},v.description||"")]);
      k.appendChild(form([{k:"title",l:"Titre",v:v.title},{k:"description",l:"Description détaillée",v:v.description||""},{k:"pos",l:"Ordre d’affichage",t:"number",v:String(v.position||0)}],"Enregistrer",async function(x){await q(d.from("videos").update({title:x.title,description:x.description,position:+x.pos}).eq("id",v.id));toast("Enregistré");}));
      k.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("videos").update({is_active:!v.is_active}).eq("id",v.id));dash();}},v.is_active?"Désactiver":"Activer"));
      k.appendChild(h("button",{class:"alt",onclick:async function(){if(!confirm("Supprimer cette vidéo ?"))return;await q(d.from("videos").delete().eq("id",v.id));dash();}},"Supprimer"));return k;}));}
  if(atab==="Demandes revendeurs"){
    if(KV.lastCode){var lc=KV.lastCode;b.appendChild(h("div",{class:"c"},[h("h3",{},"Code d’activation généré"),h("p",{class:"num"},lc.code),h("p",{class:"tag"},"Affiché une seule fois. Copiez-le et envoyez-le à "+lc.name+" sur WhatsApp."),h("button",{onclick:function(){copyTxt(lc.code);}},"COPIER LE CODE"),
      h("a",{href:waUrl(lc.phone,"Bonjour "+lc.name+", voici votre code d’activation revendeur KANIS VPN ACADEMY : "+lc.code),target:"_blank",rel:"noopener",style:WAST},"ENVOYER SUR WHATSAPP"),h("button",{class:"alt",onclick:function(){KV.lastCode=null;dash();}},"Fermer")]));}
    var rqs=await q(d.from("reseller_requests").select("*").order("created_at",{ascending:false}).limit(100));
    var sg=await Promise.all(rqs.map(function(r){return KV.db.storage.from("proofs").createSignedUrl(r.proof_path,300);}));
    b.appendChild(rows(rqs,function(r,i){var u=sg[i]&&sg[i].data&&sg[i].data.signedUrl,c=h("div",{class:"c"},[h("b",{},r.full_name+" · "+({pending:"EN ATTENTE",approved:"ACCEPTÉE",refused:"REFUSÉE"}[r.status]||r.status)),
        h("p",{},"Tél : "+r.phone+" · E-mail : "+r.email),h("p",{},"Payé depuis : "+r.pay_phone+" · "+FMT(r.amount)+" · "+new Date(r.created_at).toLocaleDateString("fr-FR")),u?h("a",{href:u,target:"_blank",rel:"noopener"},"Voir la preuve de paiement"):h("p",{class:"tag"},"Preuve indisponible")]);
      if(r.status==="pending"){c.appendChild(h("button",{onclick:async function(){if(!confirm("Avez-vous vérifié manuellement ce paiement sur votre compte Orange Money ?"))return;try{var code=await rpc("admin_review_request",{p_id:r.id,p_decision:"approved"});KV.lastCode={code:code,name:r.full_name,phone:r.phone};dash();}catch(e){toast(mapErr(e));}}},"ACCEPTER ET GÉNÉRER LE CODE"));
        c.appendChild(h("button",{class:"alt",onclick:async function(){var n=prompt("Motif du refus (optionnel)","");if(n===null)return;try{await rpc("admin_review_request",{p_id:r.id,p_decision:"refused",p_note:n||null});dash();}catch(e){toast(mapErr(e));}}},"REFUSER"));}
      return c;}));}
  if(atab==="Promotion des prix"){var cs4=await q(d.from("courses").select("id,title,price")),pp=await q(d.from("price_promos").select("*,courses(title,price)").order("created_at",{ascending:false}));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Nouvelle promotion de prix"),form([{k:"course",l:"Formation",opts:cs4.map(function(c){return [c.id,c.title+" — "+FMT(c.price)];})},{k:"price",l:"Prix promotionnel (FCFA)",t:"number"},{k:"starts",l:"Début",t:"datetime-local"},{k:"ends",l:"Fin",t:"datetime-local"}],"Créer",async function(v){
      if(!v.price||!v.ends)throw new Error("Prix et date de fin requis.");await q(d.from("price_promos").insert({course_id:v.course,promo_price:+v.price,starts_at:v.starts?new Date(v.starts).toISOString():null,ends_at:new Date(v.ends).toISOString()}));dash();})]));
    b.appendChild(rows(pp,function(x){var r=row((x.courses?x.courses.title:"")+" · "+FMT(x.promo_price)+" (au lieu de "+FMT(x.courses?x.courses.price:0)+") · fin "+new Date(x.ends_at).toLocaleDateString("fr-FR"),"");
      r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("price_promos").update({active:!x.active}).eq("id",x.id));dash();}},x.active?"Désactiver":"Activer"));
      r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("price_promos").delete().eq("id",x.id));dash();}},"Supprimer"));return r;}));}
  if(atab==="Réinitialiser accès"){
    if(KV.lastReset){var lr=KV.lastReset;b.appendChild(h("div",{class:"c"},[h("h3",{},"Accès initialisé ✓"),h("p",{},lr.email),h("p",{class:"tag"},"Aucun mot de passe n’est communiqué : le client choisit lui-même le sien (valable 24 h). Dis-lui d’ouvrir l’application → Connexion → « Mot de passe oublié ? »."),
      h("a",{href:waUrl(lr.phone,"Bonjour, votre accès KANIS VPN ACADEMY est initialisé. Ouvrez l’application, touchez Connexion puis « Mot de passe oublié ? », saisissez votre e-mail et votre numéro, et choisissez votre nouveau mot de passe (valable 24 h)."),target:"_blank",rel:"noopener",style:WAST},"PRÉVENIR LE CLIENT SUR WHATSAPP"),h("button",{class:"alt",onclick:function(){KV.lastReset=null;dash();}},"Fermer")]));}
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Initialiser l’accès d’un client"),form([{k:"email",l:"E-mail du client",t:"email"}],"INITIALISER",async function(v){
      var em=(v.email||"").trim();if(!em)throw new Error("Saisis l’e-mail du client.");if(!confirm("Initialiser l’accès de "+em+" ? Son ancien mot de passe sera invalidé."))return;
      await rpc("admin_init_reset",{p_email:em});var ph="";
      try{var pr=await q(d.from("profiles").select("phone").ilike("email",em).limit(1));ph=(pr[0]&&pr[0].phone)||"";}catch(e){}
      KV.lastReset={email:em,phone:ph};dash();})]));}
  if(atab==="Promotions"){var cs3=await q(d.from("courses").select("id,title")),pr=await q(d.from("promotions").select("*").order("code"));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Nouvelle promotion"),form([{k:"code",l:"Code promotionnel"},{k:"kind",l:"Type",opts:[["percent","Pourcentage"],["fixed","Réduction fixe (FCFA)"]]},{k:"value",l:"Valeur",t:"number"},{k:"starts",l:"Début",t:"datetime-local"},{k:"ends",l:"Expiration",t:"datetime-local"},{k:"max",l:"Utilisations max (vide = illimité)",t:"number"},
      {k:"scope",l:"Concerne",opts:[["all","Toutes les formations"]].concat(cs3.map(function(c){return [c.id,c.title];})).concat([["activation","Activation revendeur"]])}],"Créer",async function(v){
      await q(d.from("promotions").insert({code:v.code.toUpperCase(),kind:v.kind,value:+v.value,starts_at:v.starts?new Date(v.starts).toISOString():null,ends_at:v.ends?new Date(v.ends).toISOString():null,max_uses:v.max?+v.max:null,
        course_ids:v.scope==="all"||v.scope==="activation"?[]:[v.scope],applies_to_activation:v.scope==="activation"}));dash();})]));
    b.appendChild(rows(pr,function(p){var r=row(p.code+" · "+(p.kind==="percent"?p.value+" %":FMT(p.value))+(p.applies_to_activation?" · activation revendeur":"")+" · "+p.uses+"/"+(p.max_uses||"∞"),"");
      r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("promotions").update({active:!p.active}).eq("id",p.id));dash();}},p.active?"Désactiver":"Activer"));return r;}));}
  if(atab==="Prix"){var cp=await q(d.from("courses").select("id,title,price").order("created_at")),sp=await q(d.from("settings").select("*").in("key",["reseller_activation_price","reseller_share_percent"]));
    b.appendChild(h("h3",{},"Prix des formations"));cp.forEach(function(c){b.appendChild(h("div",{class:"c"},form([{k:"price",l:c.title+" (FCFA)",t:"number",v:c.price}],"Enregistrer",async function(v){if(!(+v.price>=0))throw new Error("Prix invalide");await q(d.from("courses").update({price:+v.price}).eq("id",c.id));toast("Prix enregistré");})));});
    b.appendChild(h("h3",{},"Activation revendeur et commissions"));sp.forEach(function(s){b.appendChild(h("div",{class:"c"},form([{k:"v",l:s.key==="reseller_activation_price"?"Prix d’activation revendeur (FCFA)":"Part du revendeur (%)",t:"number",v:s.value}],"Enregistrer",async function(v){if(!(+v.v>=0))throw new Error("Valeur invalide");await q(d.from("settings").update({value:String(+v.v)}).eq("key",s.key));toast("Enregistré");})));});}
  if(atab==="Commissions"){var cmx=await q(d.from("commissions").select("*,profiles(full_name,email),orders(amount,courses(title))").order("created_at",{ascending:false}).limit(200));
    b.appendChild(h("p",{class:"tag"},"Total revendeurs : "+FMT(cmx.reduce(function(s,c){return s+c.reseller_amount;},0))+" · Académie : "+FMT(cmx.reduce(function(s,c){return s+c.academy_amount;},0))));
    b.appendChild(rows(cmx,function(c){var o=c.orders||{},p=c.profiles||{};return row((p.full_name||p.email||"")+" · "+(o.courses?o.courses.title:"")+" · vente "+FMT(o.amount),FMT(c.reseller_amount)+" / "+FMT(c.academy_amount));}));}
  if(atab==="Paiements"){var ps=await q(d.from("payments").select("*,orders(amount,kind,client_name,courses(title),profiles!orders_buyer_id_fkey(full_name,email))").order("created_at",{ascending:false}).limit(200));
    b.appendChild(rows(ps,function(p){var o=p.orders||{},r=h("div",{class:"row"},[h("span",{},String(p.id).slice(0,8)+" · "+(o.kind==="activation"?"Activation":(o.courses?o.courses.title:""))+" · "+FMT(p.amount)+" · "+p.provider+" · "+p.status),h("span",{})]);
      var act=function(l,fn,alt){r.lastChild.appendChild(h("button",{class:alt?"alt":"",onclick:async function(){try{await fn();dash();}catch(e){toast(e.message);}}},l));};
      if(p.status==="pending"){act("Confirmer",function(){var ref=prompt("Référence de la transaction (SMS Orange Money / Wave) :");if(!ref)throw new Error("Référence requise");return rpc("confirm_payment",{p_payment:p.id,p_reference:ref});});act("Refuser",function(){return rpc("refuse_payment",{p_payment:p.id});},1);}
      if(p.status==="confirmed")act("Rembourser",function(){if(!confirm("Rembourser et annuler commission/accès ?"))throw new Error("Annulé");return rpc("refuse_payment",{p_payment:p.id,p_refund:true});},1);return r;}));}
  if(atab==="Codes"){await adminGen(b,d);var os=await q(d.from("orders").select("id,client_name,amount,courses(title)").eq("status","confirmed").eq("kind","course")),cd=await q(d.from("access_codes").select("*,courses(title)").order("created_at",{ascending:false}).limit(200)),used={};cd.forEach(function(c){used[c.order_id]=1;});
    b.appendChild(h("h3",{},"Commandes confirmées sans code"));b.appendChild(rows(os.filter(function(o){return !used[o.id];}),function(o){var r=row((o.client_name||"")+" · "+(o.courses?o.courses.title:"")+" · "+FMT(o.amount),"");r.lastChild.appendChild(h("button",{onclick:async function(){try{codeReveal(await rpc("generate_code",{p_order:o.id}));dash();}catch(e){toast(e.message);}}},"Générer"));return r;}));
    b.appendChild(h("h3",{},"Codes générés (valeur jamais stockée en clair)"));b.appendChild(rows(cd,function(c){return row((c.courses?c.courses.title:"")+" · …"+c.hint,c.status);}));}
  if(atab==="Notifications")b.appendChild(h("div",{class:"c"},[form([{k:"title",l:"Titre"},{k:"body",l:"Message"}],"Envoyer à tous",async function(v){await q(d.from("notifications").insert({user_id:null,title:v.title,body:v.body}));toast("Notification publiée");})]));
  if(atab==="Réglages"){var st=await q(d.from("settings").select("*"));b.appendChild(rows(st,function(s){return h("div",{class:"c"},[form([{k:"v",l:s.key,v:s.value}],"Enregistrer",async function(v){await q(d.from("settings").update({value:v.v}).eq("key",s.key));toast("Enregistré");})]);}));}}

/* ---------- Tableau de bord (acheteur / revendeur actif / administrateur) ---------- */
function dashHead(r){var hd=head({buyer:"Espace acheteur",reseller:"Espace revendeur",admin:"Administration"}[r.role]);hd.appendChild(h("button",{class:"mb","aria-label":"Menu",onclick:menu},"☰"));hd.insertBefore(hello(),hd.querySelector(".fl"));return hd;}
function curTab(){var p=KV.profile;return p?(p.role==="admin"?atab:p.role==="reseller"?rtab:btab):"";}
function findNav(b){for(var i=0;i<b.children.length;i++)if(b.children[i].__nav)return b.children[i].__nav;return null;}
function skel(r){var s=h("div",{class:"in"});s.appendChild(r?dashHead(r):head("Chargement…"));s.appendChild(h("div",{class:"c sk"},[h("i",{class:"skl l"}),h("i",{class:"skl"}),h("i",{class:"skl s"})]));return s;}
/* dash(soft) : l’écran s’affiche tout de suite (version en mémoire ou squelette), les données se rechargent ensuite en arrière-plan. */
async function dash(soft){
  if(!KV.session){welcome();return;}
  stopPoll();
  var tok=++KV.tok,p0=KV.profile,key=p0?p0.role+"|"+curTab():"",hit=key&&KV.cache[key],
      same=KV.screen==="dash"&&KV.mounted===key&&!!root.querySelector(":scope > .in");
  root.className="kv";
  if(!same){
    var oldNav=root.querySelector(":scope > .bn");
    root.textContent="";root.appendChild(tunnel());
    if(hit){root.appendChild(hit.b);if(hit.nav){navMark(hit.nav,curTab());root.appendChild(hit.nav);}}
    else{root.appendChild(skel(p0));if(oldNav&&p0&&KV.navRole===p0.role){navMark(oldNav,curTab());root.appendChild(oldNav);}}
    root.scrollTop=0;KV.screen="dash";KV.mounted=key;
  }
  open(true);
  var b=h("div",{class:"in"}),ok=false,r=p0;
  try{
    var rp=(soft&&Date.now()-(KV.accAt||0)<15000)?null:KV.refresh().then(function(){KV.accAt=Date.now();});
    if(!(soft&&p0&&Date.now()-(KV.profAt||0)<15000))r=await loadProfile();
    if(tok!==KV.tok)return;
    KV.profile=r;KV.profAt=Date.now();
    if(r.role==="reseller"&&r.reseller_status!=="active"){KV.locked=true;await activationView();return;}
    KV.locked=false;
    if(rp)await rp;
    b.appendChild(dashHead(r));
    b.appendChild(h("p",{class:"tag"},(r.full_name||r.email||"Mon espace")+" · "+{buyer:"Acheteur",reseller:"Revendeur actif",admin:"Administrateur"}[r.role]));
    b.appendChild(h("button",{class:"alt",onclick:function(){open(false);}},"▶ Accéder aux formations et outils"));
    if(r.role==="admin")await adminView(b);else if(r.role==="reseller")await resellerView(b);else await buyerView(b);
    if(r.role==="admin")b.appendChild(await notifCard());
    if({buyer:btab==="Profil",reseller:rtab==="Profil",admin:atab==="Réglages"}[r.role]){b.appendChild(logoutBtn());b.appendChild(madeBy());}
    ok=true;
  }catch(e){b.appendChild(h("p",{class:"err"},mapErr(e)));b.appendChild(h("button",{onclick:function(){route();}},"Réessayer"));b.appendChild(logoutBtn());}
  if(tok!==KV.tok)return;
  if(!ok&&soft&&(hit||same))return;                       // hors ligne : on garde l’écran déjà affiché
  var key2=KV.profile?KV.profile.role+"|"+curTab():key,nav=findNav(b);
  if(ok&&key2)KV.cache[key2]={b:b,nav:nav};
  var ae=document.activeElement;
  if(soft&&same&&ae&&root.contains(ae)&&/^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName))return;   // ne jamais effacer ce que la personne tape
  var st=root.scrollTop,oi=root.querySelector(":scope > .in"),on=root.querySelector(":scope > .bn");
  if(oi)oi.replaceWith(b);else root.appendChild(b);
  if(nav){if(on)on.replaceWith(nav);else root.appendChild(nav);KV.navRole=KV.profile&&KV.profile.role;}
  KV.mounted=key2;if(same||hit)root.scrollTop=st;
}
KV.openAccount=function(){if(KV.session&&KV.profile&&!KV.locked){open(true);dash();}else route();};
/* Retour matériel Android : navigation dans les onglets du compte, puis retour
   à l’accueil public. Un revendeur non activé reste sur l’écran d’activation. */
function appPlug(){try{var Cap=window.Capacitor,A=Cap&&Cap.Plugins&&Cap.Plugins.App;if(!A&&Cap&&typeof Cap.registerPlugin==="function")A=Cap.registerPlugin("App");return A;}catch(e){return null;}}
KV.exit=function(){var A=appPlug();if(A&&A.exitApp)A.exitApp();};
KV.handleBack=function(){
  if(root.hidden)return false;
  if(root.querySelector(".dw")){closeMenu();return true;}                    // 1. menu ☰ ouvert : on le ferme
  var pr=KV.profile;
  if(KV.screen==="welcome"){KV.exit();return true;}                         // 2. écran d’accueil des comptes : on quitte
  if(!KV.session){welcome();return true;}                                    // 3. connexion / inscription : retour à l’accueil
  if(pr&&pr.role==="reseller"&&pr.reseller_status!=="active"){               // 4. revendeur non activé : double appui pour quitter
    if(Date.now()-(KV.lastBack||0)<2000){KV.exit();return true;}
    KV.lastBack=Date.now();toast("L’activation est obligatoire. Appuie encore sur Retour pour quitter.");return true;}
  if(KV.screen==="sub"){dash(true);return true;}                             // 5. sous-écran : retour au tableau de bord
  if(pr&&pr.role==="buyer"&&btab!==BT[0]){btab=BT[0];dash(true);return true;}
  if(pr&&pr.role==="reseller"&&rtab!==RT[0]){rtab=RT[0];dash(true);return true;}
  if(pr&&pr.role==="admin"&&atab!==ATABS[0]){atab=ATABS[0];dash(true);return true;}
  open(false);                                                               // 6. premier onglet : retour à l’application publique
  if(window.KANIS&&typeof window.KANIS.show==="function")window.KANIS.show("home");
  return true;
};

/* ---------- Démarrage ---------- */
function addMenu(){var d=document.getElementById("drawer");if(!d)return;d.appendChild(h("button",{type:"button",style:"margin:12px;padding:12px;border-radius:12px;border:0;font-weight:700;background:var(--accent);color:var(--accent-ink)",onclick:function(){var m=document.getElementById("scrim");if(m)m.click();KV.openAccount();}},"👤 Mon compte"));}
function hideSplash(){var s=document.getElementById("kvSplash");if(s){s.classList.add("out");setTimeout(function(){if(s.parentNode)s.parentNode.removeChild(s);},300);}}
function boot(){var t0=Date.now(),done=function(){setTimeout(hideSplash,Math.max(0,600-(Date.now()-t0)));};addMenu();KV.locked=true;
  if(!C.url||!C.anonKey||!window.supabase){var b=shell("Configuration manquante");b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},"Le serveur Supabase n’est pas configuré (www/js/config.js) ou la bibliothèque supabase.js est absente (npm run vendor)."),h("button",{onclick:function(){location.reload();}},"Réessayer")]));KV.openAccount=function(){};done();return;}
  KV.on=true;KV.db=window.supabase.createClient(C.url,C.anonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:!NATIVE}});
  wireDeepLinks();
  KV.db.auth.onAuthStateChange(function(ev,s){KV.session=s;
    if(ev==="SIGNED_OUT"&&!KV.leaving)setTimeout(function(){KV.cache={};KV.mounted=null;KV.profile=null;KV.access=[];KV.locked=true;welcome();},0);
    if(ev==="PASSWORD_RECOVERY")setTimeout(recoveryView,0);});
  KV.db.auth.getSession().then(function(r){KV.session=r.data.session;return route();}).catch(function(e){var b=shell("Démarrage impossible");b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},mapErr(e)),h("button",{onclick:function(){location.reload();}},"Réessayer")]));}).then(done);}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
})();
