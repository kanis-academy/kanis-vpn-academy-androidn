-- ============================================================================
-- KANIS VPN ACADEMY - INSTALLATION COMPLÈTE EN UNE SEULE FOIS (migrations 001 à 006)
-- À coller entièrement dans Supabase > SQL Editor, puis Run (une seule fois).
-- ATTENTION : ce script EFFACE d'abord toutes les tables de l'application (schéma "public")
-- puis les recrée. Les comptes de connexion (Authentication > Users) ne sont pas supprimés.
-- À utiliser tant que l'application ne contient aucune vraie donnée.
-- ============================================================================
drop trigger if exists on_auth_user_created on auth.users;
drop policy if exists proofs_ins on storage.objects;
drop policy if exists proofs_sel on storage.objects;
drop policy if exists videos_admin on storage.objects;
drop policy if exists videos_sel on storage.objects;
drop schema if exists public cascade;
create schema public;
grant usage on schema public to postgres, anon, authenticated, service_role;
grant all on schema public to postgres, service_role;
alter default privileges in schema public grant all on tables to postgres, anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to postgres, anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to postgres, anon, authenticated, service_role;


-- ===== 001_kanis_schema.sql =====
-- KANIS VPN ACADEMY — schéma Supabase (à exécuter dans SQL Editor, une seule fois)
create extension if not exists pgcrypto;

-- ===== Paramètres =====
create table public.settings(key text primary key, value text not null);
insert into public.settings values ('reseller_activation_price','3000'),('reseller_share_percent','90'),('default_course_price','2500');

-- ===== Profils =====
create table public.profiles(
  id uuid primary key references auth.users on delete cascade,
  email text, full_name text, phone text,
  role text not null default 'buyer' check (role in ('buyer','reseller','admin')),
  reseller_status text not null default 'none' check (reseller_status in ('none','pending','active','suspended')),
  balance int not null default 0,
  created_at timestamptz default now());

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public,extensions as
$$ select exists(select 1 from profiles where id=auth.uid() and role='admin') $$;

-- Le rôle n'est JAMAIS lu depuis les métadonnées envoyées par le client.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public,extensions as $$
begin
  insert into profiles(id,email,full_name,phone,role,reseller_status)
  values(new.id,new.email,left(new.raw_user_meta_data->>'full_name',80),left(new.raw_user_meta_data->>'phone',30),
    case when new.raw_user_meta_data->>'want_reseller'='true' then 'reseller' else 'buyer' end,
    case when new.raw_user_meta_data->>'want_reseller'='true' then 'pending' else 'none' end);
  return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- ===== Catalogue =====
create table public.courses(id uuid primary key default gen_random_uuid(), slug text unique not null, title text not null,
  description text, price int not null default 2500 check(price>=0), cover_url text, active boolean default true, created_at timestamptz default now());
create table public.chapters(id uuid primary key default gen_random_uuid(), course_id uuid references courses on delete cascade, title text not null, position int default 0);
create table public.videos(id uuid primary key default gen_random_uuid(), course_id uuid references courses on delete cascade,
  chapter_id uuid references chapters on delete set null, title text not null, url text not null, position int default 0);
insert into courses(slug,title,description,price) values
 ('dark-tunnel','DARK TUNNEL','Formation DARK TUNNEL',2500),('bkcbebe-tunnel','BKCBEBE TUNNEL','Formation BKCBEBE TUNNEL',2500);

-- ===== Promotions (système UNIQUE, y compris activation revendeur) =====
create table public.promotions(id uuid primary key default gen_random_uuid(), code text unique not null,
  kind text not null check(kind in ('percent','fixed')), value int not null check(value>0),
  starts_at timestamptz, ends_at timestamptz, max_uses int, uses int not null default 0,
  course_ids uuid[] not null default '{}', applies_to_activation boolean not null default false, active boolean not null default true);

-- ===== Commandes, paiements, commissions, codes =====
create table public.orders(id uuid primary key default gen_random_uuid(), buyer_id uuid references profiles, reseller_id uuid references profiles,
  course_id uuid references courses, kind text not null default 'course' check(kind in ('course','activation')),
  client_name text, client_phone text, amount int not null, promo_code text,
  status text not null default 'pending' check(status in ('pending','confirmed','refused','refunded')), created_at timestamptz default now());
create table public.payments(id uuid primary key default gen_random_uuid(), order_id uuid references orders on delete cascade,
  provider text not null check(provider in ('orange_money','wave','manual')), reference text, amount int not null,
  status text not null default 'pending' check(status in ('pending','confirmed','refused','refunded')),
  created_at timestamptz default now(), confirmed_at timestamptz, confirmed_by uuid);
create table public.commissions(id uuid primary key default gen_random_uuid(), reseller_id uuid references profiles, order_id uuid unique references orders,
  reseller_amount int not null, academy_amount int not null, created_at timestamptz default now());
create table public.access_codes(id uuid primary key default gen_random_uuid(), code_hash text unique not null, hint text,
  course_id uuid not null references courses, order_id uuid not null unique references orders, created_by uuid,
  status text not null default 'unused' check(status in ('unused','used','revoked')), used_by uuid, used_at timestamptz, created_at timestamptz default now());
create table public.enrollments(user_id uuid references profiles on delete cascade, course_id uuid references courses, order_id uuid references orders,
  primary key(user_id,course_id));
create table public.notifications(id uuid primary key default gen_random_uuid(), user_id uuid references profiles, title text, body text, created_at timestamptz default now());

-- ===== RLS =====
alter table settings enable row level security; alter table profiles enable row level security; alter table courses enable row level security;
alter table chapters enable row level security; alter table videos enable row level security; alter table promotions enable row level security;
alter table orders enable row level security; alter table payments enable row level security; alter table commissions enable row level security;
alter table access_codes enable row level security; alter table enrollments enable row level security; alter table notifications enable row level security;

create policy s_read on settings for select using (key in ('reseller_activation_price','default_course_price') or is_admin());
create policy s_admin on settings for all using (is_admin()) with check (is_admin());
create policy p_self on profiles for select using (id=auth.uid() or is_admin());
create policy p_upd on profiles for update using (id=auth.uid()) with check (id=auth.uid());
revoke update on profiles from authenticated, anon;
grant update(full_name,phone) on profiles to authenticated;      -- rôle, statut et solde: modifiables uniquement par fonctions serveur / admin RPC
create policy c_read on courses for select using (active or is_admin());
create policy c_admin on courses for all using (is_admin()) with check (is_admin());
create policy ch_read on chapters for select using (true);
create policy ch_admin on chapters for all using (is_admin()) with check (is_admin());
create policy v_admin on videos for all using (is_admin()) with check (is_admin());   -- les vidéos ne sont lisibles que via get_course_videos()
create policy pr_admin on promotions for all using (is_admin()) with check (is_admin());
create policy o_read on orders for select using (buyer_id=auth.uid() or reseller_id=auth.uid() or is_admin());
create policy pay_read on payments for select using (is_admin() or exists(select 1 from orders o where o.id=order_id and (o.buyer_id=auth.uid() or o.reseller_id=auth.uid())));
create policy cm_read on commissions for select using (reseller_id=auth.uid() or is_admin());
create policy ac_read on access_codes for select using (created_by=auth.uid() or is_admin());
create policy en_read on enrollments for select using (user_id=auth.uid() or is_admin());
create policy n_read on notifications for select using (user_id=auth.uid() or user_id is null or is_admin());
create policy n_admin on notifications for all using (is_admin()) with check (is_admin());
-- Aucune politique d'écriture sur orders/payments/commissions/access_codes/enrollments : tout passe par les fonctions ci-dessous.

-- ===== Prix (toujours calculé côté serveur) =====
create or replace function public.price_for(p_course uuid, p_promo text, p_activation boolean default false) returns int
language plpgsql stable security definer set search_path=public,extensions as $$
declare base int; pr promotions; res int;
begin
  if p_activation then select value::int into base from settings where key='reseller_activation_price';
  else select price into base from courses where id=p_course and active; end if;
  if base is null then raise exception 'Formation introuvable'; end if;
  if p_promo is null or p_promo='' then return base; end if;
  select * into pr from promotions where upper(code)=upper(p_promo) and active
     and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now())
     and (max_uses is null or uses<max_uses)
     and ((p_activation and applies_to_activation) or (not p_activation and (course_ids='{}' or p_course=any(course_ids))));
  if not found then return base; end if;
  res := case when pr.kind='percent' then base - base*least(pr.value,100)/100 else greatest(base-pr.value,0) end;
  return res; end $$;

-- Prix d'activation affiché pendant l'inscription (promo automatique : la plus avantageuse en cours, sans code)
create or replace function public.activation_quote() returns json language plpgsql stable security definer set search_path=public,extensions as $$
declare base int; best int; begin
  select value::int into base from settings where key='reseller_activation_price';
  select min(case when kind='percent' then base-base*least(value,100)/100 else greatest(base-value,0) end) into best from promotions
   where active and applies_to_activation and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now()) and (max_uses is null or uses<max_uses);
  return json_build_object('base',base,'final',coalesce(best,base)); end $$;

-- ===== Commandes =====
create or replace function public.create_order(p_course uuid, p_promo text default null, p_provider text default 'manual', p_client_name text default null, p_client_phone text default null)
returns uuid language plpgsql security definer set search_path=public,extensions as $$
declare oid uuid; amt int; me profiles; rid uuid; begin
  select * into me from profiles where id=auth.uid(); if not found then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','wave','manual') then raise exception 'Fournisseur invalide'; end if;
  amt := price_for(p_course,p_promo,false);
  if me.role='reseller' and me.reseller_status='active' and p_client_name is not null then rid:=me.id; end if;
  insert into orders(buyer_id,reseller_id,course_id,client_name,client_phone,amount,promo_code) values(case when rid is null then me.id end,rid,p_course,p_client_name,p_client_phone,amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

create or replace function public.request_activation(p_promo text default null, p_provider text default 'manual') returns uuid
language plpgsql security definer set search_path=public,extensions as $$
declare oid uuid; amt int; begin
  if not exists(select 1 from profiles where id=auth.uid() and role='reseller' and reseller_status='pending') then raise exception 'Non autorisé'; end if;
  amt := price_for(null,p_promo,true);
  insert into orders(buyer_id,kind,amount,promo_code) values(auth.uid(),'activation',amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt); return oid; end $$;

-- ===== Confirmation (admin ou webhook via service_role) =====
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public,extensions as $$
declare pay payments; o orders; share int; rc int; begin
  if not (is_admin() or auth.role()='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  update payments set status='confirmed', reference=coalesce(p_reference,reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then update profiles set reseller_status='active' where id=o.buyer_id;
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    rc := o.amount*share/100;
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);
    update profiles set balance=balance+rc where id=o.reseller_id;
  else insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing; end if;
  insert into notifications(user_id,title,body) values(coalesce(o.buyer_id,o.reseller_id),'Paiement confirmé','Votre paiement de '||o.amount||' FCFA est confirmé.');
end $$;

create or replace function public.refuse_payment(p_payment uuid, p_refund boolean default false) returns void
language plpgsql security definer set search_path=public,extensions as $$
declare pay payments; o orders; c commissions; begin
  if not is_admin() then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update; select * into o from orders where id=pay.order_id;
  if p_refund and pay.status='confirmed' then
    update payments set status='refunded' where id=pay.id; update orders set status='refunded' where id=o.id;
    select * into c from commissions where order_id=o.id;
    if found then update profiles set balance=balance-c.reseller_amount where id=c.reseller_id; delete from commissions where id=c.id; end if;
    update access_codes set status='revoked' where order_id=o.id;
    delete from enrollments where order_id=o.id;
  elsif pay.status='pending' then update payments set status='refused' where id=pay.id; update orders set status='refused' where id=o.id; end if;
end $$;

-- ===== Codes d'accès : générés après paiement confirmé, valeur en clair retournée UNE seule fois =====
create or replace function public.generate_code(p_order uuid) returns text language plpgsql security definer set search_path=public,extensions as $$
declare o orders; plain text; begin
  select * into o from orders where id=p_order;
  if not found or o.kind<>'course' or o.status<>'confirmed' then raise exception 'Commande non confirmée'; end if;
  if not (is_admin() or o.reseller_id=auth.uid()) then raise exception 'Non autorisé'; end if;
  if exists(select 1 from access_codes where order_id=p_order) then raise exception 'Code déjà généré pour cette commande'; end if;
  if o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then raise exception 'Revendeur suspendu'; end if;
  plain := (select upper(substr(slug,1,2)) from courses where id=o.course_id)||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),o.course_id,p_order,auth.uid());
  return plain; end $$;

create or replace function public.redeem_code(p_code text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare ac access_codes; slug text; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into ac from access_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update access_codes set status='used', used_by=auth.uid(), used_at=now() where id=ac.id;
  insert into enrollments(user_id,course_id,order_id) values(auth.uid(),ac.course_id,ac.order_id) on conflict do nothing;
  select courses.slug into slug from courses where id=ac.course_id; return slug; end $$;

create or replace function public.my_access() returns text[] language sql stable security definer set search_path=public,extensions as
$$ select coalesce(array_agg(c.slug),'{}') from courses c where is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid()) $$;

create or replace function public.get_course_videos(p_slug text) returns table(title text,url text,chapter text,pos int)
language sql stable security definer set search_path=public,extensions as $$
  select v.title,v.url,ch.title,v.position from videos v join courses c on c.id=v.course_id left join chapters ch on ch.id=v.chapter_id
  where c.slug=p_slug and (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid())) order by v.position $$;

-- ===== Admin =====
create or replace function public.admin_stats() returns json language plpgsql stable security definer set search_path=public,extensions as $$
begin if not is_admin() then raise exception 'Non autorisé'; end if;
return json_build_object(
 'buyers',(select count(*) from profiles where role='buyer'),'resellers',(select count(*) from profiles where role='reseller'),
 'sales',(select count(*) from orders where status='confirmed' and kind='course'),
 'revenue',(select coalesce(sum(amount),0) from orders where status='confirmed'),
 'commissions',(select coalesce(sum(reseller_amount),0) from commissions),
 'academy',(select coalesce(sum(academy_amount),0) from commissions)+(select coalesce(sum(amount),0) from orders where status='confirmed' and reseller_id is null)); end $$;

create or replace function public.admin_set_reseller(p_user uuid, p_status text) returns void language plpgsql security definer set search_path=public,extensions as $$
begin if not is_admin() then raise exception 'Non autorisé'; end if;
 if p_status not in ('active','suspended') then raise exception 'Statut invalide'; end if;
 update profiles set reseller_status=p_status where id=p_user and role='reseller'; end $$;
-- Premier administrateur : à faire UNE fois depuis le SQL Editor (jamais depuis l'app) :
--   update public.profiles set role='admin' where email='TON_EMAIL';

revoke execute on function public.confirm_payment(uuid,text) from anon;


-- ===== 002_notifications_roles.sql =====
-- KANIS VPN ACADEMY — migration 002 : notifications serveur, changement de rôle côté serveur, correctifs
-- À exécuter APRÈS 001_kanis_schema.sql

-- ===== Notifications =====
create or replace function public.notify(p_user uuid, p_title text, p_body text) returns void
language sql security definer set search_path=public,extensions as $$ insert into notifications(user_id,title,body) values(p_user,p_title,p_body) $$;
revoke execute on function public.notify(uuid,text,text) from public, anon, authenticated;

create or replace function public.trg_order_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
declare a record; begin
  if new.kind='course' then
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Nouvelle commande',new.amount||' FCFA en attente de vérification'); end loop;
    if new.reseller_id is not null then perform notify(new.reseller_id,'Commande enregistrée','Vente de '||new.amount||' FCFA en attente de confirmation'); end if;
  else
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Demande d''activation revendeur',new.amount||' FCFA en attente de vérification'); end loop;
  end if; return new; end $$;
create trigger orders_notify after insert on orders for each row execute function trg_order_notify();

create or replace function public.trg_code_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
begin perform notify(new.created_by,'Nouveau code généré','Un code d''accès a été créé (se terminant par …'||new.hint||').'); return new; end $$;
create trigger codes_notify after insert on access_codes for each row execute function trg_code_notify();

create or replace function public.trg_enroll_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
begin perform notify(new.user_id,'Formation débloquée','Ta formation est maintenant disponible.'); return new; end $$;
create trigger enroll_notify after insert on enrollments for each row execute function trg_enroll_notify();

create or replace function public.trg_promo_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
begin if new.active and not new.applies_to_activation then perform notify(null,'Nouvelle promotion','Code '||new.code||' disponible.'); end if; return new; end $$;
create trigger promo_notify after insert on promotions for each row execute function trg_promo_notify();

-- Promotions d'activation : notification réservée aux revendeurs en attente d'activation
create or replace function public.trg_promo_act_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
declare r record; begin
  if new.active and new.applies_to_activation then
    for r in select id from profiles where role='reseller' and reseller_status='pending' loop perform notify(r.id,'Promotion sur l''activation','Le prix d''activation est réduit. Ouvre ton espace revendeur.'); end loop; end if; return new; end $$;
create trigger promo_act_notify after insert on promotions for each row execute function trg_promo_act_notify();

-- Temps réel (les politiques RLS s'appliquent aux événements)
alter publication supabase_realtime add table public.notifications;

-- ===== confirm_payment (remplace la version 001 : contrôle d'existence + notifications) =====
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public,extensions as $$
declare pay payments; o orders; share int; rc int; begin
  if not (is_admin() or auth.role()='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  update payments set status='confirmed', reference=coalesce(p_reference,reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then
    update profiles set reseller_status='active' where id=o.buyer_id;
    perform notify(o.buyer_id,'Compte revendeur activé','Ton espace revendeur est prêt.');
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    rc := o.amount*share/100;
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);
    update profiles set balance=balance+rc where id=o.reseller_id;
    perform notify(o.reseller_id,'Paiement confirmé · nouvelle commission','Commission de '||rc||' FCFA créditée. Tu peux générer le code du client.');
  else
    insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing;  -- notifie « Formation débloquée »
    perform notify(o.buyer_id,'Paiement confirmé',o.amount||' FCFA reçus.');
  end if;
end $$;

-- ===== Rôles : uniquement côté serveur, par un administrateur =====
create or replace function public.admin_set_role(p_user uuid, p_role text) returns void language plpgsql security definer set search_path=public,extensions as $$
begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  if p_role not in ('buyer','reseller','admin') then raise exception 'Rôle invalide'; end if;
  if p_user=auth.uid() then raise exception 'Tu ne peux pas modifier ton propre rôle'; end if;
  update profiles set role=p_role, reseller_status=case when p_role='reseller' then 'active' else 'none' end where id=p_user; end $$;


-- ===== 003_direct_signup_activation.sql =====
-- KANIS VPN ACADEMY — migration 003 (à exécuter APRÈS 001 et 002, dans le SQL Editor)
-- Inscription directe (sans confirmation e-mail), profils sans incohérence,
-- activation revendeur sans double paiement ni double activation.

-- ===== 1. Création du profil à l'inscription (robuste, jamais admin) =====
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public,extensions as $$
declare want boolean := coalesce(new.raw_user_meta_data->>'want_reseller','')='true';
begin
  insert into profiles(id,email,full_name,phone,role,reseller_status)
  values(new.id,new.email,
    left(btrim(coalesce(new.raw_user_meta_data->>'full_name','')),80),
    left(btrim(coalesce(new.raw_user_meta_data->>'phone','')),30),
    case when want then 'reseller' else 'buyer' end,      -- le rôle admin n'est JAMAIS attribué ici
    case when want then 'pending' else 'none' end)
  on conflict (id) do nothing;
  return new; end $$;

-- Répare un compte Auth sans profil (rôle toujours buyer/reseller, jamais admin)
create or replace function public.ensure_profile() returns void
language plpgsql security definer set search_path=public,extensions,auth as $$
declare u auth.users; want boolean; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if exists(select 1 from profiles where id=auth.uid()) then return; end if;
  select * into u from auth.users where id=auth.uid();
  if not found then raise exception 'Utilisateur introuvable'; end if;
  want := coalesce(u.raw_user_meta_data->>'want_reseller','')='true';
  insert into profiles(id,email,full_name,phone,role,reseller_status)
  values(u.id,u.email,left(btrim(coalesce(u.raw_user_meta_data->>'full_name','')),80),
    left(btrim(coalesce(u.raw_user_meta_data->>'phone','')),30),
    case when want then 'reseller' else 'buyer' end, case when want then 'pending' else 'none' end)
  on conflict (id) do nothing; end $$;
revoke execute on function public.ensure_profile() from public, anon;
grant execute on function public.ensure_profile() to authenticated;

-- Le prix d'activation (avec promotion automatique) est affiché avant l'inscription
grant execute on function public.activation_quote() to anon, authenticated;

-- ===== 2. Un seul paiement d'activation en attente / confirmé par compte =====
create unique index if not exists one_pending_activation   on public.orders(buyer_id) where kind='activation' and status='pending';
create unique index if not exists one_confirmed_activation on public.orders(buyer_id) where kind='activation' and status='confirmed';

-- ===== 3. Demande d'activation : idempotente, promotion appliquée côté serveur =====
create or replace function public.request_activation(p_promo text default null, p_provider text default 'manual') returns uuid
language plpgsql security definer set search_path=public,extensions as $$
declare oid uuid; base int; amt int; used text; best_code text; best_amt int; code_amt int; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','wave') then raise exception 'Choisis Orange Money ou Wave'; end if;
  perform 1 from profiles where id=auth.uid() for update;            -- sérialise les doubles clics
  if not exists(select 1 from profiles where id=auth.uid() and role='reseller' and reseller_status='pending') then
    raise exception 'Ce compte n''a pas besoin d''être activé'; end if;
  select id into oid from orders where buyer_id=auth.uid() and kind='activation' and status='pending' limit 1;
  if oid is not null then
    update payments set provider=p_provider where order_id=oid and status='pending';
    return oid; end if;                                               -- déjà une demande en attente
  select value::int into base from settings where key='reseller_activation_price';
  select code, case when kind='percent' then base-base*least(value,100)/100 else greatest(base-value,0) end
    into best_code, best_amt from promotions
   where active and applies_to_activation and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now()) and (max_uses is null or uses<max_uses)
   order by 2 asc limit 1;
  amt := base; used := null;
  if best_amt is not null and best_amt<amt then amt:=best_amt; used:=best_code; end if;   -- promotion automatique (même celle affichée à l'inscription)
  if nullif(p_promo,'') is not null then
    code_amt := price_for(null,p_promo,true);
    if code_amt<amt then amt:=code_amt; used:=upper(p_promo); end if; end if;
  insert into orders(buyer_id,kind,amount,promo_code) values(auth.uid(),'activation',amt,used) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

-- ===== 4. Un revendeur inactif ne peut pas vendre =====
create or replace function public.create_order(p_course uuid, p_promo text default null, p_provider text default 'manual', p_client_name text default null, p_client_phone text default null)
returns uuid language plpgsql security definer set search_path=public,extensions as $$
declare oid uuid; amt int; me profiles; rid uuid; begin
  select * into me from profiles where id=auth.uid(); if not found then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','wave','manual') then raise exception 'Fournisseur invalide'; end if;
  if me.role='reseller' then
    if me.reseller_status<>'active' then raise exception 'Compte revendeur inactif : active-le pour vendre'; end if;
    if p_client_name is not null then rid:=me.id; end if;
  end if;
  amt := price_for(p_course,p_promo,false);
  insert into orders(buyer_id,reseller_id,course_id,client_name,client_phone,amount,promo_code)
  values(case when rid is null then me.id end,rid,p_course,p_client_name,p_client_phone,amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

-- ===== 5. Confirmation de paiement : pas de commission pour un revendeur inactif, pas de double activation =====
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public,extensions as $$
declare pay payments; o orders; share int; rc int; n int; begin
  if not (is_admin() or auth.role()='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  if o.kind='activation' then
    update profiles set reseller_status='active' where id=o.buyer_id and role='reseller' and reseller_status='pending';
    get diagnostics n = row_count;
    if n=0 then raise exception 'Ce compte n''est pas en attente d''activation (déjà actif ou suspendu)'; end if;
  elsif o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then
    raise exception 'Revendeur inactif : aucune commission possible (refuse le paiement ou réactive le revendeur)';
  end if;
  update payments set status='confirmed', reference=coalesce(p_reference,reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then
    perform notify(o.buyer_id,'Compte revendeur activé','Ton espace revendeur est prêt.');
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    rc := o.amount*share/100;
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);
    update profiles set balance=balance+rc where id=o.reseller_id;
    perform notify(o.reseller_id,'Paiement confirmé · nouvelle commission','Commission de '||rc||' FCFA créditée. Tu peux générer le code du client.');
  else
    insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing;
    perform notify(o.buyer_id,'Paiement confirmé',o.amount||' FCFA reçus.');
  end if;
end $$;
revoke execute on function public.confirm_payment(uuid,text) from public, anon;
grant execute on function public.confirm_payment(uuid,text) to authenticated, service_role;


-- ===== 004_reseller_requests_videos.sql =====
-- KANIS VPN ACADEMY 004 : demandes revendeur (preuve + validation manuelle + code), moyens de paiement revendeur, vidéos protégées
-- À exécuter APRÈS 001, 002, 003. Jamais testé sur un vrai PostgreSQL ici : exécute et signale toute erreur.
create extension if not exists pgcrypto;

create table if not exists public.reseller_requests(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles on delete cascade,
  full_name text not null, phone text not null, email text not null, pay_phone text not null,
  amount int not null check(amount>0), proof_path text not null,
  status text not null default 'pending' check(status in ('pending','approved','refused')),
  admin_note text, reviewed_by uuid, reviewed_at timestamptz, created_at timestamptz default now());
create unique index if not exists one_pending_request on public.reseller_requests(user_id) where status='pending';

create table if not exists public.reseller_codes(
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null unique references public.reseller_requests on delete cascade,
  user_id uuid not null references public.profiles on delete cascade,
  code_hash text unique not null,
  status text not null default 'unused' check(status in ('unused','used','revoked')),
  used_at timestamptz, created_at timestamptz default now());

create table if not exists public.reseller_payment_methods(
  id uuid primary key default gen_random_uuid(),
  reseller_id uuid not null references public.profiles on delete cascade,
  operator text not null, number text not null, holder_name text not null, instructions text,
  created_at timestamptz default now());

create table if not exists public.operation_log(
  id uuid primary key default gen_random_uuid(), actor uuid, action text not null, detail jsonb, created_at timestamptz default now());

alter table public.videos add column if not exists description text;
alter table public.videos add column if not exists thumbnail_path text;
alter table public.videos add column if not exists storage_path text;
alter table public.videos add column if not exists is_active boolean not null default true;
alter table public.courses add column if not exists code_prefix text;
update public.courses set code_prefix='DT' where slug='dark-tunnel' and code_prefix is null;
update public.courses set code_prefix='BK' where slug='bkcbebe-tunnel' and code_prefix is null;

alter table public.reseller_requests enable row level security;
alter table public.reseller_codes enable row level security;
alter table public.reseller_payment_methods enable row level security;
alter table public.operation_log enable row level security;

create policy rr_own on public.reseller_requests for select using (user_id=auth.uid() or public.is_admin());
create policy rc_admin on public.reseller_codes for select using (public.is_admin());
create policy rpm_own on public.reseller_payment_methods for all
  using (reseller_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and reseller_status='active'))
  with check (reseller_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and reseller_status='active'));
create policy rpm_admin on public.reseller_payment_methods for select using (public.is_admin());
create policy ol_admin on public.operation_log for select using (public.is_admin());

-- 1) Le futur revendeur envoie sa preuve : statut EN ATTENTE, aucune activation automatique
create or replace function public.submit_reseller_request(p_name text,p_phone text,p_email text,p_pay_phone text,p_amount int,p_proof_path text)
returns uuid language plpgsql security definer set search_path=public,extensions as $$
declare rid uuid; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_proof_path is null or p_proof_path not like auth.uid()::text||'/%' then raise exception 'Preuve de paiement invalide'; end if;
  if exists(select 1 from profiles where id=auth.uid() and reseller_status='active') then raise exception 'Compte déjà activé'; end if;
  insert into reseller_requests(user_id,full_name,phone,email,pay_phone,amount,proof_path)
    values(auth.uid(),trim(p_name),trim(p_phone),trim(p_email),trim(p_pay_phone),p_amount,p_proof_path) returning id into rid;
  insert into operation_log(actor,action,detail) values(auth.uid(),'reseller_request',jsonb_build_object('id',rid));
  return rid; end $$;

-- 2) L'administrateur accepte ou refuse ; le code est renvoyé UNE seule fois (seul son hash est stocké)
create or replace function public.admin_review_request(p_id uuid,p_decision text,p_note text default null)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare r reseller_requests; c text; begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  select * into r from reseller_requests where id=p_id and status='pending' for update;
  if not found then raise exception 'Demande introuvable ou déjà traitée'; end if;
  if p_decision='refused' then
    update reseller_requests set status='refused',admin_note=p_note,reviewed_by=auth.uid(),reviewed_at=now() where id=p_id;
    insert into operation_log(actor,action,detail) values(auth.uid(),'request_refused',jsonb_build_object('id',p_id)); return null; end if;
  if p_decision<>'approved' then raise exception 'Décision invalide'; end if;
  c:='RV-'||upper(substr(encode(gen_random_bytes(6),'hex'),1,10));
  update reseller_requests set status='approved',admin_note=p_note,reviewed_by=auth.uid(),reviewed_at=now() where id=p_id;
  insert into reseller_codes(request_id,user_id,code_hash) values(p_id,r.user_id,encode(digest(c,'sha256'),'hex'));
  insert into operation_log(actor,action,detail) values(auth.uid(),'request_approved',jsonb_build_object('id',p_id));
  return c; end $$;

-- 3) Le revendeur saisit son code : vérification serveur, usage unique, activation
create or replace function public.redeem_reseller_code(p_code text) returns void language plpgsql security definer set search_path=public,extensions as $$
declare rc reseller_codes; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into rc from reseller_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' and user_id=auth.uid() for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update reseller_codes set status='used',used_at=now() where id=rc.id;
  update profiles set role='reseller',reseller_status='active' where id=auth.uid() and role<>'admin';
  insert into operation_log(actor,action,detail) values(auth.uid(),'reseller_activated',jsonb_build_object('code_id',rc.id)); end $$;

-- 4) Clients : voir les moyens de paiement d'un revendeur actif (jamais ceux de l'admin)
create or replace function public.get_reseller_methods(p_reseller uuid) returns table(operator text,number text,holder_name text,instructions text)
language sql stable security definer set search_path=public,extensions as $$
  select m.operator,m.number,m.holder_name,m.instructions from reseller_payment_methods m
  join profiles p on p.id=m.reseller_id where m.reseller_id=p_reseller and p.reseller_status='active' $$;

-- 5) Vidéos : la liste (titre, description, miniature) est visible, jamais le fichier sans droit
create or replace function public.list_course_videos(p_slug text) returns table(id uuid,title text,description text,thumbnail_path text,pos int,unlocked boolean)
language sql stable security definer set search_path=public,extensions as $$
  select v.id,v.title,v.description,v.thumbnail_path,v.position,
   (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid()))
  from videos v join courses c on c.id=v.course_id where c.slug=p_slug and v.is_active order by v.position $$;

-- Buckets privés
insert into storage.buckets(id,name,public) values('proofs','proofs',false),('videos','videos',false),('thumbs','thumbs',true) on conflict do nothing;
create policy proofs_ins on storage.objects for insert to authenticated with check(bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text);
create policy proofs_sel on storage.objects for select to authenticated using(bucket_id='proofs' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
create policy videos_admin on storage.objects for all to authenticated using(bucket_id in ('videos','thumbs') and public.is_admin()) with check(bucket_id in ('videos','thumbs') and public.is_admin());
create policy videos_sel on storage.objects for select to authenticated using(bucket_id='videos' and exists(
  select 1 from public.videos v join public.enrollments e on e.course_id=v.course_id where v.storage_path=name and v.is_active and e.user_id=auth.uid()));

revoke execute on function public.submit_reseller_request(text,text,text,text,int,text),public.admin_review_request(uuid,text,text),
  public.redeem_reseller_code(text),public.get_reseller_methods(uuid),public.list_course_videos(text) from anon;

-- ===== Promotion des prix (automatique : prix promo pendant la période, prix normal ensuite) =====
create table if not exists public.price_promos(id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses on delete cascade,
  promo_price int not null check(promo_price>=0), starts_at timestamptz, ends_at timestamptz not null, active boolean not null default true, created_at timestamptz default now());
alter table public.price_promos enable row level security;
create policy pp_admin on public.price_promos for all using(public.is_admin()) with check(public.is_admin());
create or replace function public.price_for(p_course uuid, p_promo text, p_activation boolean default false) returns int
language plpgsql stable security definer set search_path=public,extensions as $$
declare base int; pr promotions; res int;
begin
  if p_activation then select value::int into base from settings where key='reseller_activation_price';
  else select coalesce((select pp.promo_price from price_promos pp where pp.course_id=c.id and pp.active and (pp.starts_at is null or pp.starts_at<=now()) and pp.ends_at>=now() order by pp.promo_price limit 1),c.price) into base from courses c where c.id=p_course and c.active; end if;
  if base is null then raise exception 'Formation introuvable'; end if;
  if p_promo is null or p_promo='' then return base; end if;
  select * into pr from promotions where upper(code)=upper(p_promo) and active
     and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now())
     and (max_uses is null or uses<max_uses)
     and ((p_activation and applies_to_activation) or (not p_activation and (course_ids='{}' or p_course=any(course_ids))));
  if not found then return base; end if;
  res := case when pr.kind='percent' then base - base*least(pr.value,100)/100 else greatest(base-pr.value,0) end;
  return res; end $$;

-- ===== Codes de formation : préfixe DT (Dark Tunnel) / BK (BKCBEBE Tunnel) ; chaque code ne débloque que sa formation =====
create or replace function public.generate_code(p_order uuid) returns text language plpgsql security definer set search_path=public,extensions as $$
declare o orders; plain text; begin
  select * into o from orders where id=p_order;
  if not found or o.kind<>'course' or o.status<>'confirmed' then raise exception 'Commande non confirmée'; end if;
  if not (is_admin() or o.reseller_id=auth.uid()) then raise exception 'Non autorisé'; end if;
  if exists(select 1 from access_codes where order_id=p_order) then raise exception 'Code déjà généré pour cette commande'; end if;
  if o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then raise exception 'Revendeur suspendu'; end if;
  plain := (select coalesce(code_prefix,upper(substr(slug,1,2))) from courses where id=o.course_id)||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),o.course_id,p_order,auth.uid());
  return plain; end $$;

-- ===== Sources vidéo (accès vérifié côté serveur ; le fichier privé est servi par URL signée) =====
create or replace function public.get_video_sources(p_slug text) returns table(id uuid,title text,description text,url text,storage_path text,chapter text,pos int)
language sql stable security definer set search_path=public,extensions as $$
  select v.id,v.title,v.description,case when v.storage_path is null then v.url else null end,v.storage_path,ch.title,v.position
  from videos v join courses c on c.id=v.course_id left join chapters ch on ch.id=v.chapter_id
  where c.slug=p_slug and v.is_active and (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid())) order by v.position $$;
revoke execute on function public.get_video_sources(text) from anon;

-- Les vidéos désactivées ne sont plus servies
create or replace function public.get_course_videos(p_slug text) returns table(title text,url text,chapter text,pos int)
language sql stable security definer set search_path=public,extensions as $$
  select v.title,v.url,ch.title,v.position from videos v join courses c on c.id=v.course_id left join chapters ch on ch.id=v.chapter_id
  where c.slug=p_slug and v.is_active and (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid())) order by v.position $$;


-- ===== 005_admin_reset_password.sql =====
-- KANIS VPN ACADEMY 005 : les fonctions sécurisées voient pgcrypto
-- À exécuter APRÈS 001 à 004 (et aussi si 001 à 004 sont déjà exécutées).

-- 1) Les fonctions sécurisées doivent voir pgcrypto (digest, crypt, gen_random_bytes), installé dans le schéma "extensions" sur Supabase
do $$ declare r record; begin
  for r in select p.oid::regprocedure as f from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.prosecdef loop
    execute format('alter function %s set search_path = public, extensions', r.f);
  end loop; end $$;


-- ===== 006_reset_by_client.sql =====
-- KANIS VPN ACADEMY 006 : réinitialisation SANS que l'administrateur connaisse le mot de passe
-- L'admin « initialise » l'accès (24 h) ; le client choisit lui-même son nouveau mot de passe (e-mail + numéro de téléphone du compte).
-- À exécuter APRÈS 005.
alter table public.profiles add column if not exists reset_until timestamptz;
alter table public.profiles add column if not exists reset_attempts int not null default 0;
drop function if exists public.admin_reset_password(text);

create or replace function public.admin_init_reset(p_email text) returns void
language plpgsql security definer set search_path=public,extensions,auth as $$
declare uid uuid; begin
  if not public.is_admin() then raise exception 'Non autorisé'; end if;
  select id into uid from auth.users where lower(email)=lower(trim(p_email));
  if uid is null then raise exception 'Aucun compte avec cet e-mail'; end if;
  -- l'ancien mot de passe est invalidé ; le nouveau mot de passe n'est connu de personne tant que le client ne l'a pas choisi
  update auth.users set encrypted_password=crypt(encode(gen_random_bytes(24),'hex'),gen_salt('bf')),
    email_confirmed_at=coalesce(email_confirmed_at,now()), updated_at=now() where id=uid;
  update public.profiles set reset_until=now()+interval '24 hours', reset_attempts=0 where id=uid;
  insert into public.operation_log(actor,action,detail) values(auth.uid(),'reset_initialized',jsonb_build_object('user',uid));
end $$;

-- Le client choisit son mot de passe : e-mail + téléphone du compte, 5 essais maximum, valable 24 h, une seule fois
create or replace function public.claim_reset(p_email text,p_phone text,p_new text) returns text
language plpgsql security definer set search_path=public,extensions,auth as $$
declare uid uuid; pr public.profiles; a text; b text; begin
  if length(coalesce(p_new,''))<8 then return 'ko'; end if;
  select id into uid from auth.users where lower(email)=lower(trim(p_email));
  if uid is null then return 'ko'; end if;
  select * into pr from public.profiles where id=uid;
  if pr.id is null or pr.reset_until is null or pr.reset_until<now() or pr.reset_attempts>=5 then return 'ko'; end if;
  a:=right(regexp_replace(coalesce(pr.phone,''),'\D','','g'),8); b:=right(regexp_replace(coalesce(p_phone,''),'\D','','g'),8);
  if a='' or a<>b then update public.profiles set reset_attempts=reset_attempts+1 where id=uid; return 'ko'; end if;
  update auth.users set encrypted_password=crypt(p_new,gen_salt('bf')), updated_at=now() where id=uid;
  update public.profiles set reset_until=null, reset_attempts=0 where id=uid;
  insert into public.operation_log(actor,action,detail) values(null,'reset_claimed',jsonb_build_object('user',uid));
  return 'ok'; end $$;

revoke execute on function public.admin_init_reset(text) from anon, public;
grant execute on function public.admin_init_reset(text) to authenticated;
grant execute on function public.claim_reset(text,text,text) to anon, authenticated;


-- ===== 007_manual_payments_codes.sql =====
-- 007 : paiements manuels, codes générés par l'administrateur, vente directe du revendeur.
-- Sans risque pour les données existantes : à exécuter seul si la base est déjà installée.
alter table public.access_codes alter column order_id drop not null;
alter table public.reseller_codes alter column request_id drop not null;
alter table public.reseller_codes alter column user_id drop not null;
alter table public.reseller_codes add column if not exists hint text;
alter table public.reseller_codes add column if not exists created_by uuid;

-- Un code revendeur créé par l'admin (sans demande) peut être utilisé par n'importe quel compte, une seule fois.
create or replace function public.redeem_reseller_code(p_code text) returns void language plpgsql security definer set search_path=public,extensions as $$
declare rc reseller_codes; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into rc from reseller_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' and (user_id=auth.uid() or user_id is null) for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update reseller_codes set status='used',used_at=now(),user_id=auth.uid() where id=rc.id;
  update profiles set role='reseller',reseller_status='active' where id=auth.uid() and role<>'admin';
  insert into operation_log(actor,action,detail) values(auth.uid(),'reseller_activated',jsonb_build_object('code_id',rc.id)); end $$;

-- Admin : générer un code de formation ('course') ou un code d'accès revendeur ('reseller'). Valeur affichée une seule fois.
create or replace function public.admin_generate_code(p_kind text, p_course uuid default null) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare plain text; sl text; pre text; begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  if p_kind='reseller' then
    plain:='RV-'||upper(substr(encode(gen_random_bytes(6),'hex'),1,10));
    insert into reseller_codes(code_hash,hint,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),auth.uid());
  elsif p_kind='course' then
    select c.slug into sl from courses c where c.id=p_course;
    if not found then raise exception 'Formation introuvable'; end if;
    pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
    plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
    insert into access_codes(code_hash,hint,course_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,auth.uid());
  else raise exception 'Type de code invalide'; end if;
  insert into operation_log(actor,action,detail) values(auth.uid(),'admin_code_'||p_kind,jsonb_build_object('course',p_course));
  return plain; end $$;

-- Revendeur : le client a payé directement sur le numéro du revendeur ; vente enregistrée + code généré (aucune commission).
create or replace function public.reseller_sell(p_course uuid, p_client_name text, p_client_phone text default null, p_method text default null) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; amt int; oid uuid; plain text; sl text; pre text; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  if coalesce(trim(p_client_name),'')='' then raise exception 'Nom du client requis'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  amt:=price_for(p_course,null,false);
  insert into orders(reseller_id,course_id,client_name,client_phone,amount,status) values(me.id,p_course,trim(p_client_name),nullif(p_client_phone,''),amt,'confirmed') returning id into oid;
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,oid,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_sale',jsonb_build_object('order',oid,'method',p_method));
  return plain; end $$;

revoke execute on function public.admin_generate_code(text,uuid) from public, anon;
revoke execute on function public.reseller_sell(uuid,text,text,text) from public, anon;
grant execute on function public.admin_generate_code(text,uuid) to authenticated;
grant execute on function public.reseller_sell(uuid,text,text,text) to authenticated;

-- ===== 008_reseller_generate_code.sql =====
-- 008 : le revendeur actif génère lui-même un code d'accès (Dark Tunnel / BKCBEBE Tunnel), sans passer par une vente.
create or replace function public.reseller_generate_code(p_course uuid) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; plain text; sl text; pre text; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_code',jsonb_build_object('course',p_course));
  return plain; end $$;
revoke execute on function public.reseller_generate_code(uuid) from public, anon;
grant execute on function public.reseller_generate_code(uuid) to authenticated;

-- ===== 009_audit_hardening.sql =====
-- KANIS VPN ACADEMY 009 : audit final (idempotent, ne supprime aucune donnée)
-- 1) reseller_generate_code : chaque code créé par un revendeur est lié à une commande au prix OFFICIEL (price_for, calculé par le serveur).
--    La commande reste « pending » (aucune vente fictive) et devient « confirmed » quand le client utilise le code (redeem_code).
-- 2) redeem_code : confirme la commande liée à un code revendeur, rattache l'acheteur, garde le verrou anti double utilisation.
-- 3) Droits EXECUTE : aucune fonction appelable sans connexion, sauf is_admin() (utilisée par les politiques RLS) et claim_reset().
-- 4) Pas de faux « Nouvelle commande » admin pour les codes générés.
-- 5) Lecture des fichiers vidéo privés par les acheteurs inscrits (correctif du stockage).

create or replace function public.trg_order_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
declare a record; begin
  if coalesce(current_setting('kanis.silent',true),'')='1' then return new; end if;
  if new.kind='course' then
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Nouvelle commande',new.amount||' FCFA en attente de vérification'); end loop;
    if new.reseller_id is not null then perform notify(new.reseller_id,'Commande enregistrée','Vente de '||new.amount||' FCFA en attente de confirmation'); end if;
  else
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Demande d''activation revendeur',new.amount||' FCFA en attente de vérification'); end loop;
  end if; return new; end $$;

drop function if exists public.reseller_generate_code(uuid);
create function public.reseller_generate_code(p_course uuid) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; plain text; sl text; pre text; amt int; oid uuid; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  amt:=price_for(p_course,null,false);
  perform set_config('kanis.silent','1',true);
  insert into orders(reseller_id,course_id,amount,status) values(me.id,p_course,amt,'pending') returning id into oid;
  perform set_config('kanis.silent','0',true);
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,oid,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_code',jsonb_build_object('course',p_course,'order',oid,'amount',amt));
  return plain; end $$;

create or replace function public.redeem_code(p_code text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare ac access_codes; slug text; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into ac from access_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update access_codes set status='used', used_by=auth.uid(), used_at=now() where id=ac.id;
  if ac.order_id is not null then
    update orders o set status='confirmed', buyer_id=auth.uid(),
      client_name=coalesce(o.client_name,(select coalesce(nullif(p.full_name,''),p.email) from profiles p where p.id=auth.uid()))
    where o.id=ac.order_id and o.status='pending' and o.kind='course' and o.reseller_id is not null and o.buyer_id is null;
  end if;
  insert into enrollments(user_id,course_id,order_id) values(auth.uid(),ac.course_id,ac.order_id) on conflict do nothing;
  insert into operation_log(actor,action,detail) values(auth.uid(),'code_redeemed',jsonb_build_object('code_id',ac.id,'course',ac.course_id));
  select courses.slug into slug from courses where id=ac.course_id; return slug; end $$;

-- 5) Stockage des vidéos : un acheteur inscrit doit pouvoir lire le fichier privé de SA formation.
--    L'ancienne règle interrogeait la table videos (réservée à l'admin par RLS) : elle ne renvoyait jamais rien pour un acheteur.
create or replace function public.can_watch_video(p_path text) returns boolean language sql stable security definer set search_path=public,extensions as $$
  select p_path is not null and (is_admin() or exists(select 1 from videos v join enrollments e on e.course_id=v.course_id
    where v.storage_path=p_path and v.is_active and e.user_id=auth.uid())) $$;
drop policy if exists videos_sel on storage.objects;
create policy videos_sel on storage.objects for select to authenticated using(bucket_id='videos' and public.can_watch_video(name));

-- Droits EXECUTE (les fonctions des extensions et les fonctions de déclencheurs ne sont pas touchées ; notify() reste interne)
do $$ declare r record; begin
  for r in select p.oid::regprocedure f, p.proname n from pg_proc p join pg_namespace s on s.oid=p.pronamespace
           where s.nspname='public' and p.prokind='f' and p.prorettype<>'trigger'::regtype
             and not exists(select 1 from pg_depend d where d.objid=p.oid and d.deptype='e') loop
    execute format('revoke execute on function %s from public, anon',r.f);
    if r.n='notify' then
      execute format('revoke execute on function %s from authenticated',r.f);
    else
      execute format('grant execute on function %s to authenticated, service_role',r.f);
    end if;
    if r.n in ('is_admin','claim_reset') then execute format('grant execute on function %s to anon',r.f); end if;
  end loop; end $$;
alter default privileges in schema public revoke execute on functions from anon;


-- ===== 010_host_offert.sql =====
-- 010 : host offert (acheteur + revendeur) et sites gratuits, affichés dans l'écran de félicitations.
-- Les hosts et les sites sont dans des tables : tu les ajoutes dans Supabase → Table Editor, sans recompiler l'application.
-- Le host n'est jamais dans l'APK : il est renvoyé par le serveur seulement à un acheteur inscrit, à un revendeur actif ou à l'admin.

create table if not exists public.host_gifts(
  id uuid primary key default gen_random_uuid(),
  country_code text,
  country_name text not null,
  flag text default '🏳️',
  host text not null,
  active boolean not null default true,
  position int not null default 0,
  created_at timestamptz default now());

create table if not exists public.free_sites(
  id uuid primary key default gen_random_uuid(),
  title text not null,
  url text not null,
  active boolean not null default true,
  position int not null default 0,
  created_at timestamptz default now());

alter table public.host_gifts enable row level security;
alter table public.free_sites enable row level security;
drop policy if exists hg_admin on public.host_gifts;
create policy hg_admin on public.host_gifts for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists fs_admin on public.free_sites;
create policy fs_admin on public.free_sites for all using (public.is_admin()) with check (public.is_admin());

create or replace function public.get_host_gift(p_audience text default 'buyer') returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare aud text; ok boolean;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_audience='reseller' then
    aud:='reseller';
    ok:=public.is_admin() or exists(select 1 from profiles where id=auth.uid() and reseller_status='active');
  else
    aud:='buyer';
    ok:=public.is_admin() or exists(select 1 from enrollments where user_id=auth.uid());
  end if;
  if not ok then raise exception 'Accès refusé'; end if;
  return json_build_object(
    'hosts', coalesce((select json_agg(json_build_object('country_code',country_code,'country_name',country_name,'flag',flag,'host',host) order by position,created_at) from host_gifts where active),'[]'::json),
    'sites', case when aud='buyer'
              then coalesce((select json_agg(json_build_object('title',title,'url',url) order by position,created_at) from free_sites where active),'[]'::json)
              else '[]'::json end);
end $$;
revoke all on function public.get_host_gift(text) from public, anon;
grant execute on function public.get_host_gift(text) to authenticated, service_role;

-- Exemples à adapter dans le SQL Editor (ou à saisir dans Table Editor) :
-- insert into public.host_gifts(country_code,country_name,flag,host,position) values ('BF','Burkina Faso','🇧🇫','TON-HOST-ICI',0);
-- insert into public.free_sites(title,url,position) values ('Nom du site 1','https://...',0),('Nom du site 2','https://...',1);


-- ===== 011_referral.sql =====
-- 011 : code de parrainage (revendeur -> client). A executer UNE fois dans Supabase > SQL Editor.
-- Le client entre le code de son revendeur : il voit alors les moyens de paiement et le WhatsApp de CE revendeur
-- (et non ceux de l'administrateur), seulement si le revendeur a renseigne ses informations.

alter table public.profiles add column if not exists referral_code text;
alter table public.profiles add column if not exists referred_by uuid references public.profiles(id) on delete set null;
create unique index if not exists profiles_referral_code_key on public.profiles(referral_code) where referral_code is not null;

-- Informations visibles d'un revendeur actif (interne : appelee seulement par les fonctions ci-dessous)
create or replace function public.seller_info(p_seller uuid) returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare p record; m json; n int;
begin
  select * into p from profiles where id=p_seller and role='reseller' and reseller_status='active';
  if p.id is null then return null; end if;
  select count(*) into n from reseller_payment_methods where reseller_id=p.id;
  if n=0 and coalesce(trim(p.phone),'')='' then return null; end if;
  select coalesce(json_agg(json_build_object('operator',operator,'number',number,'holder_name',holder_name,'instructions',instructions) order by created_at),'[]'::json)
    into m from reseller_payment_methods where reseller_id=p.id;
  return json_build_object('name',p.full_name,'phone',p.phone,'methods',m);
end $$;

-- Le revendeur actif obtient (ou recupere) son code VPN-XXXXX
create or replace function public.my_referral_code() returns text
language plpgsql security definer set search_path=public,extensions as $$
declare r record; c text; i int; alpha text:='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
begin
  select * into r from profiles where id=auth.uid();
  if r.id is null or r.role<>'reseller' or r.reseller_status<>'active' then raise exception 'Reservé aux revendeurs actifs'; end if;
  if r.referral_code is not null then return r.referral_code; end if;
  loop
    c:='VPN-';
    for i in 1..5 loop c:=c||substr(alpha,1+floor(random()*length(alpha))::int,1); end loop;
    begin
      update profiles set referral_code=c where id=r.id;
      return c;
    exception when unique_violation then null;
    end;
  end loop;
end $$;

-- Le client entre le code de son revendeur
create or replace function public.use_referral_code(p_code text) returns json
language plpgsql security definer set search_path=public,extensions as $$
declare s record;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into s from profiles where referral_code=upper(trim(p_code)) and role='reseller' and reseller_status='active';
  if s.id is null then raise exception 'Code de parrainage invalide'; end if;
  if s.id=auth.uid() then raise exception 'Tu ne peux pas utiliser ton propre code'; end if;
  update profiles set referred_by=s.id where id=auth.uid();
  return json_build_object('ok',true,'seller',public.seller_info(s.id));
end $$;

-- Infos du revendeur du client (null si aucun revendeur ou si ses infos ne sont pas disponibles)
create or replace function public.my_seller() returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare rb uuid;
begin
  select referred_by into rb from profiles where id=auth.uid();
  if rb is null then return null; end if;
  return public.seller_info(rb);
end $$;

create or replace function public.clear_referral() returns void
language sql security definer set search_path=public,extensions as $$
  update profiles set referred_by=null where id=auth.uid() $$;

revoke all on function public.seller_info(uuid) from public, anon, authenticated;
revoke all on function public.my_referral_code() from public, anon;
revoke all on function public.use_referral_code(text) from public, anon;
revoke all on function public.my_seller() from public, anon;
revoke all on function public.clear_referral() from public, anon;
grant execute on function public.my_referral_code(), public.use_referral_code(text), public.my_seller(), public.clear_referral() to authenticated, service_role;


-- ===== 012_referral_promo.sql =====
-- 012 : (1) le revendeur lie reste affiche meme sans infos ; (2) codes promo crees par le revendeur.
-- A executer UNE fois dans Supabase > SQL Editor, APRES 011_referral.sql.

-- 1) seller_info : renvoie toujours le revendeur actif (infos eventuellement vides)
create or replace function public.seller_info(p_seller uuid) returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare p record; m json;
begin
  select * into p from profiles where id=p_seller and role='reseller' and reseller_status='active';
  if p.id is null then return null; end if;
  select coalesce(json_agg(json_build_object('operator',operator,'number',number,'holder_name',holder_name,'instructions',instructions) order by created_at),'[]'::json)
    into m from reseller_payment_methods where reseller_id=p.id;
  return json_build_object('name',p.full_name,'phone',nullif(trim(coalesce(p.phone,'')),''),'methods',m);
end $$;
revoke all on function public.seller_info(uuid) from public, anon, authenticated;

-- 2) codes promo du revendeur : pourcentage 1 a 30, code 4 a 16 caracteres, uniquement les siens
alter table public.promotions add column if not exists reseller_id uuid references public.profiles(id) on delete cascade;
drop policy if exists pr_reseller_sel on public.promotions;
create policy pr_reseller_sel on public.promotions for select using (reseller_id=auth.uid());
drop policy if exists pr_reseller_ins on public.promotions;
create policy pr_reseller_ins on public.promotions for insert with check (
  reseller_id=auth.uid() and kind='percent' and value between 1 and 30 and not applies_to_activation
  and code ~ '^[A-Z0-9-]{4,16}$'
  and exists(select 1 from public.profiles where id=auth.uid() and role='reseller' and reseller_status='active'));
drop policy if exists pr_reseller_upd on public.promotions;
create policy pr_reseller_upd on public.promotions for update using (reseller_id=auth.uid()) with check (
  reseller_id=auth.uid() and kind='percent' and value between 1 and 30 and not applies_to_activation and code ~ '^[A-Z0-9-]{4,16}$');
drop policy if exists pr_reseller_del on public.promotions;
create policy pr_reseller_del on public.promotions for delete using (reseller_id=auth.uid());

-- 3) vente du revendeur avec code promo optionnel
drop function if exists public.reseller_sell(uuid,text,text,text);
create or replace function public.reseller_sell(p_course uuid, p_client_name text, p_client_phone text default null, p_method text default null, p_promo text default null) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; amt int; oid uuid; plain text; sl text; pre text; pc text; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  if coalesce(trim(p_client_name),'')='' then raise exception 'Nom du client requis'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  pc:=nullif(upper(trim(coalesce(p_promo,''))),'');
  amt:=price_for(p_course,pc,false);
  insert into orders(reseller_id,course_id,client_name,client_phone,amount,promo_code,status) values(me.id,p_course,trim(p_client_name),nullif(p_client_phone,''),amt,pc,'confirmed') returning id into oid;
  if pc is not null then update promotions set uses=uses+1 where upper(code)=pc; end if;
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,oid,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_sale',jsonb_build_object('order',oid,'method',p_method,'promo',pc));
  return plain; end $$;
revoke execute on function public.reseller_sell(uuid,text,text,text,text) from public, anon;
grant execute on function public.reseller_sell(uuid,text,text,text,text) to authenticated;
