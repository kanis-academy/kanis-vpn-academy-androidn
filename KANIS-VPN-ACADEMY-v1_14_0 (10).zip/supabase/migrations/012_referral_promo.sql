-- 012 : (1) le revendeur lie reste affiche meme sans infos ; (2) codes promo crees par le revendeur.
-- A executer UNE fois dans Supabase > SQL Editor, APRES 011_referral.sql.

-- 1) seller_info : renvoie toujours le revendeur actif (infos eventuellement vides)
create or replace function public.seller_info(p_seller uuid) returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare p record; m json;
begin
  select * into p from profiles where id=p_seller and role='reseller' and reseller_status='active';
  if p.id is null then return null; end if;
  select coalesce(json_agg(json_build_object('operator',operator,'number',number,'holder_name',holder_name,'instructions',instructions) order by created_at),'[]'::json)
    into m from reseller_payment_methods where reseller_id=p.id;
  return json_build_object('name',p.full_name,'phone',nullif(trim(coalesce(p.phone,'')),''),'methods',m);
end $$;
revoke all on function public.seller_info(uuid) from public, anon, authenticated;

-- 2) codes promo du revendeur : pourcentage 1 a 30, code 4 a 16 caracteres, uniquement les siens
alter table public.promotions add column if not exists reseller_id uuid references public.profiles(id) on delete cascade;
drop policy if exists pr_reseller_sel on public.promotions;
create policy pr_reseller_sel on public.promotions for select using (reseller_id=auth.uid());
drop policy if exists pr_reseller_ins on public.promotions;
create policy pr_reseller_ins on public.promotions for insert with check (
  reseller_id=auth.uid() and kind='percent' and value between 1 and 30 and not applies_to_activation
  and code ~ '^[A-Z0-9-]{4,16}$'
  and exists(select 1 from public.profiles where id=auth.uid() and role='reseller' and reseller_status='active'));
drop policy if exists pr_reseller_upd on public.promotions;
create policy pr_reseller_upd on public.promotions for update using (reseller_id=auth.uid()) with check (
  reseller_id=auth.uid() and kind='percent' and value between 1 and 30 and not applies_to_activation and code ~ '^[A-Z0-9-]{4,16}$');
drop policy if exists pr_reseller_del on public.promotions;
create policy pr_reseller_del on public.promotions for delete using (reseller_id=auth.uid());

-- 3) vente du revendeur avec code promo optionnel
drop function if exists public.reseller_sell(uuid,text,text,text);
create or replace function public.reseller_sell(p_course uuid, p_client_name text, p_client_phone text default null, p_method text default null, p_promo text default null) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; amt int; oid uuid; plain text; sl text; pre text; pc text; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  if coalesce(trim(p_client_name),'')='' then raise exception 'Nom du client requis'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  pc:=nullif(upper(trim(coalesce(p_promo,''))),'');
  amt:=price_for(p_course,pc,false);
  insert into orders(reseller_id,course_id,client_name,client_phone,amount,promo_code,status) values(me.id,p_course,trim(p_client_name),nullif(p_client_phone,''),amt,pc,'confirmed') returning id into oid;
  if pc is not null then update promotions set uses=uses+1 where upper(code)=pc; end if;
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,oid,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_sale',jsonb_build_object('order',oid,'method',p_method,'promo',pc));
  return plain; end $$;
revoke execute on function public.reseller_sell(uuid,text,text,text,text) from public, anon;
grant execute on function public.reseller_sell(uuid,text,text,text,text) to authenticated;
