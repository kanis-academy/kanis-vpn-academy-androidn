# Keep WireGuard and Xray JNI/AIDL classes
-keep class com.wireguard.** { *; }
-keep class libXray.** { *; }
-keep class go.** { *; }
-dontwarn kotlin.**
