package com.kanis.vpn.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.kanis.vpn.R
import com.kanis.vpn.databinding.ActivityProfilesBinding
import com.kanis.vpn.model.Profile
import com.kanis.vpn.profile.ProfileRepository

class ProfilesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfilesBinding
    private lateinit var repo: ProfileRepository
    private lateinit var adapter: ProfilesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfilesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repo = ProfileRepository(this)

        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = ProfilesAdapter(
            items = mutableListOf(),
            onClick = { profile -> openProfile(profile) },
            onMoreClick = { profile, anchor -> showMenu(profile, anchor) }
        )
        binding.recyclerProfiles.layoutManager = LinearLayoutManager(this)
        binding.recyclerProfiles.adapter = adapter

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val all = repo.loadAll()
        adapter.update(all)
        binding.txtEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openProfile(profile: Profile) {
        setResult(RESULT_OK, Intent().putExtra("profile_id", profile.id))
        finish()
    }

    private fun showMenu(profile: Profile, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menuInflater.inflate(R.menu.menu_profile_item, popup.menu)
        popup.menu.findItem(R.id.action_lock).isVisible = !profile.locked
        popup.menu.findItem(R.id.action_unlock).isVisible = profile.locked

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_lock -> {
                    repo.setLocked(profile.id, true)
                    refresh()
                    true
                }
                R.id.action_unlock -> {
                    repo.setLocked(profile.id, false)
                    refresh()
                    true
                }
                R.id.action_share -> {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "KANIS VPN profile: ${profile.remark}")
                        putExtra(Intent.EXTRA_TEXT, profile.toExportText())
                    }
                    startActivity(Intent.createChooser(shareIntent, getString(R.string.btn_share)))
                    true
                }
                R.id.action_delete -> {
                    if (profile.locked) {
                        Toast.makeText(this, R.string.toast_locked_cannot_edit, Toast.LENGTH_SHORT).show()
                    } else {
                        repo.delete(profile.id)
                        refresh()
                    }
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
}
