package com.kanis.vpn.vpn

import com.kanis.vpn.model.Profile

data class TrafficStats(val rxBytesPerSec: Long, val txBytesPerSec: Long)

interface VpnEngineCallback {
    fun onConnected()
    fun onDisconnected(reason: String?)
    fun onError(message: String)
    fun onStats(stats: TrafficStats)
}

/**
 * One implementation per protocol family. [KanisVpnService] owns the TUN file descriptor
 * (via [android.net.VpnService.Builder]) and hands it to whichever engine the active
 * profile needs.
 */
interface VpnEngine {
    fun start(profile: Profile, tunFd: Int)
    fun stop()
    val isRunning: Boolean

    /** Best-effort throughput snapshot; engines that can't report this return zeros. */
    fun currentStats(): TrafficStats = TrafficStats(0, 0)
}
