package com.kanis.vpn.vpn

import android.content.Context
import com.kanis.vpn.model.Protocol

object VpnEngineFactory {
    fun create(context: Context, protocol: Protocol): VpnEngine = when (protocol) {
        Protocol.WIREGUARD -> WireGuardEngine(context)
        Protocol.VMESS, Protocol.VLESS, Protocol.SHADOWSOCKS, Protocol.TROJAN -> XrayEngine(context)
        Protocol.SSH_TUNNEL -> SshTunnelEngine()
    }
}
