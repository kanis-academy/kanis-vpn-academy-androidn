package com.kanis.vpn.profile

import android.content.Context
import com.kanis.vpn.model.Profile
import org.json.JSONArray
import java.io.File

/**
 * Simple file-backed profile store (no external DB needed). Lives in app-private storage,
 * so it disappears with the app and is never readable by other apps.
 */
class ProfileRepository(context: Context) {

    private val file = File(context.filesDir, "profiles.json")

    @Synchronized
    fun loadAll(): MutableList<Profile> {
        if (!file.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(file.readText())
            MutableList(arr.length()) { i -> Profile.fromJson(arr.getJSONObject(i)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun saveAll(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(it.toJson()) }
        file.writeText(arr.toString())
    }

    @Synchronized
    fun upsert(profile: Profile) {
        val all = loadAll()
        val index = all.indexOfFirst { it.id == profile.id }
        if (index >= 0) {
            val existing = all[index]
            if (existing.locked) {
                // Locked = read-only. Caller must unlock() first to change fields.
                return
            }
            all[index] = profile
        } else {
            all.add(profile)
        }
        saveAll(all)
    }

    @Synchronized
    fun delete(profileId: String) {
        val all = loadAll()
        all.removeAll { it.id == profileId }
        saveAll(all)
    }

    @Synchronized
    fun setLocked(profileId: String, locked: Boolean): Profile? {
        val all = loadAll()
        val index = all.indexOfFirst { it.id == profileId }
        if (index < 0) return null
        val p = all[index]
        p.locked = locked
        p.lockedAtEpochMs = if (locked) System.currentTimeMillis() else null
        all[index] = p
        saveAll(all)
        return p
    }
}
