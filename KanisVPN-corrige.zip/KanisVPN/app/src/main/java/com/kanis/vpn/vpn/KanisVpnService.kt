package com.kanis.vpn.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.kanis.vpn.R
import com.kanis.vpn.model.Profile
import com.kanis.vpn.model.Protocol
import com.kanis.vpn.ui.MainActivity

/**
 * Owns the Android TUN interface for every protocol except WireGuard (which runs its own
 * service via com.wireguard.android.backend.GoBackend, declared separately in the manifest).
 * MainActivity binds to this with start/stop actions and listens for broadcasts for status.
 */
class KanisVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.kanis.vpn.action.CONNECT"
        const val ACTION_DISCONNECT = "com.kanis.vpn.action.DISCONNECT"
        const val EXTRA_PROFILE_JSON = "profile_json"

        const val ACTION_STATUS = "com.kanis.vpn.STATUS"
        const val EXTRA_STATUS = "status"
        const val EXTRA_RX = "rx"
        const val EXTRA_TX = "tx"
        const val STATUS_CONNECTING = "connecting"
        const val STATUS_CONNECTED = "connected"
        const val STATUS_DISCONNECTED = "disconnected"
        const val STATUS_ERROR = "error"

        private const val CHANNEL_ID = "kanis_vpn_channel"
        private const val NOTIF_ID = 42
    }

    private var tunInterface: ParcelFileDescriptor? = null
    private var engine: VpnEngine? = null
    private val statsHandler = Handler(Looper.getMainLooper())
    private var statsRunnable: Runnable? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val json = intent.getStringExtra(EXTRA_PROFILE_JSON)
                if (json != null) {
                    val profile = Profile.fromJson(org.json.JSONObject(json))
                    connect(profile)
                }
            }
            ACTION_DISCONNECT -> disconnect()
        }
        return START_NOT_STICKY
    }

    private fun connect(profile: Profile) {
        broadcastStatus(STATUS_CONNECTING)
        startForeground(NOTIF_ID, buildNotification("Connecting…"))

        Thread {
            try {
                if (profile.protocol == Protocol.WIREGUARD) {
                    // WireGuard (GoBackend) creates its own TUN: we must not open another one.
                    val wg = VpnEngineFactory.create(this, profile.protocol)
                    engine = wg
                    wg.start(profile, -1)
                    broadcastStatus(STATUS_CONNECTED)
                    startForeground(NOTIF_ID, buildNotification("Connected"))
                    statsHandler.post { startStatsLoop() }
                    return@Thread
                }

                val builder = Builder()
                    .setSession("KANIS VPN")
                    .addAddress("10.10.14.1", 24)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                    .setMtu(1500)

                tunInterface = builder.establish()
                val fd = tunInterface?.fd ?: throw IllegalStateException("Could not establish TUN interface")

                val newEngine = VpnEngineFactory.create(this, profile.protocol)
                engine = newEngine
                if (newEngine is XrayEngine) {
                    newEngine.setCallback(object : VpnEngineCallback {
                        override fun onConnected() {
                            broadcastStatus(STATUS_CONNECTED)
                            startForeground(NOTIF_ID, buildNotification("Connected"))
                        }
                        override fun onDisconnected(reason: String?) {
                            broadcastStatus(STATUS_DISCONNECTED)
                        }
                        override fun onError(message: String) {
                            broadcastStatus(STATUS_ERROR, extra = message)
                        }
                        override fun onStats(stats: TrafficStats) {
                            broadcastStats(stats)
                        }
                    })
                }
                newEngine.start(profile, fd)
                statsHandler.post { startStatsLoop() }
            } catch (e: Exception) {
                broadcastStatus(STATUS_ERROR, extra = e.message)
                statsHandler.post { disconnect() }
            }
        }.start()
    }

    private fun startStatsLoop() {
        stopStatsLoop()
        val runnable = object : Runnable {
            override fun run() {
                engine?.let { broadcastStats(it.currentStats()) }
                statsHandler.postDelayed(this, 1000)
            }
        }
        statsRunnable = runnable
        statsHandler.post(runnable)
    }

    private fun stopStatsLoop() {
        statsRunnable?.let { statsHandler.removeCallbacks(it) }
        statsRunnable = null
    }

    private fun disconnect() {
        stopStatsLoop()
        try {
            engine?.stop()
        } catch (e: Exception) {
            // ignore
        }
        engine = null
        try {
            tunInterface?.close()
        } catch (e: Exception) {
            // ignore
        }
        tunInterface = null
        broadcastStatus(STATUS_DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }

    override fun onRevoke() {
        disconnect()
        super.onRevoke()
    }

    private fun broadcastStatus(status: String, extra: String? = null) {
        val intent = Intent(ACTION_STATUS).apply {
            putExtra(EXTRA_STATUS, status)
            extra?.let { putExtra("message", it) }
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun broadcastStats(stats: TrafficStats) {
        val intent = Intent(ACTION_STATUS).apply {
            putExtra(EXTRA_STATUS, STATUS_CONNECTED)
            putExtra(EXTRA_RX, stats.rxBytesPerSec)
            putExtra(EXTRA_TX, stats.txBytesPerSec)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun buildNotification(text: String): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "KANIS VPN", NotificationManager.IMPORTANCE_LOW)
            manager?.createNotificationChannel(channel)
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("KANIS VPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
    }
}
