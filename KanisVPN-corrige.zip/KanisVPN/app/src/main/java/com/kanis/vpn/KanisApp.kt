package com.kanis.vpn

import android.app.Application

class KanisApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
