# Connecter KANIS VPN ACADEMY à Supabase (à faire une seule fois)

Projet actuel : `qoxsvtzjqprwzegbsnhv` (déjà dans `www/js/config.js`).

1. **Base de données** : Supabase → SQL Editor → colle tout `supabase/TOUT-EN-UN.sql` → Run.
   (Attention : le script commence par effacer le schéma `public`. Ne le relance pas quand tu as de vraies données.)
   Autre option : GitHub → Actions → « Installer la base Supabase », tape `OUI` (secrets DB_HOST, DB_USER, DB_PASSWORD requis).
2. **Comptes sans inscription** : Authentication → Sign In / Providers → active **Allow anonymous sign-ins** → Save.
3. **Connexion admin** : Authentication → Sign In / Providers → Email : désactive **Confirm email**.
4. **Liens** : Authentication → URL Configuration → Site URL et Redirect URLs = `kanisvpn://auth-callback`.
5. **Compte administrateur** : Authentication → Users → Add user (e-mail + mot de passe), puis dans SQL Editor :
   `update public.profiles set role='admin' where email='TON_EMAIL';`
6. **Clés** : `www/js/config.js` doit contenir l'URL et la clé `sb_publishable_…` du MÊME projet. Jamais la clé `service_role`.
7. **Stockage** : les dossiers `proofs`, `videos`, `thumbs` sont créés par le script SQL (vidéos : 50 Mo max par fichier en gratuit).
7b. **Base déjà installée (v1.9 ou avant)** : exécute seulement `supabase/migrations/007_manual_payments_codes.sql` (paiements manuels et codes admin).
8. **APK** : GitHub → Actions → « Build KANIS VPN ACADEMY APK » → télécharge `KANIS-VPN-ACADEMY-APK`.
9. **Vérification** : ouvre l'app → menu ☰ → **Vérifier la connexion**. Chaque ligne doit être en ✓ (vert).
   Une ligne ✗ indique l'étape à refaire (table absente = étape 1 ; session = étape 2).
