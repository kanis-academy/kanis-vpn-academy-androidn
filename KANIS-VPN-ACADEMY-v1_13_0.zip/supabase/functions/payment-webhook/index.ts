// Edge Function : confirmation de paiement par le fournisseur (Orange Money / Wave).
// À brancher quand le contrat fournisseur est signé. Déploiement : supabase functions deploy payment-webhook
// Secrets requis : WEBHOOK_SECRET (signature du fournisseur). SUPABASE_SERVICE_ROLE_KEY reste côté serveur, jamais dans l'app.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
Deno.serve(async (req) => {
  const raw = await req.text();
  const sig = req.headers.get("x-signature") ?? "";
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(Deno.env.get("WEBHOOK_SECRET")!), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = Array.from(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)))).map((b) => b.toString(16).padStart(2, "0")).join("");
  if (mac !== sig) return new Response("signature invalide", { status: 401 });
  const { payment_id, reference, status } = JSON.parse(raw); // adapter au format réel du fournisseur
  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  if (status === "SUCCESS") {
    const { error } = await db.rpc("confirm_payment", { p_payment: payment_id, p_reference: reference });
    if (error) return new Response(error.message, { status: 400 });
  }
  return new Response("ok");
});
