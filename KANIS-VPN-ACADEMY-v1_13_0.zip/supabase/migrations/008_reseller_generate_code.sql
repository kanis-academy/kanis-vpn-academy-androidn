-- 008 : le revendeur actif génère lui-même un code d'accès (Dark Tunnel / BKCBEBE Tunnel), sans passer par une vente.
create or replace function public.reseller_generate_code(p_course uuid) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; plain text; sl text; pre text; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_code',jsonb_build_object('course',p_course));
  return plain; end $$;
revoke execute on function public.reseller_generate_code(uuid) from public, anon;
grant execute on function public.reseller_generate_code(uuid) to authenticated;
