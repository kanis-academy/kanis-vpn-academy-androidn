-- KANIS VPN ACADEMY 009 : audit final (idempotent, ne supprime aucune donnée)
-- 1) reseller_generate_code : chaque code créé par un revendeur est lié à une commande au prix OFFICIEL (price_for, calculé par le serveur).
--    La commande reste « pending » (aucune vente fictive) et devient « confirmed » quand le client utilise le code (redeem_code).
-- 2) redeem_code : confirme la commande liée à un code revendeur, rattache l'acheteur, garde le verrou anti double utilisation.
-- 3) Droits EXECUTE : aucune fonction appelable sans connexion, sauf is_admin() (utilisée par les politiques RLS) et claim_reset().
-- 4) Pas de faux « Nouvelle commande » admin pour les codes générés.
-- 5) Lecture des fichiers vidéo privés par les acheteurs inscrits (correctif du stockage).

create or replace function public.trg_order_notify() returns trigger language plpgsql security definer set search_path=public,extensions as $$
declare a record; begin
  if coalesce(current_setting('kanis.silent',true),'')='1' then return new; end if;
  if new.kind='course' then
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Nouvelle commande',new.amount||' FCFA en attente de vérification'); end loop;
    if new.reseller_id is not null then perform notify(new.reseller_id,'Commande enregistrée','Vente de '||new.amount||' FCFA en attente de confirmation'); end if;
  else
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Demande d''activation revendeur',new.amount||' FCFA en attente de vérification'); end loop;
  end if; return new; end $$;

drop function if exists public.reseller_generate_code(uuid);
create function public.reseller_generate_code(p_course uuid) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; plain text; sl text; pre text; amt int; oid uuid; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  amt:=price_for(p_course,null,false);
  perform set_config('kanis.silent','1',true);
  insert into orders(reseller_id,course_id,amount,status) values(me.id,p_course,amt,'pending') returning id into oid;
  perform set_config('kanis.silent','0',true);
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,oid,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_code',jsonb_build_object('course',p_course,'order',oid,'amount',amt));
  return plain; end $$;

create or replace function public.redeem_code(p_code text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare ac access_codes; slug text; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into ac from access_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update access_codes set status='used', used_by=auth.uid(), used_at=now() where id=ac.id;
  if ac.order_id is not null then
    update orders o set status='confirmed', buyer_id=auth.uid(),
      client_name=coalesce(o.client_name,(select coalesce(nullif(p.full_name,''),p.email) from profiles p where p.id=auth.uid()))
    where o.id=ac.order_id and o.status='pending' and o.kind='course' and o.reseller_id is not null and o.buyer_id is null;
  end if;
  insert into enrollments(user_id,course_id,order_id) values(auth.uid(),ac.course_id,ac.order_id) on conflict do nothing;
  insert into operation_log(actor,action,detail) values(auth.uid(),'code_redeemed',jsonb_build_object('code_id',ac.id,'course',ac.course_id));
  select courses.slug into slug from courses where id=ac.course_id; return slug; end $$;

-- 5) Stockage des vidéos : un acheteur inscrit doit pouvoir lire le fichier privé de SA formation.
--    L'ancienne règle interrogeait la table videos (réservée à l'admin par RLS) : elle ne renvoyait jamais rien pour un acheteur.
create or replace function public.can_watch_video(p_path text) returns boolean language sql stable security definer set search_path=public,extensions as $$
  select p_path is not null and (is_admin() or exists(select 1 from videos v join enrollments e on e.course_id=v.course_id
    where v.storage_path=p_path and v.is_active and e.user_id=auth.uid())) $$;
drop policy if exists videos_sel on storage.objects;
create policy videos_sel on storage.objects for select to authenticated using(bucket_id='videos' and public.can_watch_video(name));

-- Droits EXECUTE (les fonctions des extensions et les fonctions de déclencheurs ne sont pas touchées ; notify() reste interne)
do $$ declare r record; begin
  for r in select p.oid::regprocedure f, p.proname n from pg_proc p join pg_namespace s on s.oid=p.pronamespace
           where s.nspname='public' and p.prokind='f' and p.prorettype<>'trigger'::regtype
             and not exists(select 1 from pg_depend d where d.objid=p.oid and d.deptype='e') loop
    execute format('revoke execute on function %s from public, anon',r.f);
    if r.n='notify' then
      execute format('revoke execute on function %s from authenticated',r.f);
    else
      execute format('grant execute on function %s to authenticated, service_role',r.f);
    end if;
    if r.n in ('is_admin','claim_reset') then execute format('grant execute on function %s to anon',r.f); end if;
  end loop; end $$;
alter default privileges in schema public revoke execute on functions from anon;
