-- KANIS VPN ACADEMY 005 : les fonctions sécurisées voient pgcrypto
-- À exécuter APRÈS 001 à 004 (et aussi si 001 à 004 sont déjà exécutées).

-- 1) Les fonctions sécurisées doivent voir pgcrypto (digest, crypt, gen_random_bytes), installé dans le schéma "extensions" sur Supabase
do $$ declare r record; begin
  for r in select p.oid::regprocedure as f from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.prosecdef loop
    execute format('alter function %s set search_path = public, extensions', r.f);
  end loop; end $$;
