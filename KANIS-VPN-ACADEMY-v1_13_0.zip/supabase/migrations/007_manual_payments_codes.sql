-- 007 : paiements manuels, codes générés par l'administrateur, vente directe du revendeur.
-- Sans risque pour les données existantes : à exécuter seul si la base est déjà installée.
alter table public.access_codes alter column order_id drop not null;
alter table public.reseller_codes alter column request_id drop not null;
alter table public.reseller_codes alter column user_id drop not null;
alter table public.reseller_codes add column if not exists hint text;
alter table public.reseller_codes add column if not exists created_by uuid;

-- Un code revendeur créé par l'admin (sans demande) peut être utilisé par n'importe quel compte, une seule fois.
create or replace function public.redeem_reseller_code(p_code text) returns void language plpgsql security definer set search_path=public,extensions as $$
declare rc reseller_codes; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into rc from reseller_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' and (user_id=auth.uid() or user_id is null) for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update reseller_codes set status='used',used_at=now(),user_id=auth.uid() where id=rc.id;
  update profiles set role='reseller',reseller_status='active' where id=auth.uid() and role<>'admin';
  insert into operation_log(actor,action,detail) values(auth.uid(),'reseller_activated',jsonb_build_object('code_id',rc.id)); end $$;

-- Admin : générer un code de formation ('course') ou un code d'accès revendeur ('reseller'). Valeur affichée une seule fois.
create or replace function public.admin_generate_code(p_kind text, p_course uuid default null) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare plain text; sl text; pre text; begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  if p_kind='reseller' then
    plain:='RV-'||upper(substr(encode(gen_random_bytes(6),'hex'),1,10));
    insert into reseller_codes(code_hash,hint,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),auth.uid());
  elsif p_kind='course' then
    select c.slug into sl from courses c where c.id=p_course;
    if not found then raise exception 'Formation introuvable'; end if;
    pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
    plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
    insert into access_codes(code_hash,hint,course_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,auth.uid());
  else raise exception 'Type de code invalide'; end if;
  insert into operation_log(actor,action,detail) values(auth.uid(),'admin_code_'||p_kind,jsonb_build_object('course',p_course));
  return plain; end $$;

-- Revendeur : le client a payé directement sur le numéro du revendeur ; vente enregistrée + code généré (aucune commission).
create or replace function public.reseller_sell(p_course uuid, p_client_name text, p_client_phone text default null, p_method text default null) returns text
language plpgsql security definer set search_path=public,extensions as $$
declare me profiles; amt int; oid uuid; plain text; sl text; pre text; begin
  select * into me from profiles where id=auth.uid();
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  if coalesce(trim(p_client_name),'')='' then raise exception 'Nom du client requis'; end if;
  select c.slug into sl from courses c where c.id=p_course and c.active;
  if not found then raise exception 'Formation introuvable'; end if;
  amt:=price_for(p_course,null,false);
  insert into orders(reseller_id,course_id,client_name,client_phone,amount,status) values(me.id,p_course,trim(p_client_name),nullif(p_client_phone,''),amt,'confirmed') returning id into oid;
  pre:=case when sl like 'dark%' then 'DT' when sl like 'bk%' then 'BK' else upper(substr(sl,1,2)) end;
  plain:=pre||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),p_course,oid,me.id);
  insert into operation_log(actor,action,detail) values(me.id,'reseller_sale',jsonb_build_object('order',oid,'method',p_method));
  return plain; end $$;

revoke execute on function public.admin_generate_code(text,uuid) from public, anon;
revoke execute on function public.reseller_sell(uuid,text,text,text) from public, anon;
grant execute on function public.admin_generate_code(text,uuid) to authenticated;
grant execute on function public.reseller_sell(uuid,text,text,text) to authenticated;
