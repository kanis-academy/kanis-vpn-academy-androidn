\set QUIET on
\pset tuples_only on
\pset pager off
create schema tt; grant usage on schema tt to public;
create table tt.v(k text primary key, v text); grant all on tt.v to public;
create function tt.assert(c boolean, m text default 'condition fausse') returns void language plpgsql as $$ begin if c is not true then raise exception 'ASSERT: %', m; end if; end $$;
create function tt.get(p text) returns text language sql stable as $$ select v from tt.v where k=p $$;
grant execute on function tt.assert(boolean,text), tt.get(text) to public;
create function tt.try(r text, sub uuid, q text, expect_ok boolean, label text) returns text language plpgsql as $$
declare res text:='ok'; ok boolean; begin
  perform set_config('request.jwt.claim.sub', coalesce(sub::text,''), true);
  execute 'set local role '||r;
  begin execute q; ok:=true; exception when others then ok:=false; res:=sqlerrm; end;
  execute 'reset role';
  return case when ok=expect_ok then 'PASS' else 'FAIL' end||' | '||label||' | '||left(res,70); end $$;
grant execute on function tt.try(text,uuid,text,boolean,text) to public;
grant select on storage.objects to authenticated;
insert into auth.users(id,email,is_anonymous,raw_user_meta_data) values
 ('a0000000-0000-0000-0000-000000000001','admin@kanis.test',false,'{}'),
 ('b0000000-0000-0000-0000-000000000001',null,true,'{"full_name":"Acheteur Un"}'),
 ('b0000000-0000-0000-0000-000000000002',null,true,'{"full_name":"Acheteur Deux"}'),
 ('c0000000-0000-0000-0000-000000000001',null,true,'{"want_reseller":"true","full_name":"Revendeur Un"}'),
 ('c0000000-0000-0000-0000-000000000002',null,true,'{"want_reseller":"true","full_name":"Revendeur Deux"}'),
 ('d0000000-0000-0000-0000-000000000001',null,true,'{"role":"admin","full_name":"Pirate"}');
update profiles set role='admin' where id='a0000000-0000-0000-0000-000000000001';
select case when role='buyer' then 'PASS' else 'FAIL' end||' | INSCRIPTION | metadata role=admin ignoré => '||role from profiles where id='d0000000-0000-0000-0000-000000000001';
select case when role='reseller' and reseller_status='pending' then 'PASS' else 'FAIL' end||' | INSCRIPTION | revendeur demandé => reseller/pending (aucun privilège) => '||role||'/'||reseller_status from profiles where id='c0000000-0000-0000-0000-000000000001';
insert into videos(course_id,title,url,position,storage_path,is_active) select id,'Privée '||slug,'https://x/'||slug,1,'vid/'||slug||'.mp4',true from courses;
insert into videos(course_id,title,url,position,is_active) select id,'Lien '||slug,'https://youtu.be/'||slug,2,true from courses;
insert into storage.objects(bucket_id,name) select 'videos',storage_path from videos where storage_path is not null;
\echo === ACHETEUR ===
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from courses)=2,'2 formations')$q$,true,'ACHETEUR | voit les 2 formations');
select tt.try('authenticated','@B1@',$q$update profiles set role='admin' where id='@B1@'$q$,false,'ACHETEUR | se promouvoir admin refusé');
select tt.try('authenticated','@B1@',$q$update profiles set balance=99999 where id='@B1@'$q$,false,'ACHETEUR | modifier son solde refusé');
select tt.try('authenticated','@B1@',$q$update profiles set reseller_status='active' where id='@B1@'$q$,false,'ACHETEUR | s''activer revendeur refusé');
select tt.try('authenticated','@B1@',$q$update profiles set full_name='Nouveau Nom' where id='@B1@'$q$,true,'ACHETEUR | modifier son nom (autorisé)');
select tt.try('authenticated','@B1@',$q$update profiles set full_name='Piraté' where id='@B2@'$q$,true,'ACHETEUR | modifier le profil d''un autre (0 ligne touchée)');
select case when full_name='Acheteur Deux' then 'PASS' else 'FAIL' end||' | ACHETEUR | profil de l''autre inchangé => '||full_name from profiles where id='b0000000-0000-0000-0000-000000000002';
select tt.try('authenticated','@B1@',$q$select admin_stats()$q$,false,'ACHETEUR | tableau de bord admin refusé');
select tt.try('authenticated','@B1@',$q$select admin_generate_code('course',@DT@)$q$,false,'ACHETEUR | admin_generate_code refusé');
select tt.try('authenticated','@B1@',$q$select admin_set_role('@B2@','admin')$q$,false,'ACHETEUR | admin_set_role refusé');
select tt.try('authenticated','@B1@',$q$select admin_review_request(gen_random_uuid(),'approved')$q$,false,'ACHETEUR | admin_review_request refusé');
select tt.try('authenticated','@B1@',$q$select notify('@B2@','x','y')$q$,false,'ACHETEUR | notify() non appelable');
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from access_codes)=0,'voit des codes')$q$,true,'ACHETEUR | ne voit aucun code');
select tt.try('authenticated','@B1@',$q$insert into enrollments(user_id,course_id) values('@B1@',@DT@)$q$,false,'ACHETEUR | INSERT enrollments direct refusé');
select tt.try('authenticated','@B1@',$q$insert into orders(buyer_id,course_id,amount,status) values('@B1@',@DT@,0,'confirmed')$q$,false,'ACHETEUR | INSERT orders direct refusé');
select tt.try('authenticated','@B1@',$q$select reseller_sell(@DT@,'Client')$q$,false,'ACHETEUR | reseller_sell refusé');
select tt.try('authenticated','@B1@',$q$select reseller_generate_code(@DT@)$q$,false,'ACHETEUR | reseller_generate_code refusé');
\echo --- paiement manuel ---
select tt.try('authenticated','@B1@',$q$insert into tt.v select 'ord1', create_order(@DT@,null,'manual')$q$,true,'ACHETEUR | create_order (paiement manuel)');
select case when o.amount=c.price then 'PASS' else 'FAIL' end||' | ACHETEUR | montant fixé par le serveur = '||o.amount||' FCFA' from orders o join courses c on c.id=o.course_id where o.id=tt.get('ord1')::uuid;
select tt.try('authenticated','@B1@',$q$select tt.assert(cardinality(my_access())=0,'accès avant validation')$q$,true,'ACHETEUR | aucun accès avant validation du paiement');
select tt.try('authenticated','@B1@',$q$select confirm_payment((select id from payments limit 1))$q$,false,'ACHETEUR | confirmer son propre paiement refusé');
select tt.try('authenticated','@A@',$q$select confirm_payment((select id from payments where order_id=tt.get('ord1')::uuid))$q$,true,'ADMIN    | confirme le paiement');
select tt.try('authenticated','@B1@',$q$select tt.assert('dark-tunnel'=any(my_access()),'pas d''accès')$q$,true,'ACHETEUR | accès Dark Tunnel après validation');
select tt.try('authenticated','@B1@',$q$select tt.assert(not 'bkcbebe-tunnel'=any(my_access()),'accès BK')$q$,true,'ACHETEUR | pas d''accès à BKCBEBE');
\echo === CODES D ACCES ===
select tt.try('authenticated','@A@',$q$insert into tt.v select 'dt1', admin_generate_code('course',@DT@)$q$,true,'ADMIN    | génère un code Dark Tunnel');
select tt.try('authenticated','@A@',$q$insert into tt.v select 'bk1', admin_generate_code('course',@BK@)$q$,true,'ADMIN    | génère un code BKCBEBE');
select case when count(*)=count(*) filter (where code_hash ~ '^[0-9a-f]{64}$') and count(*)>0 then 'PASS' else 'FAIL' end||' | CODES | tous stockés hashés ('||count(*)||') ; clair présent en base ? '||exists(select 1 from access_codes a, tt.v t where t.k in ('dt1','bk1') and a.code_hash=t.v) from access_codes;
select tt.try('authenticated','@B2@',$q$select redeem_code('FAUX-CODE')$q$,false,'CODE     | code invalide refusé');
select tt.try('authenticated','@B2@',$q$select redeem_code(tt.get('dt1'))$q$,true,'CODE     | code valide utilisé');
select tt.try('authenticated','@B1@',$q$select redeem_code(tt.get('dt1'))$q$,false,'CODE     | code DÉJÀ utilisé refusé');
select case when array_to_string(array(select c.slug from enrollments e join courses c on c.id=e.course_id where e.user_id='b0000000-0000-0000-0000-000000000002'),',')='dark-tunnel' then 'PASS' else 'FAIL' end||' | CODE     | un code DT ne débloque que DT';
update access_codes set status='revoked' where code_hash=encode(extensions.digest(tt.get('bk1'),'sha256'),'hex');
select tt.try('authenticated','@B2@',$q$select redeem_code(tt.get('bk1'))$q$,false,'CODE     | code RÉVOQUÉ refusé');
select tt.try('authenticated',null,$q$select redeem_code('X')$q$,false,'CODE     | session sans utilisateur refusée');
select tt.try('anon',null,$q$select redeem_code('X')$q$,false,'CODE     | rôle anon refusé (EXECUTE retiré)');
select tt.try('anon',null,$q$select admin_generate_code('reseller')$q$,false,'CODE     | anon : admin_generate_code refusé');
select tt.try('anon',null,$q$select tt.assert((select count(*) from courses)>=0)$q$,true,'ANON     | lecture catalogue sans erreur de droits (is_admin dans RLS)');
\echo === VIDEOS ===
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from get_video_sources('bkcbebe-tunnel'))=0,'sources visibles')$q$,true,'VIDÉO    | non inscrit : 0 source BK');
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from list_course_videos('bkcbebe-tunnel'))=2 and (select count(*) from list_course_videos('bkcbebe-tunnel') where unlocked)=0,'liste')$q$,true,'VIDÉO    | liste visible, 2 vidéos verrouillées (cadenas)');
select tt.try('authenticated','@B2@',$q$select tt.assert((select count(*) from get_video_sources('dark-tunnel'))=2,'2 sources')$q$,true,'VIDÉO    | inscrit DT : 2 sources DT');
select tt.try('authenticated','@B2@',$q$select tt.assert((select count(*) from get_video_sources('bkcbebe-tunnel'))=0,'BK visible')$q$,true,'VIDÉO    | inscrit DT : 0 source BK');
select tt.try('authenticated','@B2@',$q$select tt.assert((select count(*) from storage.objects where bucket_id='videos' and name='vid/dark-tunnel.mp4')=1,'DT')$q$,true,'STOCKAGE | fichier DT lisible (inscrit)');
select tt.try('authenticated','@B2@',$q$select tt.assert((select count(*) from storage.objects where bucket_id='videos' and name='vid/bkcbebe-tunnel.mp4')=0,'BK')$q$,true,'STOCKAGE | fichier BK illisible (non inscrit)');
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from storage.objects where bucket_id='videos' and name='vid/bkcbebe-tunnel.mp4')=0,'BK')$q$,true,'STOCKAGE | acheteur 1 : fichier BK illisible');
select case when (select count(*) from get_video_sources('dark-tunnel') where url is not null and storage_path is not null)=0 then 'PASS' else 'FAIL' end||' | VIDÉO | url jamais mélangée avec storage_path (admin)' from (select set_config('request.jwt.claim.sub','@A@',false)) s;
\echo === REVENDEUR : ACTIVATION MANUELLE ===
select tt.try('authenticated','@R1@',$q$select reseller_sell(@DT@,'Client')$q$,false,'REVENDEUR | inactif : vente refusée');
select tt.try('authenticated','@R1@',$q$select reseller_generate_code(@DT@)$q$,false,'REVENDEUR | inactif : génération refusée');
select tt.try('authenticated','@R1@',$q$select redeem_reseller_code('RV-FAUX')$q$,false,'REVENDEUR | faux code d''activation refusé');
select tt.try('authenticated','@R1@',$q$select submit_reseller_request('Revendeur Un','70000001','r1@x.com','70000001',3000,'c0000000-9999-0000-0000-000000000001/preuve.jpg')$q$,false,'REVENDEUR | preuve dans le dossier d''un autre refusée');
select tt.try('authenticated','@R1@',$q$insert into tt.v select 'req1', submit_reseller_request('Revendeur Un','70000001','r1@x.com','70000001',3000,'c0000000-0000-0000-0000-000000000001/preuve.jpg')$q$,true,'REVENDEUR | demande d''activation + preuve (pending)');
select tt.try('authenticated','@R2@',$q$insert into tt.v select 'req2', submit_reseller_request('Revendeur Deux','70000002','r2@x.com','70000002',3000,'c0000000-0000-0000-0000-000000000002/preuve.jpg')$q$,true,'REVENDEUR | 2e demande (sera refusée)');
select case when (select status from reseller_requests where id=tt.get('req1')::uuid)='pending' then 'PASS' else 'FAIL' end||' | REVENDEUR | statut enregistré = pending';
select tt.try('authenticated','@R2@',$q$select tt.assert((select count(*) from reseller_requests where user_id<>'@R2@')=0,'voit la demande d''un autre')$q$,true,'REVENDEUR | ne voit pas les demandes des autres');
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from reseller_requests)=0,'voit demandes')$q$,true,'ACHETEUR  | ne voit aucune demande');
insert into storage.objects(bucket_id,name,owner) values('proofs','c0000000-0000-0000-0000-000000000001/preuve.jpg',null);
select tt.try('authenticated','@R2@',$q$select tt.assert((select count(*) from storage.objects where bucket_id='proofs')=0,'preuve exposée')$q$,true,'STOCKAGE  | preuve de paiement illisible par un autre utilisateur');
select tt.try('authenticated','@A@',$q$select tt.assert((select count(*) from storage.objects where bucket_id='proofs')=1,'admin ne voit pas')$q$,true,'STOCKAGE  | admin lit la preuve');
select tt.try('authenticated','@R1@',$q$select admin_review_request(tt.get('req1')::uuid,'approved')$q$,false,'REVENDEUR | s''auto-approuver refusé');
select tt.try('authenticated','@A@',$q$insert into tt.v select 'rv1', admin_review_request(tt.get('req1')::uuid,'approved','preuve vérifiée')$q$,true,'ADMIN    | accepte la demande => code RV généré');
select tt.try('authenticated','@A@',$q$select admin_review_request(tt.get('req1')::uuid,'approved')$q$,false,'ADMIN    | redécider une demande déjà traitée refusé');
select tt.try('authenticated','@A@',$q$select admin_review_request(tt.get('req2')::uuid,'refused','preuve illisible')$q$,true,'ADMIN    | refuse la 2e demande avec note');
select case when (select count(*) from reseller_codes where user_id='c0000000-0000-0000-0000-000000000002')=0 and (select status from reseller_requests where id=tt.get('req2')::uuid)='refused' then 'PASS' else 'FAIL' end||' | ADMIN    | demande refusée => aucun code créé';
select tt.try('authenticated','@B1@',$q$select redeem_reseller_code(tt.get('rv1'))$q$,false,'REVENDEUR | code RV d''un autre utilisateur refusé');
select tt.try('authenticated','@R1@',$q$select redeem_reseller_code(tt.get('rv1'))$q$,true,'REVENDEUR | saisit son code => activation');
select case when role='reseller' and reseller_status='active' then 'PASS' else 'FAIL' end||' | REVENDEUR | compte actif => '||role||'/'||reseller_status from profiles where id='c0000000-0000-0000-0000-000000000001';
select tt.try('authenticated','@R1@',$q$select redeem_reseller_code(tt.get('rv1'))$q$,false,'REVENDEUR | code d''activation déjà utilisé refusé');
select tt.try('authenticated','@A@',$q$insert into tt.v select 'rvdirect', admin_generate_code('reseller')$q$,true,'ADMIN    | activation directe (code RV)');
select case when exists(select 1 from operation_log where action='admin_code_reseller') then 'PASS' else 'FAIL' end||' | ADMIN    | activation directe tracée dans operation_log';
select tt.try('authenticated','@R2@',$q$select redeem_reseller_code(tt.get('rvdirect'))$q$,true,'REVENDEUR | code RV direct (admin) accepté par un compte en attente');
\echo === REVENDEUR : VENTES ET CODES ===
insert into price_promos(course_id,promo_price,ends_at) select id,1500,now()+interval '1 day' from courses where slug='bkcbebe-tunnel';
select tt.try('authenticated','@R1@',$q$insert into tt.v select 'sell_dt', reseller_sell(@DT@,'Client Awa','70112233','Orange Money')$q$,true,'VENTE    | vente Dark Tunnel');
select tt.try('authenticated','@R1@',$q$insert into tt.v select 'sell_bk', reseller_sell(@BK@,'Client Issa')$q$,true,'VENTE    | vente BKCBEBE (promo active)');
select case when (select amount from orders where client_name='Client Awa')=2500 and (select amount from orders where client_name='Client Issa')=1500 then 'PASS' else 'FAIL' end||' | VENTE    | prix officiel/promo imposé par le serveur (2500 et 1500)';
select case when (select count(*) from orders o join access_codes a on a.order_id=o.id where o.reseller_id='c0000000-0000-0000-0000-000000000001' and o.status='confirmed')=2 then 'PASS' else 'FAIL' end||' | VENTE    | 1 commande confirmée = 1 code lié (pas de doublon)';
select tt.try('authenticated','@R1@',$q$update orders set amount=1 where reseller_id='@R1@'$q$,true,'VENTE    | modifier le montant d''une commande (0 ligne)');
select case when (select min(amount) from orders where reseller_id='c0000000-0000-0000-0000-000000000001')=1500 then 'PASS' else 'FAIL' end||' | VENTE    | montants inchangés après tentative de modification';
select count(*) as admin_notifs_avant from notifications n join profiles p on p.id=n.user_id where p.role='admin' \gset
select tt.try('authenticated','@R1@',$q$insert into tt.v select 'gen_bk', reseller_generate_code(@BK@)$q$,true,'CODE REV | bouton « BKCBEBE TUNNEL » : code généré');
select tt.try('authenticated','@R1@',$q$insert into tt.v select 'gen_dt', reseller_generate_code(@DT@)$q$,true,'CODE REV | bouton « DARK TUNNEL » : code généré');
select case when (select status from orders where id=(select order_id from access_codes where code_hash=encode(extensions.digest(tt.get('gen_bk'),'sha256'),'hex')))='pending' and (select amount from orders where id=(select order_id from access_codes where code_hash=encode(extensions.digest(tt.get('gen_bk'),'sha256'),'hex')))=1500 then 'PASS' else 'FAIL' end||' | CODE REV | commande liée au prix officiel/promo, en attente (pas de vente fictive)';
select case when (select count(*) from notifications n join profiles p on p.id=n.user_id where p.role='admin')=:admin_notifs_avant then 'PASS' else 'FAIL' end||' | CODE REV | pas de fausse notification « Nouvelle commande » à l''admin';
select tt.try('authenticated','@B1@',$q$select redeem_code(tt.get('gen_bk'))$q$,true,'CODE REV | le client utilise le code BKCBEBE');
select case when (select status||'/'||buyer_id::text||'/'||client_name from orders where id=(select order_id from access_codes where code_hash=encode(extensions.digest(tt.get('gen_bk'),'sha256'),'hex')))='confirmed/b0000000-0000-0000-0000-000000000001/Nouveau Nom' then 'PASS' else 'FAIL' end||' | CODE REV | utilisation => commande confirmée + acheteur rattaché';
select tt.try('authenticated','@B2@',$q$select redeem_code(tt.get('gen_bk'))$q$,false,'CODE REV | 2e utilisation refusée');
select tt.try('authenticated','@B1@',$q$select tt.assert('bkcbebe-tunnel'=any(my_access()),'inscription')$q$,true,'CODE REV | formation BKCBEBE débloquée pour le client');
select tt.try('authenticated','@R1@',$q$select tt.assert((select count(*) from access_codes where created_by<>'@R1@')=0 and (select count(*) from access_codes)=4,'visibilité codes')$q$,true,'HISTORIQUE| le revendeur voit ses 4 codes et aucun autre');
select tt.try('authenticated','@R2@',$q$select tt.assert((select count(*) from orders)=0,'voit ventes')$q$,true,'HISTORIQUE| un autre revendeur ne voit aucune de ces ventes');
select tt.try('authenticated','@A@',$q$select tt.assert((select count(*) from orders where reseller_id='@R1@')=4,'admin ventes')$q$,true,'HISTORIQUE| l''admin voit toutes les ventes (4)');
select tt.try('authenticated','@B1@',$q$select tt.assert((select count(*) from operation_log)=0,'journal visible')$q$,true,'SÉCURITÉ | le journal des opérations est invisible aux non-admin');
\echo === ADMIN ===
select tt.try('authenticated','@A@',$q$select admin_stats()$q$,true,'ADMIN    | tableau de bord');
select tt.try('authenticated','@A@',$q$select admin_set_reseller('@R1@','suspended')$q$,true,'ADMIN    | suspend un revendeur');
select tt.try('authenticated','@R1@',$q$select reseller_sell(@DT@,'Client Suspendu')$q$,false,'ADMIN    | revendeur suspendu : vente refusée');
select tt.try('authenticated','@R1@',$q$select reseller_generate_code(@DT@)$q$,false,'ADMIN    | revendeur suspendu : code refusé');
select tt.try('authenticated','@A@',$q$select admin_set_reseller('@R1@','active')$q$,true,'ADMIN    | réactive le revendeur');
select tt.try('authenticated','@A@',$q$select tt.assert((select count(*) from profiles)=6,'liste utilisateurs')$q$,true,'ADMIN    | liste des 6 comptes');
select tt.try('authenticated','@A@',$q$update courses set price=3000 where slug='dark-tunnel'$q$,true,'ADMIN    | modifie le prix d''une formation');
select tt.try('authenticated','@B1@',$q$update courses set price=1 where slug='dark-tunnel'$q$,true,'ACHETEUR | modifier un prix (0 ligne)');
select case when (select price from courses where slug='dark-tunnel')=3000 then 'PASS' else 'FAIL' end||' | ACHETEUR | prix inchangé après tentative';
select tt.try('authenticated','@A@',$q$select tt.assert(price_for((select id from courses where slug='dark-tunnel'),null)=3000,'prix')$q$,true,'ADMIN    | le nouveau prix s''applique via price_for');
select tt.try('anon',null,$q$select tt.assert((select count(*) from profiles)=0,'profils visibles sans connexion')$q$,true,'ANON     | aucun profil lisible sans connexion');
select tt.try('anon',null,$q$select tt.assert((select count(*) from orders)+(select count(*) from access_codes)=0,'données visibles')$q$,true,'ANON     | aucune commande ni code lisible');
