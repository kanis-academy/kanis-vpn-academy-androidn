# KANIS VPN ACADEMY — Rapport d'audit v1.12.0 (06/11/2026)

## Ce qui n'a PAS pu être fait ici (à lire en premier)
- **L'APK n'a pas été compilé** : l'environnement n'a pas accès au réseau (npm, Android SDK). Le workflow est vérifié à la lecture et chaque script a été validé, mais seule votre exécution GitHub Actions prouvera la compilation.
- **Aucun test sur votre vrai Supabase** (réseau bloqué). Les tests SQL ont été faits sur un PostgreSQL local avec une simulation de Supabase (auth, storage, rôles).
- **Aucun test sur téléphone** (lecture vidéo réelle, notifications, bouton Retour, signature APK).
- L'interface a été testée dans un navigateur avec un faux serveur (démo), pas avec votre serveur.

## Ce qui était déjà fonctionnel (vérifié)
- Tous les noms de tables, colonnes et fonctions appelés par l'application existent dans le SQL, avec les bons paramètres (21 fonctions comparées).
- RLS activé sur toutes les tables ; un acheteur ne peut modifier que son nom et son téléphone ; le rôle admin n'est jamais attribué à l'inscription (metadata role=admin ignoré).
- Codes d'accès : hashés (SHA-256), usage unique, liés à une formation, verrou anti double utilisation.
- Prix : toujours calculés par le serveur (price_for), promotions comprises.
- Activation revendeur manuelle : demande + preuve -> validation admin -> code RV -> saisie -> activation.

## Corrigé
1. **Stockage vidéo (défaut réel)** : un acheteur inscrit ne pouvait pas lire le fichier vidéo privé (la règle interrogeait la table videos, lisible seulement par l'admin). Nouvelle fonction can_watch_video + règle remplacée.
2. **reseller_generate_code** : créait un code sans commande. Maintenant : commande au prix officiel/promo, en attente, confirmée à l'utilisation du code ; pas de fausse notification admin.
3. **Droits EXECUTE** : 20 fonctions étaient appelables sans connexion ; il n'en reste que 2 (is_admin pour les règles RLS, claim_reset pour la réinitialisation).
4. **Migration idempotente** : la fonction existante (même avec un type de retour différent) est remplacée proprement.
5. Écran d'erreur de démarrage : affiche le message technique exact reçu de Supabase.
6. Workflow : package.json cherché en sous-dossier ; npm ci si package-lock.json existe.

## Ajouté
- Migration 009, tests SQL (supabase/tests), ce rapport.

## À faire dans Supabase
- Exécuter `009_audit_hardening.sql` (ou TOUT-EN-UN.sql sur une base neuve).
- Authentication > Sign In / Providers : activer **Allow anonymous sign-ins** puis **Save changes** (toujours bloquant d'après votre dernière capture).
- Activer les limites de débit / captcha pour les connexions anonymes.
- Créer le compte admin (Authentication > Users, Auto Confirm) puis `update public.profiles set role='admin' where email='...';`

## Tests SQL réussis (99 PASS, 0 FAIL) + 2 scénarios
Acheteur : inscription, voit les formations, ne peut ni se promouvoir, ni changer son solde, ni s'activer revendeur, ni modifier un autre profil, ni appeler les fonctions admin/revendeur, ni lire les codes/demandes/journal, ni insérer commandes ou inscriptions ; paiement manuel (montant fixé par le serveur), aucun accès avant validation, accès après validation.
Codes : invalide, déjà utilisé, révoqué, sans session, rôle anon refusés ; un code DT ne débloque que DT ; aucun code en clair en base.
Vidéos : sources vides sans droit, liste visible mais verrouillée, sources et fichier lisibles seulement pour la formation inscrite.
Revendeur : inactif refusé ; demande + preuve (chemin d'un autre refusé) ; admin accepte/refuse avec note ; code RV d'un autre refusé ; activation ; code réutilisé refusé ; activation directe admin tracée ; ventes au prix officiel/promo ; montant non modifiable ; codes générés liés à une commande ; historique isolé par revendeur ; suspension.
Admin : tableau de bord, liste des comptes, changement de prix appliqué.
Anonyme : aucun profil, commande ni code lisible.
Concurrence : 5 essais de double utilisation simultanée d'un même code -> exactement 1 succès à chaque fois.
Mise à jour : 009 appliquée seule sur une base existante contenant une ancienne fonction incompatible, puis rejouée.

## Points restants / décisions à confirmer
- **Commissions** : reseller_sell et reseller_generate_code n'enregistrent aucune commission (le client paie le revendeur directement). Seul le paiement en ligne confirmé par l'admin crédite une commission. Dites-moi si une règle de commission doit s'appliquer aux ventes manuelles.
- **Codes revendeur sans limite** : un revendeur actif peut générer autant de codes qu'il veut ; chacun est tracé (commande en attente). Une limite par jour est possible.
- **Comptes anonymes** : un acheteur qui réinstalle l'application perd sa session et donc son accès ; aucun mécanisme de récupération n'existe.
- **Revendeur « en attente »** : choisi à l'accueil, il est créé avec role=reseller / pending, sans aucun privilège avant activation.
- **Interface** : écrans admin (promotions, vidéos, paiements) non revérifiés visuellement un par un dans cette passe.
- APK signé en mode debug seulement (pas de Play Store).
