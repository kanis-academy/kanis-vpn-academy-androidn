// Ajoute le lien profond kanisvpn://auth-callback à l'activité principale (récupération du mot de passe).
const fs=require("fs"),path=require("path");
const f=path.join(__dirname,"..","android","app","src","main","AndroidManifest.xml");
if(!fs.existsSync(f)){console.error("android/ introuvable : lance d'abord « npm run android:add ».");process.exit(1);}
let x=fs.readFileSync(f,"utf8");
if(x.includes('android:scheme="kanisvpn"')){console.log("Lien profond déjà présent.");process.exit(0);}
const filter=`
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="kanisvpn" android:host="auth-callback" />
            </intent-filter>
`;
const i=x.indexOf("</activity>");
if(i<0){console.error("Balise </activity> introuvable.");process.exit(1);}
x=x.slice(0,i)+filter+"        "+x.slice(i);
if(!/launchMode="singleTask"/.test(x)){x=x.replace(/<activity\b/,'<activity android:launchMode="singleTask"');}
fs.writeFileSync(f,x);console.log("Lien profond kanisvpn://auth-callback ajouté.");
