const fs = require("fs");
const path = require("path");
const gradle = path.join(__dirname, "..", "android", "app", "build.gradle");
if (!fs.existsSync(gradle)) {
  console.error("android/app/build.gradle introuvable. Lance d'abord : npm run android:add");
  process.exit(1);
}
let s = fs.readFileSync(gradle, "utf8");
if (s.includes("keystore.properties")) {
  console.log("Signature deja configuree.");
  process.exit(0);
}
const loader = `
def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
`;
const signing = `    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }

`;
const a = s.replace(/(apply plugin: 'com\.android\.application'\s*\n)/, (m) => m + loader);
const b = a.replace(/\n[ \t]*buildTypes\s*\{/, (m) => "\n" + signing + m.replace(/^\n/, "\n"));
const c = b.replace(/(buildTypes\s*\{\s*release\s*\{)/, (m) => m + "\n            signingConfig signingConfigs.release");
if (c === s || !c.includes("signingConfigs.release") || !c.includes("keystoreProperties")) {
  console.error("Impossible de modifier build.gradle automatiquement. Voir README (signature manuelle).");
  process.exit(1);
}
fs.writeFileSync(gradle, c);
console.log("Signature configuree dans android/app/build.gradle");
