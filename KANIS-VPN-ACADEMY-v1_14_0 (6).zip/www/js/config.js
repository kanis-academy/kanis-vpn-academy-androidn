// Clé publique Supabase (conçue pour être dans l'app) ; la sécurité repose sur les règles RLS des migrations.
// N'ajoute JAMAIS la clé "service_role" ou "secret" ici.
// L'URL et la clé publique (sb_publishable_… ou anon) doivent venir du MÊME projet Supabase :
// Supabase → Project Settings → API.
window.KANIS_SUPABASE = {
  url: "https://lqxkkyhinkxncagwkojn.supabase.co",
  anonKey: "sb_publishable_XRqjv0eufs4q0nEWaYHBrQ_41DMM3Hy",
  whatsapp: "22668165026",
  redirectTo: ""   // Web : origine de l’application ; Android : lien profond kanisvpn://auth-callback
};
