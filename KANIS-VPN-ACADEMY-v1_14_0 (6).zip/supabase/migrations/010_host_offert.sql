-- 010 : host offert (acheteur + revendeur) et sites gratuits, affichés dans l'écran de félicitations.
-- Les hosts et les sites sont dans des tables : tu les ajoutes dans Supabase → Table Editor, sans recompiler l'application.
-- Le host n'est jamais dans l'APK : il est renvoyé par le serveur seulement à un acheteur inscrit, à un revendeur actif ou à l'admin.

create table if not exists public.host_gifts(
  id uuid primary key default gen_random_uuid(),
  country_code text,
  country_name text not null,
  flag text default '🏳️',
  host text not null,
  active boolean not null default true,
  position int not null default 0,
  created_at timestamptz default now());

create table if not exists public.free_sites(
  id uuid primary key default gen_random_uuid(),
  title text not null,
  url text not null,
  active boolean not null default true,
  position int not null default 0,
  created_at timestamptz default now());

alter table public.host_gifts enable row level security;
alter table public.free_sites enable row level security;
drop policy if exists hg_admin on public.host_gifts;
create policy hg_admin on public.host_gifts for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists fs_admin on public.free_sites;
create policy fs_admin on public.free_sites for all using (public.is_admin()) with check (public.is_admin());

create or replace function public.get_host_gift(p_audience text default 'buyer') returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare aud text; ok boolean;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_audience='reseller' then
    aud:='reseller';
    ok:=public.is_admin() or exists(select 1 from profiles where id=auth.uid() and reseller_status='active');
  else
    aud:='buyer';
    ok:=public.is_admin() or exists(select 1 from enrollments where user_id=auth.uid());
  end if;
  if not ok then raise exception 'Accès refusé'; end if;
  return json_build_object(
    'hosts', coalesce((select json_agg(json_build_object('country_code',country_code,'country_name',country_name,'flag',flag,'host',host) order by position,created_at) from host_gifts where active),'[]'::json),
    'sites', case when aud='buyer'
              then coalesce((select json_agg(json_build_object('title',title,'url',url) order by position,created_at) from free_sites where active),'[]'::json)
              else '[]'::json end);
end $$;
revoke all on function public.get_host_gift(text) from public, anon;
grant execute on function public.get_host_gift(text) to authenticated, service_role;

-- Exemples à adapter dans le SQL Editor (ou à saisir dans Table Editor) :
-- insert into public.host_gifts(country_code,country_name,flag,host,position) values ('BF','Burkina Faso','🇧🇫','TON-HOST-ICI',0);
-- insert into public.free_sites(title,url,position) values ('Nom du site 1','https://...',0),('Nom du site 2','https://...',1);
