-- 010 : cadeau après validation (host offert par pays + sites gratuits). À exécuter UNE fois dans Supabase > SQL Editor.
-- Les hosts et les liens ne sont lisibles que par l'admin (tables) et par les membres autorisés (fonction get_welcome_gift).

create table if not exists public.welcome_hosts(
  id uuid primary key default gen_random_uuid(),
  country text not null,
  flag text not null default '',
  host text not null,
  position int not null default 0,
  active boolean not null default true);

create table if not exists public.welcome_links(
  id uuid primary key default gen_random_uuid(),
  title text not null,
  url text not null,
  position int not null default 0,
  active boolean not null default true);

alter table public.welcome_hosts enable row level security;
alter table public.welcome_links enable row level security;
drop policy if exists wh_admin on public.welcome_hosts;
create policy wh_admin on public.welcome_hosts for all using (is_admin()) with check (is_admin());
drop policy if exists wl_admin on public.welcome_links;
create policy wl_admin on public.welcome_links for all using (is_admin()) with check (is_admin());

-- p_kind = 'buyer' : acheteur ayant au moins une formation débloquée (hosts + sites gratuits)
-- p_kind = 'reseller' : revendeur actif (hosts seulement). L'admin voit tout.
create or replace function public.get_welcome_gift(p_kind text) returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare ok boolean; hs json; ls json;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_kind='reseller' then
    ok := is_admin() or exists(select 1 from profiles where id=auth.uid() and role='reseller' and reseller_status='active');
  else
    ok := is_admin() or exists(select 1 from enrollments where user_id=auth.uid());
  end if;
  if not ok then return json_build_object('hosts','[]'::json,'links','[]'::json); end if;
  select coalesce(json_agg(json_build_object('country',country,'flag',flag,'host',host) order by position,country),'[]'::json) into hs from welcome_hosts where active;
  if p_kind='reseller' then ls:='[]'::json;
  else select coalesce(json_agg(json_build_object('title',title,'url',url) order by position,title),'[]'::json) into ls from welcome_links where active; end if;
  return json_build_object('hosts',hs,'links',ls);
end $$;

revoke execute on function public.get_welcome_gift(text) from public, anon;
grant execute on function public.get_welcome_gift(text) to authenticated, service_role;

-- ===== À REMPLIR (exemples : remplace les valeurs puis exécute) =====
-- insert into public.welcome_hosts(country,flag,host,position) values ('Burkina Faso','🇧🇫','COLLE_ICI_LE_HOST',1);
-- insert into public.welcome_links(title,url,position) values ('Nom du site 1','https://site1.exemple',1),('Nom du site 2','https://site2.exemple',2);
