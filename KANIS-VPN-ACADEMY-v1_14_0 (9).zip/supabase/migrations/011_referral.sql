-- 011 : code de parrainage (revendeur -> client). A executer UNE fois dans Supabase > SQL Editor.
-- Le client entre le code de son revendeur : il voit alors les moyens de paiement et le WhatsApp de CE revendeur
-- (et non ceux de l'administrateur), seulement si le revendeur a renseigne ses informations.

alter table public.profiles add column if not exists referral_code text;
alter table public.profiles add column if not exists referred_by uuid references public.profiles(id) on delete set null;
create unique index if not exists profiles_referral_code_key on public.profiles(referral_code) where referral_code is not null;

-- Informations visibles d'un revendeur actif (interne : appelee seulement par les fonctions ci-dessous)
create or replace function public.seller_info(p_seller uuid) returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare p record; m json; n int;
begin
  select * into p from profiles where id=p_seller and role='reseller' and reseller_status='active';
  if p.id is null then return null; end if;
  select count(*) into n from reseller_payment_methods where reseller_id=p.id;
  if n=0 and coalesce(trim(p.phone),'')='' then return null; end if;
  select coalesce(json_agg(json_build_object('operator',operator,'number',number,'holder_name',holder_name,'instructions',instructions) order by created_at),'[]'::json)
    into m from reseller_payment_methods where reseller_id=p.id;
  return json_build_object('name',p.full_name,'phone',p.phone,'methods',m);
end $$;

-- Le revendeur actif obtient (ou recupere) son code VPN-XXXXX
create or replace function public.my_referral_code() returns text
language plpgsql security definer set search_path=public,extensions as $$
declare r record; c text; i int; alpha text:='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
begin
  select * into r from profiles where id=auth.uid();
  if r.id is null or r.role<>'reseller' or r.reseller_status<>'active' then raise exception 'Reservé aux revendeurs actifs'; end if;
  if r.referral_code is not null then return r.referral_code; end if;
  loop
    c:='VPN-';
    for i in 1..5 loop c:=c||substr(alpha,1+floor(random()*length(alpha))::int,1); end loop;
    begin
      update profiles set referral_code=c where id=r.id;
      return c;
    exception when unique_violation then null;
    end;
  end loop;
end $$;

-- Le client entre le code de son revendeur
create or replace function public.use_referral_code(p_code text) returns json
language plpgsql security definer set search_path=public,extensions as $$
declare s record;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into s from profiles where referral_code=upper(trim(p_code)) and role='reseller' and reseller_status='active';
  if s.id is null then raise exception 'Code de parrainage invalide'; end if;
  if s.id=auth.uid() then raise exception 'Tu ne peux pas utiliser ton propre code'; end if;
  update profiles set referred_by=s.id where id=auth.uid();
  return json_build_object('ok',true,'seller',public.seller_info(s.id));
end $$;

-- Infos du revendeur du client (null si aucun revendeur ou si ses infos ne sont pas disponibles)
create or replace function public.my_seller() returns json
language plpgsql stable security definer set search_path=public,extensions as $$
declare rb uuid;
begin
  select referred_by into rb from profiles where id=auth.uid();
  if rb is null then return null; end if;
  return public.seller_info(rb);
end $$;

create or replace function public.clear_referral() returns void
language sql security definer set search_path=public,extensions as $$
  update profiles set referred_by=null where id=auth.uid() $$;

revoke all on function public.seller_info(uuid) from public, anon, authenticated;
revoke all on function public.my_referral_code() from public, anon;
revoke all on function public.use_referral_code(text) from public, anon;
revoke all on function public.my_seller() from public, anon;
revoke all on function public.clear_referral() from public, anon;
grant execute on function public.my_referral_code(), public.use_referral_code(text), public.my_seller(), public.clear_referral() to authenticated, service_role;
